﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace DataAccessLibrary
{
    public static class DataAccess
    {
        public async static void InitializeDatabase(String[] tableCommand)
        {
            await ApplicationData.Current.LocalFolder.CreateFileAsync("AstroDB.db", CreationCollisionOption.OpenIfExists);
            string dbpath = Path.Combine(ApplicationData.Current.LocalFolder.Path, "AstroDB.db");
            using (SqliteConnection db =
               new SqliteConnection($"Filename={dbpath}"))
            {
                db.Open();
                for (int i = 0; i < tableCommand.Length; i++)
                {
                    SqliteCommand createTable = new SqliteCommand(tableCommand[i], db);

                    createTable.ExecuteReader();
                }
            }
        }
       
        public static void InsertData(SqliteCommand insertCommand)
        {
            string dbpath = Path.Combine(ApplicationData.Current.LocalFolder.Path, "AstroDB.db");
            using (SqliteConnection db = new SqliteConnection($"Filename={dbpath}"))
            {
                db.Open();

                // SqliteCommand insertCommand = new SqliteCommand();
                insertCommand.Connection = db;
                insertCommand.ExecuteReader();

                db.Close();
            }
        }
        public static void UpdateRecord(SqliteCommand insertCommand)
        {
            string dbpath = Path.Combine(ApplicationData.Current.LocalFolder.Path, "AstroDB.db");
            using (SqliteConnection db = new SqliteConnection($"Filename={dbpath}"))
            {
                db.Open();

                // SqliteCommand insertCommand = new SqliteCommand();
                insertCommand.Connection = db;
                insertCommand.ExecuteReader();

                db.Close();
            }
        }
        public static void DeleteRecord(SqliteCommand deleteCommand)
        {
            string dbpath = Path.Combine(ApplicationData.Current.LocalFolder.Path, "AstroDB.db");
            using (SqliteConnection db = new SqliteConnection($"Filename={dbpath}"))
            {
                db.Open();
                // SqliteCommand insertCommand = new SqliteCommand();
                deleteCommand.Connection = db;
                // deleteCommand.ExecuteReader();
                deleteCommand.ExecuteNonQuery();
                db.Close();
            }
        }
        public static DataSet GetData(string query)
        {            
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            string dbpath = Path.Combine(ApplicationData.Current.LocalFolder.Path, "AstroDB.db");
            using (SqliteConnection db =
               new SqliteConnection($"Filename={dbpath}"))
            {
                db.Open();

                SqliteCommand selectCommand = new SqliteCommand                   
                    (query, db);
                SqliteDataReader sqlquery = selectCommand.ExecuteReader();
                dt.Load(sqlquery);
                
                db.Close();
                ds.Tables.Add(dt);
            }
            return ds;
        }
    }
}
