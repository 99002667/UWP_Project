﻿using MixAmp.Carina.Views;
using MixAmp.Common.UserControls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Carina.UserControl
{
    public sealed partial class RoutingOutputControl
    {
        string _Value = "0 %";
        public RoutingOutputControl()
        {
            this.InitializeComponent();
            //Load();
        }
        public RoutingOutputControl(string text)
        {
            this.InitializeComponent();
            inputdevicename.Text = text;
            //rect9.Fill = new SolidColorBrush(Colors.Red);
            Load(text);
        }

        private void Load(string inputs)
        {
            Dictionary<string, string> inputdevice = new Dictionary<string, string>();
            switch (inputs)
            {
                case "Stream Mix":
                    inputdevice.Add("1/4”", "Combo");
                    inputdevice.Add("XLR", "Combo");
                    inputdevice.Add("Game", "HDMI");
                    inputdevice.Add("PC Game", "Game USB-C");
                    inputdevice.Add("PC Chat", "Game USB-C");
                    inputdevice.Add("Alerts", "Stream USB-C");
                    inputdevice.Add("AUX", "AUX 1/4”");
                    inputdevice.Add("Headset", "Headset 1/4”");
                    inputdevice.Add("Astro A40", "Host USB-A");
                    break;
                case "Stream Mic":
                    inputdevice.Add("1/4”", "Combo");
                    inputdevice.Add("XLR", "Combo");
                    inputdevice.Add("Game", "HDMI");
                    inputdevice.Add("Headset", "Headset 1/4”");
                    inputdevice.Add("Astro A40", "Host USB-A");
                    inputdevice.Add("Astro A50", "RF");
                    break;
                case "Game Mic":
                    inputdevice.Add("1/4”", "Combo");
                    inputdevice.Add("XLR", "Combo");
                    inputdevice.Add("Game", "HDMI");
                    inputdevice.Add("Headset", "Headset 1/4”");
                    inputdevice.Add("Astro A40", "Host USB-A");
                    inputdevice.Add("Astro A50", "RF");
                    break;
                case "Headset":
                    inputdevice.Add("1/4”", "Combo");
                    inputdevice.Add("XLR", "Combo");
                    inputdevice.Add("Game", "HDMI");
                    inputdevice.Add("PC Game", "Game USB-C");
                    inputdevice.Add("PC Chat", "Game USB-C");
                    inputdevice.Add("Alerts", "Stream USB-C");
                    inputdevice.Add("AUX", "AUX 1/4”");
                    inputdevice.Add("Headset", "Headset 1/4”");
                    inputdevice.Add("Astro A40", "Host USB-A");
                    break;
                case "AUX":
                    inputdevice.Add("XLR", "Combo");
                    inputdevice.Add("Headset", "Headset 1/4”");
                    inputdevice.Add("Astro A40", "Host USB-A");
                    inputdevice.Add("Astro A50", "RF");
                    break;
                case "Stream":
                    inputdevice.Add("1/4”", "Combo");
                    inputdevice.Add("XLR", "Combo");
                    inputdevice.Add("Game", "HDMI");
                    inputdevice.Add("PC Game", "Game USB-C");
                    inputdevice.Add("PC Chat", "Game USB-C");
                    inputdevice.Add("Alerts", "Stream USB-C");
                    inputdevice.Add("AUX", "AUX 1/4”");
                    inputdevice.Add("Headset", "Headset 1/4”");
                    inputdevice.Add("Astro A40", "Host USB-A");
                    break;
                case "Astro A30":
                    inputdevice.Add("1/4”", "Combo");
                    inputdevice.Add("XLR", "Combo");
                    inputdevice.Add("Headset", "Headset 1/4”");
                    inputdevice.Add("Astro A40", "Host USB-A");
                    inputdevice.Add("Astro A50", "RF");
                    break;
            }

            foreach (var device in inputdevice)
            {
                InputDeviceControl uc = new InputDeviceControl();
                var text = uc.FindName("txt1") as TextBlock;
                var textvalue = uc.FindName("txtValue") as TextBlock;
                var stackpanel = uc.FindName("InputDevice") as StackPanel;
                var stackpanels = uc.FindName("routtab") as StackPanel;
                var text1 = uc.FindName("txt2") as TextBlock;
                var selectedImage = uc.FindName("selectedcontrol") as Image;
                var speakerrelative = uc.FindName("speakerrelative") as RelativePanel;
                var slider = uc.FindName("Slider4") as Slider;

                text.Text = device.Key;
                text1.Text = device.Value;
                switch (text.Text)
                {
                    case "1/4”":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                        break;
                    case "XLR":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                        break;
                    case "Game":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/HDMI.png"));
                        break;
                    case "PC Game":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/USB.png"));
                        break;
                    case "PC Chat":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/USB.png"));
                        break;
                    case "Alerts":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/USB.png"));
                        break;
                    case "AUX":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                        break;
                    case "Headset":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                        break;
                    case "Astro A40":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/USB.png"));
                        break;
                    case "Astro A50":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Wifi.png"));
                        break;
                }
                if (text.Text == "XLR")
                {
                    //stackpanels.Opacity = 0.4;
                    text.Foreground = new SolidColorBrush(Colors.Wheat);
                    textvalue.Foreground = new SolidColorBrush(Colors.Wheat);
                    text1.Foreground = new SolidColorBrush(Colors.Wheat);
                    slider.IsEnabled = false;
                    //speakerrelative.Opacity = 0.4;
                    stackpanel.Opacity = 0.4;
                    uc.Opacity = 0.4;
                }
                inputdevices.Children.Add(uc);
            }
            //Console.WriteLine("Key: {0}, Value: {1}", kvp.Key, kvp.Value);
            //for (int i = 0; i < inputdevice.Count; i++)
            //{
            //    text=inputdevice

            //}
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Frame parentFrame = Window.Current.Content as Frame;
            parentFrame.Navigate(typeof(TabHeader), inputdevicename);
        }

        //private void Slider_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        //{
        //    //string value = String.Format(e.NewValue.ToString());
        //    int value = Convert.ToInt32(e.NewValue.ToString());

        //    int newValue = 1;
        //    _Value = value + " %";
        //    sliderValue.Text = _Value;

        //    //if (value < 11)
        //    //{
        //    //    newValue = (Convert.ToInt32(value)) + 2;
        //    //}
        //    //else
        //    //{
        //    //     //newValue = (Convert.ToInt32(value) / 2) + 3;                

        //    //}
        //    newValue = (Convert.ToInt32(value) / 2) + 3;
        //    for (int i = 0; i < newValue; i++)
        //    {

        //        foreach (UIElement element in stkrect.Children)
        //        {
        //            if (element is Rectangle)
        //            {
        //                string[] str = ((Rectangle)element).Name.Split('t');
        //                int strID = Convert.ToInt32(str[1]);
        //                if (strID <= i)
        //                {
        //                    ((Rectangle)element).Fill = new SolidColorBrush(Colors.Wheat);
        //                }
        //                //else if (i==0)
        //                //{
        //                //    ((Rectangle)element).Fill = new SolidColorBrush(Colors.Gray);
        //                //}
        //                else
        //                {
        //                    ((Rectangle)element).Fill = new SolidColorBrush(Colors.Gray);
        //                }
        //            }

        //        }
        //    }

        //}
        private void Slider_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            string value = String.Format(e.NewValue.ToString());
            sliderValue.Text = value + "%";
            if (e.NewValue > 0)
            {
                rect1.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect1.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 2.5)
            {
                rect2.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect2.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 5)
            {
                rect3.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect3.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 7.5)
            {
                rect4.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect4.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 10)
            {
                rect5.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect5.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 12.5)
            {
                rect6.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect6.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 15)
            {
                rect7.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect7.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 17.5)
            {
                rect8.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect8.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 20)
            {
                rect9.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect9.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 22.5)
            {
                rect10.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect10.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 25)
            {
                rect11.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect11.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 27.5)
            {
                rect12.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect12.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 30)
            {
                rect13.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect13.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 32.5)
            {
                rect14.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect14.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 35)
            {
                rect15.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect15.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 37.5)
            {
                rect16.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect16.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 40)
            {
                rect17.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect17.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 42.5)
            {
                rect18.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect18.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 45)
            {
                rect19.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect19.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 47.5)
            {
                rect20.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect20.Fill = new SolidColorBrush(Colors.Gray);
            }


            if (e.NewValue > 50)
            {
                rect21.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect21.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 52.5)
            {
                rect22.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect22.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 55)
            {
                rect23.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect23.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 57.5)
            {
                rect24.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect24.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 60)
            {
                rect25.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect25.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 62.5)
            {
                rect26.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect26.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 65)
            {
                rect27.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect27.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 67.5)
            {
                rect28.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect28.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 70)
            {
                rect29.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect29.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 72.5)
            {
                rect30.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect30.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 75)
            {
                rect31.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect31.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 77.5)
            {
                rect32.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect32.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 80)
            {
                rect33.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect33.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 82.5)
            {
                rect34.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect34.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 85)
            {
                rect35.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect35.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 87.5)
            {
                rect36.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect36.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 90)
            {
                rect37.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect37.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 92.5)
            {
                rect38.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect38.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 95)
            {
                rect39.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect39.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue == 100)
            {
                rect40.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect40.Fill = new SolidColorBrush(Colors.Gray);
            }

        }
    }
}