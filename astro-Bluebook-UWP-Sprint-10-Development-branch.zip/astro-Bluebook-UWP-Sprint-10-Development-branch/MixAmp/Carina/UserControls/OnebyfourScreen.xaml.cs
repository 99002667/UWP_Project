﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Carina.UserControls
{
    public sealed partial class OnebyfourScreen : UserControl
    {
        public OnebyfourScreen()
        {
            this.InitializeComponent();
            // Get the visible bounds for current view
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            // Get the scale factor from display information
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;

            // Get the application screen size
            var size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);

            //ScrollXLR.Height = size.Height - 510;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Frame parentFrame = Window.Current.Content as Frame;
            var tabheader = parentFrame.Content as Page;
            var pivotheader = tabheader.FindName("TabHeaderView") as Pivot;
            var pivotItem = pivotheader.FindName("Microphonetab") as PivotItem;
            UserControl screens;
            Page page;
            screens = pivotItem.FindName("onebyfourscreen") as UserControl;
            page = pivotItem.FindName("microphonescreen") as Page;
            screens.Visibility = Visibility.Collapsed;
            page.Visibility = Visibility.Visible;
            //parentFrame.Navigate(typeof(TabHeader), xlrText);
        }
    }
}
