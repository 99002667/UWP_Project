﻿using MixAmp.Carina.ViewModels;
using MixAmp.Carina.Views;
using MixAmp.Common.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Carina.UserControls
{
    public sealed partial class MixAmpTakeTheTourScreens : UserControl
    {
        public ObservableCollection<TakeTheTourViewModel> mixampTourList { get; set; }
        public MixAmpTakeTheTourScreens()
        {
            this.InitializeComponent();
            mixampTourList = new ObservableCollection<TakeTheTourViewModel>();
            mixampTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Assets/Carina_Front.png",
                TextHeading = "WELCOME",
                TextContent = "Welcome to the ASTRO Mobile Command Center App. Here you will be able to customize and control your Astro Mixamp experience."
            });
            mixampTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Carina/Assets/Source Selection.png",
                TextHeading = "SOURCE SELECTION",
                TextContent = "Your Astro Mixamp has the ability to connect to three sources at one time. " +
                "You can connect to a device using the 3.5mm jack, a USB-C cable, and using Bluetooth"
            });
            mixampTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Carina/Assets/Mixing Sources.png",
                TextHeading = "MIXING SOURCES",
                TextContent = "Once you have selected your sources use the Mixing section to balance between them. Adding volume to one source will decrease the volume of the other source"
            });
            mixampTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Carina/Assets/Microphones.png",
                TextHeading = "MICROPHONES",
                TextContent = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quiver is the consumer need lorem pellentesque." +
                " Clinical always a mass of jasmine and free"
            });
            mixampTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Carina/Assets/EQ Profiles.png",
                TextHeading = "EQ PROFILES",
                TextContent = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quiver is the consumer need lorem pellentesque." +
                " Clinical always a mass of jasmine and free"
            });
            mixampTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Carina/Assets/Phantom Power.png",
                TextHeading = "PHANTOM POWER",
                TextContent = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quiver is the consumer need lorem pellentesque. Clinical always a mass of jasmine and free"
            });
            mixampTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Carina/Assets/Modules.png",
                TextHeading = "MODULES",
                TextContent = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quiver is the consumer need lorem pellentesque." +
                " Clinical always a mass of jasmine and free"
            });
        }
        private void Next_Click(object sender, RoutedEventArgs e)
        {


            if (GalleryIndicator.SelectedIndex < mixampTourList.Count - 1)
            {

                GalleryIndicator.SelectedIndex = GalleryIndicator.SelectedIndex + 1;
                btn.Content = "NEXT";
            }
            else
            {
                ((Frame)Window.Current.Content).GoBack();
            }
            if (GalleryIndicator.SelectedIndex == mixampTourList.Count - 1)
            {
                btn.Content = "COMPLETE";
            }



        }

        private void GalleryIndicator_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (GalleryIndicator.SelectedIndex < mixampTourList.Count - 1)
            {
                btnSkip.Visibility = Visibility.Visible;
                btn.Content = "NEXT";
            }

            if (GalleryIndicator.SelectedIndex == mixampTourList.Count - 1)
            {
                btnSkip.Visibility = Visibility.Collapsed;
                btn.Content = "COMPLETE";
            }
        }

        private void btnSkip_Click(object sender, RoutedEventArgs e)
        {
            GotoHomePage();
            //((Frame)Window.Current.Content).Navigate(typeof(MainPage));
        }

        private static void GotoHomePage()
        {
            Frame parentFrame = Window.Current.Content as Frame;
            var lastPage = parentFrame.BackStack.Last().SourcePageType;

            if (lastPage.FullName.Contains("TabHeader"))
            {
                ((Frame)Window.Current.Content).Navigate(typeof(TabHeader));
            }
            else
            {
                ((Frame)Window.Current.Content).Navigate(typeof(MainPage));
            }
        }


    }
}
