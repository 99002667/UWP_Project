﻿using MixAmp.Carina.Views;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Carina.UserControls
{
    public sealed partial class XLRScreen : UserControl
    {
        public XLRScreen()
        {
            this.InitializeComponent();
            // Get the visible bounds for current view
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            // Get the scale factor from display information
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;

            // Get the application screen size
            var size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            
            //ScrollXLR.Height = size.Height - 510;
        }

        //private void Slider_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        //{
        //    string value = String.Format(e.NewValue.ToString());
        //    sliderValue.Text = value + "%";
        //    if (e.NewValue > 0)
        //    {
        //        rect1.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect1.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 2.5)
        //    {
        //        rect2.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect2.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 5)
        //    {
        //        rect3.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect3.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 7.5)
        //    {
        //        rect4.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect4.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 10)
        //    {
        //        rect5.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect5.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 12.5)
        //    {
        //        rect6.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect6.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 15)
        //    {
        //        rect7.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect7.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 17.5)
        //    {
        //        rect8.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect8.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 20)
        //    {
        //        rect9.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect9.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 22.5)
        //    {
        //        rect10.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect10.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 25)
        //    {
        //        rect11.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect11.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 27.5)
        //    {
        //        rect12.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect12.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 30)
        //    {
        //        rect13.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect13.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 32.5)
        //    {
        //        rect14.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect14.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 35)
        //    {
        //        rect15.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect15.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 37.5)
        //    {
        //        rect16.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect16.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 40)
        //    {
        //        rect17.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect17.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 42.5)
        //    {
        //        rect18.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect18.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 45)
        //    {
        //        rect19.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect19.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 47.5)
        //    {
        //        rect20.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect20.Fill = new SolidColorBrush(Colors.Gray);
        //    }


        //    if (e.NewValue > 50)
        //    {
        //        rect21.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect21.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 52.5)
        //    {
        //        rect22.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect22.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 55)
        //    {
        //        rect23.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect23.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 57.5)
        //    {
        //        rect24.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect24.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 60)
        //    {
        //        rect25.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect25.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 62.5)
        //    {
        //        rect26.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect26.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 65)
        //    {
        //        rect27.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect27.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 67.5)
        //    {
        //        rect28.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect28.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 70)
        //    {
        //        rect29.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect29.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 72.5)
        //    {
        //        rect30.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect30.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 75)
        //    {
        //        rect31.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect31.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 77.5)
        //    {
        //        rect32.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect32.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 80)
        //    {
        //        rect33.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect33.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 82.5)
        //    {
        //        rect34.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect34.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue > 85)
        //    {
        //        rect35.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect35.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue >= 87.5)
        //    {
        //        rect36.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect36.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue >= 90)
        //    {
        //        rect37.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect37.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue >= 92.5)
        //    {
        //        rect38.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect38.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue >= 95)
        //    {
        //        rect39.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect39.Fill = new SolidColorBrush(Colors.Gray);
        //    }
        //    if (e.NewValue == 100)
        //    {
        //        rect40.Fill = new SolidColorBrush(Colors.Red);
        //    }
        //    else
        //    {
        //        rect40.Fill = new SolidColorBrush(Colors.Gray);
        //    }

        //}

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Frame parentFrame = Window.Current.Content as Frame;
            var tabheader = parentFrame.Content as Page;
            var pivotheader = tabheader.FindName("TabHeaderView") as Pivot;
            var pivotItem = pivotheader.FindName("Microphonetab") as PivotItem;
            UserControl screens;
            Page page;
            screens = pivotItem.FindName("xlrscreen") as UserControl;
            page = pivotItem.FindName("microphonescreen") as Page;
            screens.Visibility = Visibility.Collapsed;
            page.Visibility = Visibility.Visible;
            //parentFrame.Navigate(typeof(TabHeader), xlrText);
        }

        private void noise_Click(object sender, RoutedEventArgs e)
        {

        }

        //private void Radio_Click(object sender, RoutedEventArgs e)
        //{
        //    RadioButton rb = (RadioButton)sender;

        //    if (rb != null && lbloff != null)
        //    {

        //        string selectedColor = rb.Tag.ToString();

        //        switch (selectedColor)
        //        {
        //            case "off":
        //                lblHome.Foreground = new SolidColorBrush(Colors.Gray);
        //                lbloff.Foreground = new SolidColorBrush(Colors.White);
        //                lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
        //                lblNight.Foreground = new SolidColorBrush(Colors.Gray);
        //                break;
        //            case "Home":
        //                rb.IsChecked = true;
        //                lblHome.Foreground = new SolidColorBrush(Colors.White);
        //                lbloff.Foreground = new SolidColorBrush(Colors.Gray);
        //                lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
        //                lblNight.Foreground = new SolidColorBrush(Colors.Gray);
        //                break;
        //            case "On-the-GO":
        //                lblHome.Foreground = new SolidColorBrush(Colors.Gray);
        //                lbloff.Foreground = new SolidColorBrush(Colors.Gray);
        //                lblOnthego.Foreground = new SolidColorBrush(Colors.White);
        //                lblNight.Foreground = new SolidColorBrush(Colors.Gray);
        //                break;
        //            case "Night":
        //                lblHome.Foreground = new SolidColorBrush(Colors.Gray);
        //                lbloff.Foreground = new SolidColorBrush(Colors.Gray);
        //                lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
        //                lblNight.Foreground = new SolidColorBrush(Colors.White);
        //                break;
        //        }
        //    }
        //}
    }
}
