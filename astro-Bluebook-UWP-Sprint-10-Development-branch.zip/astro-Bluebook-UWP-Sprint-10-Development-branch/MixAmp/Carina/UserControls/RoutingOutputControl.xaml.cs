﻿using Microsoft.Toolkit.Extensions;
using MixAmp.Carina.Views;
using MixAmp.Common.UserControls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Carina.UserControls
{

    
    public sealed partial class RoutingOutputControl : UserControl
    {
        Size size;
        string _Value = "0 %";
        Windows.Storage.ApplicationDataContainer RoutingData =
  Windows.Storage.ApplicationData.Current.LocalSettings;
        string StreamMix;
        string StreamMic;
        string GameMic;
        string Headset;
        string AUX;
        string Stream;
        string AstroA30;
        string AstroA50;
        string HeadSet;
        public RoutingOutputControl()
        {
            this.InitializeComponent();
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            //Load();
        }
        public RoutingOutputControl(string text)
        {
            this.InitializeComponent();
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            inputdevicename.Text = text;

            //rect9.Fill = new SolidColorBrush(Colors.Red);
            Load(text);
        }

        public RoutingOutputControl(TextBlock text)
        {
            this.InitializeComponent();
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            inputdevicename.Text = (string)text.Tag;
            //rect9.Fill = new SolidColorBrush(Colors.Red);
            Load((string)text.Tag);
        }



        private void Load(string inputs)
        {
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;

            var languagueSelected = Utils.LanguageSettingsUtils.ReadLanguageSettings();

            if (languagueSelected.ToUpper() == "ARABIC")
            {
                if (scaleFactor == 1) { 
                    
                    SliderRouting.Width = 223;
                    SpeakerImg.Margin = new Thickness(7, 15, 0, 0);

                }
                else if (scaleFactor == 1.25)
                {
                    SliderRouting.Width = 220;
                    stkrect.Margin = new Thickness(30,-13,0,0);
                    SpeakerImg.Margin = new Thickness(8, 15, 0, 0);
                }
                else if (scaleFactor == 1.5)
                {
                    SliderRouting.Width = 223;
                    stkrect.Margin = new Thickness(15, -13, 0, 0);
                    SpeakerImg.Margin = new Thickness(5, 15, 0, 0);
                }
                else if (scaleFactor == 1.75)
                {
                    SliderRouting.Width = 224;
                    stkrect.Margin = new Thickness(14, -13, 0, 0);
                    SpeakerImg.Margin = new Thickness(4, 15, 0, 0);
                }

            }
            else {
                if (scaleFactor == 1.25)
                {
                    SliderRouting.Width = 235;
                }
                else if (scaleFactor == 1.5)
                {
                    SliderRouting.Width = 243;
                }
                else if (scaleFactor == 1.75)
                {
                    SliderRouting.Width = 255;
                }

            }
            
            Windows.Storage.ApplicationDataCompositeValue ReadRoutingData =
 (Windows.Storage.ApplicationDataCompositeValue)RoutingData.Values["RoutingDictionary"];
            int count = 1;
            foreach (var item in ReadRoutingData)
            {
                switch (count)
                {
                    case 1:
                        Headset = item.Key;
                        break;
                    case 2:
                        StreamMix = item.Key;
                        break;
                    case 3:
                        StreamMic = item.Key;
                        break;
                    case 4:
                        GameMic = item.Key;
                        break;
                    case 5:
                        AUX = item.Key;
                        break;
                    case 6:
                        Stream = item.Key;
                        break;
                    case 7:
                        HeadSet = item.Key;
                        break;
                    case 8:
                        AstroA50 = item.Key;
                        break;
                    case 9:
                        AstroA30 = item.Key;
                        break;
                    default:
                        break;
                }
                count++;
            }
            Dictionary<string, string> inputdevice = new Dictionary<string, string>();
            //switch (inputs)
            //{
            //    case "Stream Mix":
            //        inputdevice.Add("1/4”", "Combo");
            //        inputdevice.Add("XLR", "Combo");
            //        inputdevice.Add("Game", "HDMI");
            //        inputdevice.Add("PC Game", "Game USB-C");
            //        inputdevice.Add("PC Chat", "Game USB-C");
            //        inputdevice.Add("Alerts", "Stream USB-C");
            //        inputdevice.Add("AUX", "AUX 1/4”");
            //        inputdevice.Add("Headset", "Headset 1/4”");
            //        inputdevice.Add("Astro A40", "Host USB-A");                  
            //        break;
            //    case "Stream Mic":
            //        inputdevice.Add("1/4”", "Combo");
            //        inputdevice.Add("XLR", "Combo");
            //        inputdevice.Add("Game", "HDMI");
            //        inputdevice.Add("Headset", "Headset 1/4”");
            //        inputdevice.Add("Astro A40", "Host USB-A");
            //        inputdevice.Add("Astro A50", "RF");
            //        break;
            //    case "Game Mic":
            //        inputdevice.Add("1/4”", "Combo");
            //        inputdevice.Add("XLR", "Combo");
            //        inputdevice.Add("Game", "HDMI");
            //        inputdevice.Add("Headset", "Headset 1/4”");
            //        inputdevice.Add("Astro A40", "Host USB-A");
            //        inputdevice.Add("Astro A50", "RF");
            //        break;
            //    case "Headset":
            //        inputdevice.Add("1/4”", "Combo");
            //        inputdevice.Add("XLR", "Combo");
            //        inputdevice.Add("Game", "HDMI");
            //        inputdevice.Add("PC Game", "Game USB-C");
            //        inputdevice.Add("PC Chat", "Game USB-C");
            //        inputdevice.Add("Alerts", "Stream USB-C");
            //        inputdevice.Add("AUX", "AUX 1/4”");
            //        inputdevice.Add("Headset", "Headset 1/4”");
            //        inputdevice.Add("Astro A40", "Host USB-A");
            //        break;
            //    case "AUX":
            //        inputdevice.Add("XLR", "Combo");
            //        inputdevice.Add("Headset", "Headset 1/4”");
            //        inputdevice.Add("Astro A40", "Host USB-A");
            //        inputdevice.Add("Astro A50", "RF");
            //        break;
            //    case "Stream":
            //        inputdevice.Add("1/4”", "Combo");
            //        inputdevice.Add("XLR", "Combo");
            //        inputdevice.Add("Game", "HDMI");
            //        inputdevice.Add("PC Game", "Game USB-C");
            //        inputdevice.Add("PC Chat", "Game USB-C");
            //        inputdevice.Add("Alerts", "Stream USB-C");
            //        inputdevice.Add("AUX", "AUX 1/4”");
            //        inputdevice.Add("Headset", "Headset 1/4”");
            //        inputdevice.Add("Astro A40", "Host USB-A");
            //        break;
            //    case "Astro A30":
            //        inputdevice.Add("1/4”", "Combo");
            //        inputdevice.Add("XLR", "Combo");
            //        inputdevice.Add("Headset", "Headset 1/4”");
            //        inputdevice.Add("Astro A40", "Host USB-A");
            //        inputdevice.Add("Astro A50", "RF");
            //        break;
            //}
            if (inputs == StreamMix)
            {
                inputdevice.Add("1/4”", "Combo");
                inputdevice.Add("XLR", "Combo");
                inputdevice.Add("Game", "HDMI");
                inputdevice.Add("PC Game", "Game USB-C");
                inputdevice.Add("PC Chat", "Game USB-C");
                inputdevice.Add("Alerts", "Stream USB-C");
                inputdevice.Add("AUX", "AUX 1/4”");
                inputdevice.Add("Headset", "Headset 1/4”");
                inputdevice.Add("Astro A40", "Host USB-A");
            }
            else if (inputs == StreamMic)
            {
                inputdevice.Add("1/4”", "Combo");
                inputdevice.Add("XLR", "Combo");
                inputdevice.Add("Game", "HDMI");
                inputdevice.Add("Headset", "Headset 1/4”");
                inputdevice.Add("Astro A40", "Host USB-A");
                inputdevice.Add("Astro A50", "RF");
            }
            else if (inputs == GameMic)
            {
                inputdevice.Add("1/4”", "Combo");
                inputdevice.Add("XLR", "Combo");
                inputdevice.Add("Game", "HDMI");
                inputdevice.Add("Headset", "Headset 1/4”");
                inputdevice.Add("Astro A40", "Host USB-A");
                inputdevice.Add("Astro A50", "RF");
            }
            else if (inputs == Headset || inputs == HeadSet)
            {
                inputdevice.Add("1/4”", "Combo");
                inputdevice.Add("XLR", "Combo");
                inputdevice.Add("Game", "HDMI");
                inputdevice.Add("PC Game", "Game USB-C");
                inputdevice.Add("PC Chat", "Game USB-C");
                inputdevice.Add("Alerts", "Stream USB-C");
                inputdevice.Add("AUX", "AUX 1/4”");
                inputdevice.Add("Headset", "Headset 1/4”");
                inputdevice.Add("Astro A40", "Host USB-A");
            }
            else if (inputs == AUX)
            {
                inputdevice.Add("XLR", "Combo");
                inputdevice.Add("Headset", "Headset 1/4”");
                inputdevice.Add("Astro A40", "Host USB-A");
                inputdevice.Add("Astro A50", "RF");
            }
            else if (inputs == Stream)
            {
                inputdevice.Add("1/4”", "Combo");
                inputdevice.Add("XLR", "Combo");
                inputdevice.Add("Game", "HDMI");
                inputdevice.Add("PC Game", "Game USB-C");
                inputdevice.Add("PC Chat", "Game USB-C");
                inputdevice.Add("Alerts", "Stream USB-C");
                inputdevice.Add("AUX", "AUX 1/4”");
                inputdevice.Add("Headset", "Headset 1/4”");
                inputdevice.Add("Astro A40", "Host USB-A");
            }
            else if (inputs == AstroA30)
            {
                inputdevice.Add("1/4”", "Combo");
                inputdevice.Add("XLR", "Combo");
                inputdevice.Add("Headset", "Headset 1/4”");
                inputdevice.Add("Astro A40", "Host USB-A");
                inputdevice.Add("Astro A50", "RF");
            }
            StackPanel usercontrol = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(20, 80, 10, 10),
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Top,
                Width = size.Width - 150,
                Height = size.Height - 100
            };
            ScrUsercontrol.Content = usercontrol;
            foreach (var device in inputdevice)
            {
                InputDeviceControl uc = new InputDeviceControl();
                var text = uc.FindName("txt1") as TextBlock;
                var textvalue = uc.FindName("txtValue") as TextBlock;
                var stackpanel = uc.FindName("InputDevice") as StackPanel;
                var stackpanels = uc.FindName("routtab") as StackPanel;
                var text1 = uc.FindName("txt2") as TextBlock;
                var selectedImage = uc.FindName("selectedcontrol") as Image;
                var speakerrelative = uc.FindName("speakerrelative") as RelativePanel;
                var slider = uc.FindName("Slider4") as Slider;

                text.Text = device.Key;
                text1.Text = device.Value;
                switch (text.Text)
                {
                    case "1/4”":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                        break;
                    case "XLR":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                        break;
                    case "Game":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/HDMI.png"));
                        break;
                    case "PC Game":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/USB.png"));
                        break;
                    case "PC Chat":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/USB.png"));
                        break;
                    case "Alerts":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/USB.png"));
                        break;
                    case "AUX":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                        break;
                    case "Headset":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                        break;
                    case "Astro A40":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/USB.png"));
                        break;
                    case "Astro A50":
                        selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Wifi.png"));
                        break;
                }
                if (text.Text == "XLR")
                {
                    //stackpanels.Opacity = 0.4;
                    text.Foreground = new SolidColorBrush(Colors.Wheat);
                    textvalue.Foreground = new SolidColorBrush(Colors.Wheat);
                    text1.Foreground = new SolidColorBrush(Colors.Wheat);
                    slider.IsEnabled = false;
                    //speakerrelative.Opacity = 0.4;
                    stackpanel.Opacity = 0.4;
                    uc.Opacity = 0.4;
                }
                usercontrol.Children.Add(uc);
            }
            //Console.WriteLine("Key: {0}, Value: {1}", kvp.Key, kvp.Value);
            //for (int i = 0; i < inputdevice.Count; i++)
            //{
            //    text=inputdevice

            //}
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Frame parentFrame = Window.Current.Content as Frame;
            parentFrame.Navigate(typeof(TabHeader), inputdevicename);
        }

        //private void Slider_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        //{
        //    //string value = String.Format(e.NewValue.ToString());
        //    int value = Convert.ToInt32(e.NewValue.ToString());

        //    int newValue = 1;
        //    _Value = value + " %";
        //    sliderValue.Text = _Value;

        //    //if (value < 11)
        //    //{
        //    //    newValue = (Convert.ToInt32(value)) + 2;
        //    //}
        //    //else
        //    //{
        //    //     //newValue = (Convert.ToInt32(value) / 2) + 3;                

        //    //}
        //    newValue = (Convert.ToInt32(value) / 2) + 3;
        //    for (int i = 0; i < newValue; i++)
        //    {

        //        foreach (UIElement element in stkrect.Children)
        //        {
        //            if (element is Rectangle)
        //            {
        //                string[] str = ((Rectangle)element).Name.Split('t');
        //                int strID = Convert.ToInt32(str[1]);
        //                if (strID <= i)
        //                {
        //                    ((Rectangle)element).Fill = new SolidColorBrush(Colors.Wheat);
        //                }
        //                //else if (i==0)
        //                //{
        //                //    ((Rectangle)element).Fill = new SolidColorBrush(Colors.Gray);
        //                //}
        //                else
        //                {
        //                    ((Rectangle)element).Fill = new SolidColorBrush(Colors.Gray);
        //                }
        //            }

        //        }
        //    }

        //}
        private void Slider_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            string value = String.Format(e.NewValue.ToString());
            sliderValue.Text = value + "%";
            if (e.NewValue > 0)
            {
                rect1.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect1.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 2.5)
            {
                rect2.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect2.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 5)
            {
                rect3.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect3.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 7.5)
            {
                rect4.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect4.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 10)
            {
                rect5.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect5.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 12.5)
            {
                rect6.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect6.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 15)
            {
                rect7.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect7.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 17.5)
            {
                rect8.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect8.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 20)
            {
                rect9.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect9.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 22.5)
            {
                rect10.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect10.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 25)
            {
                rect11.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect11.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 27.5)
            {
                rect12.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect12.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 30)
            {
                rect13.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect13.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 32.5)
            {
                rect14.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect14.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 35)
            {
                rect15.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect15.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 37.5)
            {
                rect16.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect16.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 40)
            {
                rect17.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect17.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 42.5)
            {
                rect18.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect18.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 45)
            {
                rect19.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect19.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 47.5)
            {
                rect20.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect20.Fill = new SolidColorBrush(Colors.Gray);
            }


            if (e.NewValue > 50)
            {
                rect21.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect21.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 52.5)
            {
                rect22.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect22.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 55)
            {
                rect23.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect23.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 57.5)
            {
                rect24.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect24.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 60)
            {
                rect25.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect25.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 62.5)
            {
                rect26.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect26.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 65)
            {
                rect27.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect27.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 67.5)
            {
                rect28.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect28.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 70)
            {
                rect29.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect29.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 72.5)
            {
                rect30.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect30.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 75)
            {
                rect31.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect31.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 77.5)
            {
                rect32.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect32.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 80)
            {
                rect33.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect33.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 82.5)
            {
                rect34.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect34.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 85)
            {
                rect35.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect35.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 87.5)
            {
                rect36.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect36.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 90)
            {
                rect37.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect37.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 92.5)
            {
                rect38.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect38.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 95)
            {
                rect39.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect39.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue == 100)
            {
                rect40.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect40.Fill = new SolidColorBrush(Colors.Gray);
            }

        }
        //private void Change_Name_Save_Btn_Click(object sender, RoutedEventArgs e)
        //{
        //    if (msg_bar_grid.Visibility == Visibility.Visible)
        //    {
        //        msg_bar_grid.Visibility = Visibility.Collapsed;
        //    }
        //    Windows.Storage.ApplicationDataCompositeValue ReadRoutingData =
        //(Windows.Storage.ApplicationDataCompositeValue)RoutingData.Values["RoutingDictionary"];
        //    foreach (var item in ReadRoutingData)
        //    {
        //        if (item.Key.Equals(txtName.Text))
        //        {
        //            this.SetMessageBarTimeout(msg_bar_grid, txtName.Text);
        //            Name_flyout.Hide();
        //            return;
        //        }
        //    }
        //    Windows.Storage.ApplicationDataCompositeValue WriteRoutingData =
        //new Windows.Storage.ApplicationDataCompositeValue();
        //    foreach (var item1 in ReadRoutingData)
        //    {
        //        if (item1.Key.Equals(inputdevicename.Text))
        //        {
        //            WriteRoutingData[txtName.Text] = item1.Value;
        //        }
        //        else
        //        {
        //            WriteRoutingData[item1.Key] = item1.Value;
        //        }
        //    }
        //    inputdevicename.Text = txtName.Text;
        //    RoutingData.Values["RoutingDictionary"] = WriteRoutingData;
        //    Name_flyout.Hide();
        //}
        private void Change_Name_Save_Btn_Click(object sender, RoutedEventArgs e)
        {
            if (msg_bar_grid.Visibility == Visibility.Visible)
            {
                msg_bar_grid.Visibility = Visibility.Collapsed;
            }
            if (!String.IsNullOrWhiteSpace(txtName.Text))
            {
                
                Windows.Storage.ApplicationDataCompositeValue ReadRoutingData =
            (Windows.Storage.ApplicationDataCompositeValue)RoutingData.Values["RoutingDictionary"];
                foreach (var item in ReadRoutingData)
                {
                    if (item.Key.Equals(txtName.Text))
                    {
                        this.SetMessageBarTimeout(msg_bar_grid, txtName.Text);
                        Name_flyout.Hide();
                        return;
                    }
                }
                Windows.Storage.ApplicationDataCompositeValue WriteRoutingData =
            new Windows.Storage.ApplicationDataCompositeValue();
                foreach (var item1 in ReadRoutingData)
                {
                    if (item1.Key.Equals(inputdevicename.Text))
                    {
                        WriteRoutingData[txtName.Text] = item1.Value;
                    }
                    else
                    {
                        WriteRoutingData[item1.Key] = item1.Value;
                    }
                }
                inputdevicename.Text = txtName.Text;
                RoutingData.Values["RoutingDictionary"] = WriteRoutingData;
                Name_flyout.Hide();
            }
        }
        private async void SetMessageBarTimeout(Grid msg_bar_grid, string warningMsg)
        {
            this.ShowValidationErrorMessage(msg_bar_grid, warningMsg);
            await Task.Delay(3000);
            this.HideValidationErrorMessage(msg_bar_grid);
        }
        private void ShowValidationErrorMessage(Grid msg_bar_grid, string warningMsg)
        {
            Message_Text.Text = warningMsg + " has already been used. Use a different name.";
            if (msg_bar_grid.Visibility == Visibility.Collapsed)
            {
                msg_bar_grid.Visibility = Visibility.Visible;
            }
        }
        private void HideValidationErrorMessage(Grid msg_bar_grid)
        {
            if (msg_bar_grid.Visibility == Visibility.Visible)
            {
                msg_bar_grid.Visibility = Visibility.Collapsed;
                Message_Text.Text = "Name Already Exist";
            }
        }
        private void Close_Message_Click(object sender, RoutedEventArgs e)
        {
            msg_bar_grid.Visibility = Visibility.Collapsed;
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            var view = DisplayInformation.GetForCurrentView();
            var scale = view.ResolutionScale == ResolutionScale.Invalid ? 1 : view.RawPixelsPerViewPixel;
            var resolution = new Size(view.ScreenWidthInRawPixels, view.ScreenHeightInRawPixels);
            var screenheight = resolution.Height;

            if (scale != 2)
            {
                screenheight = resolution.Height - (resolution.Height * (scale - 1));
            }
            else
            {
                screenheight = resolution.Height - (resolution.Height * (1.75 - 1));
            }

            if (screenheight < 1000 && screenheight > 850)
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.9f);
            }
            else if (screenheight < 850 && screenheight > 700)
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.85f);
            }
            else if (screenheight < 700 && screenheight > 450)
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.75f);
            }
            else if (screenheight < 450)
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.65f);
            }
        }
    }
}