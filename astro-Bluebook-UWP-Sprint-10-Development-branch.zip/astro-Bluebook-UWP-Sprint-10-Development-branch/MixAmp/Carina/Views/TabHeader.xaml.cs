﻿using MixAmp.Common.UserControls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using MixAmp.Carina.UserControls;
using MixAmp.Common.UserControls.Setting;
using MixAmp.Common.ViewModels;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Carina.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class TabHeader : Page
    {
        SolidColorBrush textcolor = new SolidColorBrush(Color.FromArgb(1, 255, 255, 255));
        string previousSelectedItem;
        public TabHeader()
        {
            try
            {
                this.InitializeComponent();
                AppCenter.Start("df4cf793-71ba-4be4-a7b8-10df5904dbd0",
                           typeof(Analytics), typeof(Crashes));
                Load();
            }
            catch (Exception ex)
            {
                ErrorAttachmentLog.AttachmentWithText(ex.Message, ex.StackTrace.ToString());
                throw;
            }

        }
        private void Load()
        {
            var footercontrol = TabHeaderView.FindName("FooterControl") as UserControl;
            var text = footercontrol.FindName("txtDevice") as TextBlock;
            text.Text = DeviceSpecificDataViewModel.GetCarinaDeviceName();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Settings(object sender, RoutedEventArgs e)
        {
            Button SettingsButton = (Button)sender;
            Flyout SettingsFlyout = (Flyout)SettingsButton.Flyout;
            StackPanel SettingsStackPanel = (StackPanel)SettingsFlyout.Content;
            UIElementCollection UIElements = SettingsStackPanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is RelativePanel)
                {
                    RelativePanel RelativePanel = (RelativePanel)UIElement;
                    this.SetDeviceName(RelativePanel);
                }
            }
        }

        private void SetDeviceName(RelativePanel RelativePanel)
        {
            UIElementCollection UIElements = RelativePanel.Children;
            var basescreen = TabHeaderView.FindName("FooterControl") as UserControl;
            var txtDevice = basescreen.FindName("txtDevice") as TextBlock;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = (MainSettingsMenu)UIElement;
                    ListView MainSettingsList = (ListView)MainSettingsMenu.FindName("MainSettingsList");
                    TextBlock DeviceNameTextBlock = (TextBlock)MainSettingsMenu.FindName("SelectedDevice");
                    //string DeviceName = txtDevice.Text;
                    //string DeviceName = "Mixamp Studio";
                    string DeviceName = DeviceSpecificDataViewModel.GetCarinaDeviceName();
                    MainSettingsList.ItemsSource = new MainSettings();
                    DeviceNameTextBlock.Text = DeviceName;
                }
                else if (UIElement is DeviceSettingsMenu)
                {
                    DeviceSettingsMenu DeviceSettingsMenu = (DeviceSettingsMenu)UIElement;
                    ListView DeviceSettingsList = (ListView)DeviceSettingsMenu.FindName("DeviceSettingsList");
                    TextBlock DeviceNameText = (TextBlock)DeviceSettingsMenu.FindName("DeviceNameText");
                    DeviceSettingsList.ItemsSource = new DeviceSettings();
                    //string DeviceName = txtDevice.Text;
                    // DeviceName = "Mixamp Studio";
                    string DeviceName = DeviceSpecificDataViewModel.GetCarinaDeviceName();
                    DeviceNameText.Text = DeviceName;
                }
                
                else if (UIElement is AppSettingsMenu)
                {
                    AppSettingsMenu AppSettingsMenu = (AppSettingsMenu)UIElement;
                    ListView AppSettingsList = (ListView)AppSettingsMenu.FindName("AppSettingsList");
                    TextBlock DeviceNameTextBlock = (TextBlock)AppSettingsMenu.FindName("AppSettingsText");

                    //string DeviceName = txtDevice.Text;
                    string DeviceName = "Application";
                    AppSettingsList.ItemsSource = new AppSettings();
                    DeviceNameTextBlock.Text = DeviceName;
                }
            }
        }
        private void settings_flyout_Closed(object sender, object e)
        {
            var footercontrol = TabHeaderView.FindName("FooterControl") as UserControl;
            var footerText = footercontrol.FindName("txtDevice") as TextBlock;
            string MixAmp = DeviceSpecificDataViewModel.GetCarinaDeviceName();
            footerText.Text = MixAmp;
            Flyout flyout = (sender) as Flyout;
            var SettingsStackPanel = flyout.Content as StackPanel;
            UIElementCollection UIElements = SettingsStackPanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is RelativePanel)
                {
                    RelativePanel RelativePanel = (RelativePanel)UIElement;
                    this.RefreshSettingsUI(RelativePanel);
                }
            }
        }
        private void RefreshSettingsUI(RelativePanel relativePanel)
        {
            UIElementCollection UIElements = relativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is MainSettingsMenu)
                {
                    UIElement.Visibility = Visibility.Visible;
                }
                else
                {
                    UIElement.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            if (settings_flyout.IsOpen)
            {
                settings_flyout.Hide();
            }
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            bool navigationdone = false;
            string input = string.Empty;
            if (e.Parameter != null)
            {
                var text = ((Windows.UI.Xaml.FrameworkElement)e.Parameter).Name;
                // var controls = (Controls)e.Parameter;
                if (e.Parameter.GetType() == typeof(TextBlock))
                {
                    input = ((Windows.UI.Xaml.Controls.TextBlock)e.Parameter).Text;
                }
                //input = ((Windows.UI.Xaml.Controls.TextBlock)e.Parameter).Text;

                if (text == "xlrText" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 4;
                    navigationdone = true;
                }
                if (text == "pcText" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 4;
                    navigationdone = true;
                }
                if (text == "inputdevicename" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                    Routingtab.Margin = new Thickness(0, 0, 12, 0);
                    MixAmpRoutingScreen mix = new MixAmpRoutingScreen();
                    mix.Margin = new Thickness(20, 0, 0, 0);
                    Routingtab.Content = mix;
                    navigationdone = true;
                }
                if (text == "ProfileList" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                    object items = ((Windows.UI.Xaml.Controls.Primitives.Selector)e.Parameter).SelectedItem;
                    Routingtab.Margin = new Thickness(0, 0, 12, 0);
                    Routingtab.Content = new MixAmpRoutingScreen(items);

                    navigationdone = true;
                }
                if (input == "Selected" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 3;
                    //routingtab.Content = new StreamMix(input);
                    navigationdone = true;
                }
                else if (input != "Selected" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                    Routingtab.Content = new RoutingOutputControl(((Windows.UI.Xaml.Controls.TextBlock)e.Parameter));
                    navigationdone = true;
                }



            }
            else
            {
                TabHeaderView.SelectedIndex = 1;
            }
            //Debug.WriteLine("Navigated");
        }
         
        private void TabHeaderView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //var basescreen = TabHeaderView.FindName("EqualizerBaseScreen") as EqualizerBaseScreen;
            //var equalizerscreen = basescreen.FindName("EqualizerScreen") as EqualizerScreen;
            //var image = equalizerscreen.FindName("BoontaEveImage") as Image;
            //image.Source = new BitmapImage(new Uri("ms-appx:///BoontaEve/Assets/Boonta Eve, Equalizer.png"));

            PivotItem pivot = (PivotItem)(sender as Pivot).SelectedItem;
            Pivot pivotMain = (sender as Pivot);
            switch (pivot.Name)
            {
                case "ProfileTab":
                    previousSelectedItem = pivot.Name;
                    profileIcon.Opacity = 1;
                    RoutingIcon.Opacity = 0.5;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 0.5;
                    moduleIcon.Opacity = 0.5;
                    videoIcon.Opacity = 0.5;
                    break;
                case "Routingtab":
                    previousSelectedItem = pivot.Name;
                    TabHeaderView.SelectedIndex = 2;
                    profileIcon.Opacity = 0.5;
                    RoutingIcon.Opacity = 1;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 0.5;
                    moduleIcon.Opacity = 0.5;
                    videoIcon.Opacity = 0.5;
                    break;
                case "MixerTab":
                    previousSelectedItem = pivot.Name;
                    profileIcon.Opacity = 0.5;
                    RoutingIcon.Opacity = 0.5;
                    MixerIcon.Opacity = 1;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 0.5;
                    moduleIcon.Opacity = 0.5;
                    videoIcon.Opacity = 0.5;
                    break;
                case "Microphonetab":
                    previousSelectedItem = pivot.Name;
                    profileIcon.Opacity = 0.5;
                    RoutingIcon.Opacity = 0.5;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 1;
                    EQIcon.Opacity = 0.5;
                    moduleIcon.Opacity = 0.5;
                    videoIcon.Opacity = 0.5;
                    break;
                case "EqualizerTab":
                    previousSelectedItem = pivot.Name;
                    profileIcon.Opacity = 0.5;
                    RoutingIcon.Opacity = 0.5;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 1;
                    moduleIcon.Opacity = 0.5;
                    videoIcon.Opacity = 0.5;
                    break;
                case "ModuleTab":
                    previousSelectedItem = pivot.Name;
                    profileIcon.Opacity = 0.5;
                    RoutingIcon.Opacity = 0.5;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 0.5;
                    moduleIcon.Opacity = 1;
                    videoIcon.Opacity = 0.5;
                    break;
                case "VideoTab":
                    previousSelectedItem = pivot.Name;
                    profileIcon.Opacity = 0.5;
                    RoutingIcon.Opacity = 0.5;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 0.5;
                    moduleIcon.Opacity = 0.5;
                    videoIcon.Opacity = 1;
                    break;
                case "":
                    Frame parentFrame = Window.Current.Content as Frame;
                    parentFrame.Navigate(typeof(MainPage));
                    break;
                    
                default:
                    SelectNavigation(previousSelectedItem);
                    profileIcon.Opacity = 1;
                    RoutingIcon.Opacity = 0.5;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 0.5;
                    moduleIcon.Opacity = 0.5;
                    videoIcon.Opacity = 0.5;
                    break;
            }
        }

        private void SelectNavigation(string previousSelectedItem)
        {
            switch (previousSelectedItem)
            {
                case "ProfileTab":
                    TabHeaderView.SelectedIndex = 1;
                    break;
                case "Routingtab":
                    TabHeaderView.SelectedIndex = 2;
                    break;
                case "MixerTab":
                    TabHeaderView.SelectedIndex = 3;
                    break;
                case "Microphonetab":
                    TabHeaderView.SelectedIndex = 4;
                    break;
                case "EqualizerTab":
                    TabHeaderView.SelectedIndex = 5;
                    break;
                case "ModuleTab":
                    TabHeaderView.SelectedIndex = 6;
                    break;
                case "VideoTab":
                    TabHeaderView.SelectedIndex = 7;
                    break;
                default:

                    break;
            }
        }



        //private void Navigate_Home(object sender, RoutedEventArgs e)
        //{
        //    Frame parentFrame = Window.Current.Content as Frame;
        //    parentFrame.Navigate(typeof(MainPage));
        //}
    }
}