﻿using MixAmp.Carina.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Carina.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MixAmpMicrophoneScreen : Page
    {
        public MixAmpMicrophoneScreen()
        {
            this.InitializeComponent();
            MicrophoneList.ItemsSource = new MicrophoneInputSources();
            // Get the visible bounds for current view
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            // Get the scale factor from display information
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;

            // Get the application screen size
            var size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            if (size.Height > 900)
            {
                MicrophoneList.Height = size.Height - 700;

            }
            else {
                MicrophoneList.Height = size.Height - 480;
            }

           
            this.DataContext = this;
        }

        private void LoadPivot()
        {
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Settings(object sender, RoutedEventArgs e)
        {

        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {

        }

        private void MyDevices(object sender, RoutedEventArgs e)
        {
            Frame parentFrame = Window.Current.Content as Frame;
            parentFrame.Navigate(typeof(MainPage));
        }

        private void XLScreen(object sender, RoutedEventArgs e)
        {

            Frame parentFrame = Window.Current.Content as Frame;
            parentFrame.Navigate(typeof(MicrophoneXLRScreen));

        }

        private void ProfileList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var deviceSelected = ((MicrophoneViewModel)((Windows.UI.Xaml.Controls.Primitives.Selector)sender).SelectedItem).InputDevicename.ToUpper();
            Frame parentFrame = Window.Current.Content as Frame;
            var tabheader = parentFrame.Content as Page;
            var pivotheader = tabheader.FindName("TabHeaderView") as Pivot;
            var pivotItem = pivotheader.FindName("MixAmpMicrophone") as PivotItem;
            //UserControl screens;
            Page page;
            switch (deviceSelected)
            {
                case "XLR":
                    var screenxlr = pivotItem.FindName("xlrscreen") as UserControl;
                    page = pivotItem.FindName("microphonescreen") as Page;
                    screenxlr.Visibility = Visibility.Visible;
                    page.Visibility = Visibility.Collapsed;
                    break;
                case "PC CHAT":
                    var pcscreens = pivotItem.FindName("pcchatscreen") as UserControl;
                   
                    var leftpanel = pcscreens.FindName("leftpanel") as UserControl;
                    var ScrollViewer = leftpanel.FindName("Scroll") as ScrollViewer;
                    var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
                    var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
                    var size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
                    ScrollViewer.Height = (size.Height / 2) - 108;

                    page = pivotItem.FindName("microphonescreen") as Page;
                    pcscreens.Visibility = Visibility.Visible;
                    page.Visibility = Visibility.Collapsed;
                    break;
                case "1/4":
                    var screenonebyfour = pivotItem.FindName("onebyfourscreen") as UserControl;
                    page = pivotItem.FindName("microphonescreen") as Page;
                    screenonebyfour.Visibility = Visibility.Visible;
                    page.Visibility = Visibility.Collapsed;
                    break;
                default:
                    break;
            }

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                Frame parentFrame = Window.Current.Content as Frame;
                parentFrame.Navigate(typeof(TabHeader));
            }
            catch (Exception ex)
            {


            }
        }

        private void MicrophoneList_ItemClick(object sender, ItemClickEventArgs e)
        {
            var deviceSelected = ((MicrophoneViewModel)((Windows.UI.Xaml.Controls.Primitives.Selector)sender).SelectedItem).InputDevicename.ToUpper();
            Frame parentFrame = Window.Current.Content as Frame;
            var tabheader = parentFrame.Content as Page;
            var pivotheader = tabheader.FindName("TabHeaderView") as Pivot;
            var pivotItem = pivotheader.FindName("MixAmpMicrophone") as PivotItem;
            //UserControl screens;
            Page page;
            switch (deviceSelected)
            {
                case "XLR":
                    var screenxlr = pivotItem.FindName("xlrscreen") as UserControl;
                    page = pivotItem.FindName("microphonescreen") as Page;
                    var leftpanels = screenxlr.FindName("leftpanel") as UserControl;
                    screenxlr.Visibility = Visibility.Visible;
                    page.Visibility = Visibility.Collapsed;
                    break;
                case "PC CHAT":
                    var pcscreens = pivotItem.FindName("pcchatscreen") as UserControl;
                    var leftpanel = pcscreens.FindName("leftpanel") as UserControl;
                    var ScrollViewer = leftpanel.FindName("Scroll") as ScrollViewer;
                    var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
                    var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
                    var size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
                    ScrollViewer.Height = (size.Height / 2) - 108;
                    page = pivotItem.FindName("microphonescreen") as Page;
                    pcscreens.Visibility = Visibility.Visible;
                    page.Visibility = Visibility.Collapsed;
                    break;
                default:
                    break;
            }
        }

        private void Image_Tapped(object sender, Windows.UI.Xaml.Input.TappedRoutedEventArgs e)
        {
            var deviceSelected = ((MixAmp.Carina.ViewModels.MicrophoneViewModel)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).InputDevicename.ToUpper();
            Frame parentFrame = Window.Current.Content as Frame;
            var tabheader = parentFrame.Content as Page;
            var pivotheader = tabheader.FindName("TabHeaderView") as Pivot;
            var pivotItem = pivotheader.FindName("Microphonetab") as PivotItem;
            //UserControl screens;
            Page page;
            switch (deviceSelected)
            {
                case "XLR":
                    var screenxlr = pivotItem.FindName("xlrscreen") as UserControl;
                    page = pivotItem.FindName("microphonescreen") as Page;
                    var leftpanels = screenxlr.FindName("leftpanel") as UserControl;
                    screenxlr.Visibility = Visibility.Visible;
                    page.Visibility = Visibility.Collapsed;
                    break;
                case "PC CHAT":
                    var pcscreens = pivotItem.FindName("pcchatscreen") as UserControl;
                    var leftpanel = pcscreens.FindName("leftpanel") as UserControl;
                    var ScrollViewer = leftpanel.FindName("Scroll") as ScrollViewer;
                    var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
                    var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
                    var size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
                    ScrollViewer.Height = (size.Height / 2) - 108;
                    page = pivotItem.FindName("microphonescreen") as Page;
                    pcscreens.Visibility = Visibility.Visible;
                    page.Visibility = Visibility.Collapsed;
                    break;
                case "1/4”":
                    var screenonebyfour = pivotItem.FindName("onebyfourscreen") as UserControl;
                    page = pivotItem.FindName("microphonescreen") as Page;
                    screenonebyfour.Visibility = Visibility.Visible;
                    page.Visibility = Visibility.Collapsed;
                    break;
                default:
                    break;
            }
        }
    }
}
