﻿using Microsoft.Toolkit.Extensions;
using MixAmp.Common.UserControls;
using MixAmp.Common.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Carina.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MixAmpRoutingScreen : Page
    {
        Windows.Storage.ApplicationDataContainer RoutingData =
    Windows.Storage.ApplicationData.Current.LocalSettings;
        Size size;
        Dictionary<string, string> inputdevice;
        Dictionary<string, string> RoutingListData;
        public MixAmpRoutingScreen()
        {
            this.InitializeComponent();
            RoutingListData = new Dictionary<string, string>() {
                { "Headset", "Host USB-A" },
                { "Stream Mix", "Stream USB-C" },
                { "Stream Mic", "Stream USB-C" },
                { "Game Mic", "Game USB-C" },
                { "AUX", "AUX 1/8”" },
                { "Stream", "Stream 1/8”" },
                { "HeadSet", "Headset 1/8”" },
                { "Astro A50", "RF" },
                { "Astro A30", "Bluetooth" } };
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            AddedList.Height = size.Height - 540;
            // ScrUsercontrol.Height = size.Height - 200;
            //ScrUsercontrol.Width = size.Width - 300;
            profileSelected.Text = "Xbox";
            profilestatus.Text = "Active Profile";
            volt.Visibility = Visibility.Visible;
            profilestatus.Foreground = new SolidColorBrush(Colors.OrangeRed);
            //usercontrolstack.Width = size.Width - 150;
            //usercontrolstack.Height = size.Height - 100;
            RoutingList.ItemsSource = new RoutingMonitor();
            AddedList.ItemsSource = new AddedRouting();

            Windows.Storage.ApplicationDataCompositeValue ReadRoutingData =
   (Windows.Storage.ApplicationDataCompositeValue)RoutingData.Values["RoutingDictionary"];
            if (ReadRoutingData == null)
            {
                Windows.Storage.ApplicationDataCompositeValue WriteRoutingData =
    new Windows.Storage.ApplicationDataCompositeValue();
                foreach (var item in RoutingListData)
                {
                    WriteRoutingData[item.Key] = item.Value;
                }
                RoutingData.Values["RoutingDictionary"] = WriteRoutingData;
            }
            Load();
            this.DataContext = this;
        }

        public MixAmpRoutingScreen(object profileViewModel)
        {
            this.InitializeComponent();
            RoutingListData = new Dictionary<string, string>() {
                { "Headset", "Host USB-A" },
                { "Stream Mix", "Stream USB-C" },
                { "Stream Mic", "Stream USB-C" },
                { "Game Mic", "Game USB-C" },
                { "AUX", "AUX 1/8”" },
                { "Stream", "Stream 1/8”" },
                { "HeadSet", "Headset 1/8”" },
                { "Astro A50", "RF" },
                { "Astro A30", "Bluetooth" } };
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            AddedList.Height = size.Height - 540;
            // ScrUsercontrol.Height = size.Height - 200;
            ScrUsercontrol.Width = size.Width - 300;
            profileSelected.Text = ((MixAmp.Carina.ViewModels.ProfileViewModel)profileViewModel).Name;
            profilestatus.Text = ((MixAmp.Carina.ViewModels.ProfileViewModel)profileViewModel).Status;
            if (profilestatus.Text == "Active Profile")
                profilestatus.Foreground = new SolidColorBrush(Colors.OrangeRed);
            else
                profilestatus.Foreground = new SolidColorBrush(Colors.Gray);

            volt.Visibility = ((MixAmp.Carina.ViewModels.ProfileViewModel)profileViewModel).FortyEightV_Visibility;
            var monitor = leftpanel.FindName("monitor") as TextBlock;
            //monitor.Margin = new Thickness(-440, 0, 0, 0);
            topsection.Margin = new Thickness(20, 0, 0, 0);
            //leftpanel.Margin = new Thickness(0, 30, 0, 0);
            ScrUsercontrol.Margin = new Thickness(0, 0, 0, 0);
            RoutingList.ItemsSource = new RoutingMonitor();
            AddedList.ItemsSource = new AddedRouting();
            Windows.Storage.ApplicationDataCompositeValue ReadRoutingData =
 (Windows.Storage.ApplicationDataCompositeValue)RoutingData.Values["RoutingDictionary"];
            if (ReadRoutingData == null)
            {
                Windows.Storage.ApplicationDataCompositeValue WriteRoutingData =
    new Windows.Storage.ApplicationDataCompositeValue();
                foreach (var item in RoutingListData)
                {
                    WriteRoutingData[item.Key] = item.Value;
                }
                RoutingData.Values["RoutingDictionary"] = WriteRoutingData;
            }
            Load();
            this.DataContext = this;
        }

        private void Load()
        {
            StackPanel usercontrol = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 80, 10, 10),
                HorizontalAlignment = HorizontalAlignment.Left,
                Width = size.Width - 150,
                //Height = size.Height - 100
            };
            ScrUsercontrol.Content = usercontrol;
            SourceUserControl uc;
            string selectedinput = string.Empty;
            var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
            foreach (var item in lists)
            {
                selectedinput = item.InputDevicename;
            }
            Dictionary<string, string> inputdevice = new Dictionary<string, string>();
            Windows.Storage.ApplicationDataCompositeValue ReadRoutingData =
   (Windows.Storage.ApplicationDataCompositeValue)RoutingData.Values["RoutingDictionary"];
            foreach (var item in ReadRoutingData)
            {
                inputdevice.Add(item.Key, (string)item.Value);
            }
            foreach (var device in inputdevice)
            {
                uc = new SourceUserControl();
                if (selectedinput == device.Key)
                {
                    this.InitializeComponent();
                }
                var text = uc.FindName("txt1") as TextBlock;
                var text1 = uc.FindName("txt2") as TextBlock;
                var playbutton = uc.FindName("ison") as TextBlock;
                var selectedbutton = uc.FindName("btntop") as Button;
                var selectedImage = uc.FindName("selectedcontrol") as Image;
                var strLengh = device.Key.Length;
                text.Tag = device.Key;
                var strText = (strLengh < 13) ? device.Key : device.Key.Truncate(10) + "...";
                text.Text = strText;
                text1.Text = device.Value;
                if (selectedinput == device.Key)
                {
                    selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Mixer.png"));
                    playbutton.Text = "Selected";
                }
                else
                    selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Vector.png"));

                usercontrol.Children.Add(uc);

            }

        }

        private void RoutingList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (AddedList.Visibility != Visibility.Visible)
            {

                AddedList.Visibility = Visibility.Visible;
                var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {

                    item.notvisiblearrow = Visibility.Visible;
                    item.visiblearrow = Visibility.Collapsed;
                }
                // RoutingList.Height = size.Height - 480;
                RoutingList.ItemsSource = null;
                RoutingList.ItemsSource = lists;
            }

            else
            {
                AddedList.Visibility = Visibility.Collapsed;
                var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {
                    item.notvisiblearrow = Visibility.Collapsed;
                    item.visiblearrow = Visibility.Visible;
                }
                // RoutingList.Height = 200;
                RoutingList.ItemsSource = null;
                RoutingList.ItemsSource = lists;
            }
        }

        private void AddedList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var selecteditem = ((Windows.UI.Xaml.Controls.Primitives.Selector)sender).SelectedValue;

            var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
            // Your UI update code goes here!
            foreach (var items in lists)
            {
                items.Icon = ((MixAmp.Common.ViewModels.RoutingViewModel)selecteditem).Icon;
                items.InputDevicename = ((MixAmp.Common.ViewModels.RoutingViewModel)selecteditem).InputDevicename;
                items.notvisiblearrow = Visibility.Visible;
                items.visiblearrow = Visibility.Collapsed;
            }
            RoutingList.ItemsSource = null;
            RoutingList.ItemsSource = lists;
            Load();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {

                Frame parentFrame = Window.Current.Content as Frame;
                parentFrame.Navigate(typeof(TabHeader));
            }
            catch (Exception ex)
            {


            }
        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            var view = DisplayInformation.GetForCurrentView();
            var scale = view.ResolutionScale == ResolutionScale.Invalid ? 1 : view.RawPixelsPerViewPixel;
            var resolution = new Size(view.ScreenWidthInRawPixels, view.ScreenHeightInRawPixels);
            var screenheight = resolution.Height;

            if (scale != 2)
            {
                screenheight = resolution.Height - (resolution.Height * (scale - 1));
            }
            else
            {
                screenheight = resolution.Height - (resolution.Height * (1.75 - 1));
            }

            if (screenheight < 1000 && screenheight > 850)
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.9f);
            }
            else if (screenheight < 850 && screenheight > 700)
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.85f);
            }
            else if (screenheight < 700 && screenheight > 450)
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.75f);
            }
            else if (screenheight < 450 )
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.65f);
            }



        }
    }
}
