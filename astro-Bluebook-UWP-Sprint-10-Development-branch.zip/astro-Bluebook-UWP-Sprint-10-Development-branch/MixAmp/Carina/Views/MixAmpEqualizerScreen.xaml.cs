﻿using MixAmp.Common.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Carina.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MixAmpEqualizerScreen : Page
    {
        public MixAmpEqualizerScreen()
        {
            this.InitializeComponent();
            EqualizerProfileList.ItemsSource = new EqualizerProfiles();
            this.DataContext = this;
            Size ScreenSize = this.GetScreenResolution();
            double ScreenHeight = this.GetScreenHeight(ScreenSize);
            double ScreenWidth = this.GetScreenWidth(ScreenSize);
            this.SetMaximumListHeight(ScreenHeight);
        }

        private Size GetScreenResolution()
        {
            var bounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            Size size = new Size(bounds.Width * scaleFactor, bounds.Height * scaleFactor);
            return size;
        }

        private double GetScreenHeight(Size size)
        {
            return size.Height;
        }

        private double GetScreenWidth(Size size)
        {
            return size.Width;
        }

        private void SetMaximumListHeight(double screenHeight)
        {
            if (screenHeight >= 640 && screenHeight < 768)
            {
                double ListHeight = (screenHeight * 0.3);
                EqualizerProfileList.MaxHeight = ListHeight;
            }
            else if (screenHeight >= 768 && screenHeight <= 1080)
            {
                double ListHeight = (screenHeight * 0.33);
                EqualizerProfileList.MaxHeight = ListHeight;
            }
            else if (screenHeight > 1080)
            {
                double ListHeight = (screenHeight * 0.45);
                EqualizerProfileList.MaxHeight = ListHeight;
            }
        }

        //private void Arrow_Right_Tapped(object sender, TappedRoutedEventArgs e)
        //{
        //    try
        //    {
        //        Frame parentFrame = Window.Current.Content as Frame;
        //        parentFrame.Navigate(typeof(TabHeader));
        //    }
        //    catch (Exception ex)
        //    {
        //    }
        //}

        private void Arrow_Right_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            EqualizerProfileViewModel EqualizerProfileViewModel = button.DataContext as EqualizerProfileViewModel;
            //if (EqualizerProfileViewModel.Name.Equals("Stream Mic"))
            //{
            this.Visibility = Visibility.Collapsed;
            RelativePanel relativePanel = this.Parent as RelativePanel;
            MixAmpOutputSourcesScreen mixAmpOutputSourcesScreen = relativePanel.FindName("MixAmpOutputSourcesScreen") as MixAmpOutputSourcesScreen;
            var outputsource = mixAmpOutputSourcesScreen.FindName("outputsources") as TextBlock;
            outputsource.Text = EqualizerProfileViewModel.Name;
            mixAmpOutputSourcesScreen.Visibility = Visibility.Visible;
            //}
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                Frame parentFrame = Window.Current.Content as Frame;
                parentFrame.Navigate(typeof(TabHeader));
            }
            catch (Exception ex)
            {


            }
        }
    }
}

