﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Carina.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class CarinaPresetScreen : Page
    {
        Windows.Storage.ApplicationDataContainer BezierSettings =
    Windows.Storage.ApplicationData.Current.LocalSettings;
        public CarinaPresetScreen()
        {
            this.InitializeComponent();
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            var size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            //scrlist.Height = size.Height - 260;
        }

        private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            this.Visibility = Visibility.Collapsed;
            RelativePanel relativePanel = this.Parent as RelativePanel;
            MixAmpOutputSourcesScreen MixAmpOutputSourcesScreen = relativePanel.FindName("MixAmpOutputSourcesScreen") as MixAmpOutputSourcesScreen;
            MixAmpOutputSourcesScreen.Visibility = Visibility.Visible;
            var textname = MixAmpOutputSourcesScreen.FindName("outputsources") as TextBlock;
            if (PresetName.Text == "Custom")
            {
                Windows.Storage.ApplicationDataCompositeValue BezierValues =
    new Windows.Storage.ApplicationDataCompositeValue();
                var Slider1 = bezierCurve.FindName("MySlider") as Slider;
                var Slider2 = bezierCurve.FindName("MySlider2") as Slider;
                var Slider3 = bezierCurve.FindName("MySlider3") as Slider;
                var Slider4 = bezierCurve.FindName("MySlider4") as Slider;
                var Slider5 = bezierCurve.FindName("MySlider5") as Slider;
                BezierValues["sliderOne"] = (int)Slider1.Value;
                BezierValues["sliderTwo"] = (int)Slider2.Value;
                BezierValues["sliderThree"] = (int)Slider3.Value;
                BezierValues["sliderFour"] = (int)Slider4.Value;
                BezierValues["sliderFive"] = (int)Slider5.Value;
                BezierSettings.Values["Carina " + textname.Text + "-BezierValues"] = BezierValues;
            }
        }
    }
}
