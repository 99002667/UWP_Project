﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MixAmp.Carina.ViewModels
{
    public class TakeTheTourViewModel
    {
        public string Image { get; set; }
        public string TextHeading { get; set; }
        public string TextContent { get; set; }
    }
}
