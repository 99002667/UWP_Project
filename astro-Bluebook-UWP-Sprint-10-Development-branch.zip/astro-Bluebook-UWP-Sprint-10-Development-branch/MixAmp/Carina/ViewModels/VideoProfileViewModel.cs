﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using System.Collections.ObjectModel;

namespace MixAmp.Carina.ViewModels
{
   public class VideoProfileViewModel
    {
        public string Name { get; set; }
        public ImageSource Icon { get; set; }
        public double IconWidth { get; set; }
        public double IconHeight { get; set; }
        public string Status { get; set; }
        public Visibility FortyEightV_Visibility { get; set; }
        public bool Is_Xbox { get; set; }
        public Visibility Video_Status_Visibility { get; set; }
        public Thickness IconMargin { get; set; }


        public VideoProfileViewModel(string Name, ImageSource Icon, double IconWidth, double IconHeight, string Status, Visibility FortyEightV_Visibility, bool Is_XBox, Visibility Video_Status_Visibility, Thickness IconMargin)
        {
            this.Name = Name;
            this.Icon = Icon;
            this.IconWidth = IconWidth;
            this.IconHeight = IconHeight;
            this.Status = Status;
            this.FortyEightV_Visibility = FortyEightV_Visibility;
            this.Is_Xbox = Is_XBox;
            this.Video_Status_Visibility = Video_Status_Visibility;
            this.IconMargin = IconMargin;
        }
    }

    public class VideoProfiles : ObservableCollection<VideoProfileViewModel>
    {
        public VideoProfiles()
        {
            Add(new VideoProfileViewModel("Xbox", GetProfileIcon("Xbox"), 32, 32, "Active Profile", Visibility.Visible, true, Visibility.Visible, new Thickness(0, 15, 0, 0)));
            Add(new VideoProfileViewModel("Resoultion/FPS", GetProfileIcon("Resolution/FPS"), 24, 24, "1080p - 60 FPS", Visibility.Collapsed, false, Visibility.Collapsed, new Thickness(5, 15, 0, 0)));
            Add(new VideoProfileViewModel("Video Format", GetProfileIcon("Video Format"), 24, 24, "MP4", Visibility.Collapsed, false, Visibility.Collapsed, new Thickness(5, 15, 0, 0)));
        }

        private ImageSource GetProfileIcon(string profileName)
        {
            Image image = new Image();

            if (profileName == "Xbox")
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Profile.png"));
            }
            else if (profileName.Equals("Resolution/FPS"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/MDI_Slow_Motion_Video.png"));
                image.Width = 24;
                image.Height = 24;
            }
            else if (profileName.Equals("Video Format"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/MDI_Slow_Motion_Video.png"));
                image.Width = 24;
                image.Height = 24;
            }
            return image.Source;
        }
    }
}
