﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;
using Windows.UI;
using System.Data;
using DataAccessLibrary;
using Microsoft.Data.Sqlite;

namespace MixAmp.Carina.ViewModels
{
    public class ProfileViewModel
    {
        public string Name { get; set; }
        public string Status { get; set; }
        public bool Is_Selected { get; set; }
        public Visibility FortyEightV_Visibility { get; set; }
        public Windows.UI.Xaml.Media.SolidColorBrush TextColor { get; set; }
        public Visibility SideBorderVisibility { get; set; }

        public bool Is_New { get; set; }
        public bool Is_Duplicate { get; set; }

        public ProfileViewModel(string Name, string Status, bool Is_Selected, Visibility FortyEightV_Visibility, Visibility SideBorderVisibility, SolidColorBrush TextColor, bool Is_New, bool Is_Duplicate)
        {
            this.Name = Name;
            this.Status = Status;
            this.Is_Selected = Is_Selected;
            this.FortyEightV_Visibility = FortyEightV_Visibility;
            this.SideBorderVisibility = SideBorderVisibility;
            this.TextColor = TextColor;
            this.Is_New = Is_New;
            this.Is_Duplicate = Is_Duplicate;
        }
    }

    public class Profiles : ObservableCollection<ProfileViewModel>
    {
        public Profiles()
        {
            //        //Add(new ProfileViewModel("Xbox", "Active Profile", true, true, new SolidColorBrush(Colors.FromArgb(255,255,4,255))));
            //        Add(new ProfileViewModel("Xbox", "Active Profile", true, Visibility.Visible, Visibility.Visible, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false));
            //        Add(new ProfileViewModel("PC", "Inactive Profile", false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Colors.Gray), false, false));
            //        Add(new ProfileViewModel("Stream", "Inactive Profile", false, Visibility.Visible, Visibility.Collapsed, new SolidColorBrush(Colors.Gray), false, false));
            //        Add(new ProfileViewModel("Tournament", "Inactive Profile", false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Colors.Gray), false, false));
            //    }
            //}
            DataSet ds = new DataSet();
            string query = "SELECT* from tblProfile";
            ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            bool val = Convert.ToBoolean(tb.Rows[0]["isSelected"]);
            bool val1 = Convert.ToBoolean(tb.Rows[1]["isSelected"]);
            bool val2 = Convert.ToBoolean(tb.Rows[2]["isSelected"]);
            bool val3 = Convert.ToBoolean(tb.Rows[3]["isSelected"]);

            string status1 = Convert.ToString(tb.Rows[0]["profileStatus"]);
            string status2 = Convert.ToString(tb.Rows[1]["profileStatus"]);
            string status3 = Convert.ToString(tb.Rows[2]["profileStatus"]);
            string status4 = Convert.ToString(tb.Rows[3]["profileStatus"]);


            Add(new ProfileViewModel("Xbox", status1, val, Visibility.Visible, GetVisibility("Xbox"), GetColor("Xbox"), false, false));
            Add(new ProfileViewModel("PC", status2, val1, Visibility.Collapsed, GetVisibility("PC"), GetColor("PC"), false, false));
            Add(new ProfileViewModel("Stream", status3, val2, Visibility.Visible, GetVisibility("Stream"), GetColor("Stream"), false, false));
            Add(new ProfileViewModel("Tournament", status4, val3, Visibility.Collapsed, GetVisibility("Tournament"), GetColor("Tournament"), false, false));
            AddAdditionaldataifthereany();
        }



        private SolidColorBrush GetColor(string name)
        {
            DataSet ds = new DataSet();
            string queryCarina = "SELECT* from tblProfile";
            ds = DataAccess.GetData(queryCarina);
            var tbCarina = ds.Tables[0];
            bool val = false;
            if (name == "Xbox")
            {
                val = Convert.ToBoolean(tbCarina.Rows[0]["isSelected"]);
            }
            else if (name == "PC")
            {
                val = Convert.ToBoolean(tbCarina.Rows[1]["isSelected"]);
            }
            else if (name == "Stream")
            {
                val = Convert.ToBoolean(tbCarina.Rows[2]["isSelected"]);
            }
            else if (name == "Tournament")
            {
                val = Convert.ToBoolean(tbCarina.Rows[3]["isSelected"]);
            }
            SolidColorBrush newcolor;
            if (val == true)
            {
                newcolor = new SolidColorBrush(Color.FromArgb(255, 255, 54, 0));
                return newcolor;
            }
            else
            {
                newcolor = new SolidColorBrush(Colors.Gray);
                return newcolor;

            }
        }

        private Visibility GetVisibility(string name)
        {
            DataSet ds = new DataSet();
            string queryCarina = "SELECT* from tblProfile";
            ds = DataAccess.GetData(queryCarina);
            var tbCarina = ds.Tables[0];
            bool val = false;
            if (name == "Xbox")
            {
                val = Convert.ToBoolean(tbCarina.Rows[0]["isSelected"]);
            }
            else if (name == "PC")
            {
                val = Convert.ToBoolean(tbCarina.Rows[1]["isSelected"]);
            }
            else if (name == "Stream")
            {
                val = Convert.ToBoolean(tbCarina.Rows[2]["isSelected"]);
            }
            else if (name == "Tournament")
            {
                val = Convert.ToBoolean(tbCarina.Rows[3]["isSelected"]);
            }

            if (val == true)
            {
                return Visibility.Visible;
            }
            else
            {
                return Visibility.Collapsed;
            }
        }

        private void AddAdditionaldataifthereany()
        {
            DataSet ds = new DataSet();
            string queryCarina = "SELECT* from tblProfile";
            ds = DataAccess.GetData(queryCarina);
            var tbCarina = ds.Tables[0];
            var rowCarina = tbCarina.Rows.Count;
            if (rowCarina > 4)
            {
                for (int i = 4; i < rowCarina; i++)
                {
                    string name = (string)tbCarina.Rows[i]["profileName"];
                    string status = (string)tbCarina.Rows[i]["profileStatus"];
                    bool visibilityStatus = Convert.ToBoolean(tbCarina.Rows[i]["fourtyEightVisibility"]);
                    bool SideBar = Convert.ToBoolean(tbCarina.Rows[i]["SideBarVisibility"]);
                    bool isSelect = Convert.ToBoolean(tbCarina.Rows[i]["isSelected"]);
                    Visibility visibleStat;
                    if (visibilityStatus == true)
                    {
                        visibleStat = Visibility.Visible;
                    }
                    else
                    {
                        visibleStat = Visibility.Collapsed;
                    }
                    Visibility sidebar_Vis;
                    if (isSelect == true)
                    {
                        sidebar_Vis = Visibility.Visible;
                    }
                    else
                    {
                        sidebar_Vis = Visibility.Collapsed;
                    }
                    SolidColorBrush newcolor;
                    if (isSelect == true)
                    {
                        newcolor = new SolidColorBrush(Color.FromArgb(255, 255, 54, 0));
                    }
                    else
                    {
                        newcolor = new SolidColorBrush(Colors.Gray);
                    }
                    //bool isSelect = Convert.ToBoolean(tbCarina.Rows[i]["isSelected"]);
                    bool isnew = Convert.ToBoolean(tbCarina.Rows[i]["isNew"]);
                    bool isDuplicate = Convert.ToBoolean(tbCarina.Rows[i]["isDuplicate"]);

                    Add(new ProfileViewModel(name, status, isSelect, visibleStat, sidebar_Vis, newcolor, isnew, isDuplicate));
                }

            }

        }
    }

    public static class ProfileScreenListData
    {
        public static void InitializeProfileScreenListData()
        {
            //Profile MixAmp//
            DataSet dataSetProfiles = new DataSet();
            string queryProfiles = "SELECT* from tblProfile";
            dataSetProfiles = DataAccess.GetData(queryProfiles);
            var tablesProfiles = dataSetProfiles.Tables[0];
            var rowProfiles = tablesProfiles.Rows.Count;
            var columnsProfiles = tablesProfiles.Columns.Count;


            if (rowProfiles == 0)
            {
                for (int i = 0; i < 4; i++)
                {
                    if (i == 0)
                    {
                        SqliteCommand insertCommand = new SqliteCommand();
                        insertCommand.CommandText = " INSERT INTO tblProfile VALUES(@profileName, @profileStatus, @isSelected, @fourtyEightVisibility, @SideBarVisibility, @textColor, @isNew, @isDuplicate)";
                        insertCommand.Parameters.AddWithValue("@profileName", "Xbox");
                        insertCommand.Parameters.AddWithValue("@profileStatus", "Active Profile");
                        insertCommand.Parameters.AddWithValue("@isSelected", true);
                        insertCommand.Parameters.AddWithValue("@fourtyEightVisibility", true);
                        insertCommand.Parameters.AddWithValue("@SideBarVisibility", true);
                        insertCommand.Parameters.AddWithValue("@textColor", "OrangeRed");
                        insertCommand.Parameters.AddWithValue("@isNew", false);
                        insertCommand.Parameters.AddWithValue("@isDuplicate", false);
                        DataAccess.InsertData(insertCommand);
                    }
                    else if (i == 1)
                    {
                        SqliteCommand insertCommand = new SqliteCommand();
                        insertCommand.CommandText = " INSERT INTO tblProfile VALUES(@profileName, @profileStatus, @isSelected, @fourtyEightVisibility, @SideBarVisibility, @textColor, @isNew, @isDuplicate)";
                        insertCommand.Parameters.AddWithValue("@profileName", "PC");
                        insertCommand.Parameters.AddWithValue("@profileStatus", "Inactive Profile");
                        insertCommand.Parameters.AddWithValue("@isSelected", false);
                        insertCommand.Parameters.AddWithValue("@fourtyEightVisibility", false);
                        insertCommand.Parameters.AddWithValue("@SideBarVisibility", false);
                        insertCommand.Parameters.AddWithValue("@textColor", "Gray");
                        insertCommand.Parameters.AddWithValue("@isNew", false);
                        insertCommand.Parameters.AddWithValue("@isDuplicate", false);
                        DataAccess.InsertData(insertCommand);
                    }
                    else if (i == 2)
                    {
                        SqliteCommand insertCommand = new SqliteCommand();
                        insertCommand.CommandText = " INSERT INTO tblProfile VALUES(@profileName, @profileStatus, @isSelected, @fourtyEightVisibility, @SideBarVisibility, @textColor, @isNew, @isDuplicate)";
                        insertCommand.Parameters.AddWithValue("@profileName", "Stream");
                        insertCommand.Parameters.AddWithValue("@profileStatus", "Inactive Profile");
                        insertCommand.Parameters.AddWithValue("@isSelected", false);
                        insertCommand.Parameters.AddWithValue("@fourtyEightVisibility", true);
                        insertCommand.Parameters.AddWithValue("@SideBarVisibility", false);
                        insertCommand.Parameters.AddWithValue("@textColor", "Gray");
                        insertCommand.Parameters.AddWithValue("@isNew", false);
                        insertCommand.Parameters.AddWithValue("@isDuplicate", false);
                        DataAccess.InsertData(insertCommand);

                    }
                    else if (i == 3)
                    {
                        SqliteCommand insertCommand = new SqliteCommand();
                        insertCommand.CommandText = " INSERT INTO tblProfile VALUES(@profileName, @profileStatus, @isSelected, @fourtyEightVisibility, @SideBarVisibility, @textColor, @isNew, @isDuplicate)";
                        insertCommand.Parameters.AddWithValue("@profileName", "Tournament");
                        insertCommand.Parameters.AddWithValue("@profileStatus", "Inactive Profile");
                        insertCommand.Parameters.AddWithValue("@isSelected", false);
                        insertCommand.Parameters.AddWithValue("@fourtyEightVisibility", false);
                        insertCommand.Parameters.AddWithValue("@SideBarVisibility", false);
                        insertCommand.Parameters.AddWithValue("@textColor", "Gray");
                        insertCommand.Parameters.AddWithValue("@isNew", false);
                        insertCommand.Parameters.AddWithValue("@isDuplicate", false);
                        DataAccess.InsertData(insertCommand);
                    }

                }

            }
            //Profile MixAmp//


        }

        public static void InsertData(string Name, string status, bool isselect, bool VisibilityStatus, bool SidebarVisibility, string color, bool isnew, bool isduplicate)
        {
            SqliteCommand insertCommand = new SqliteCommand();
            insertCommand.CommandText = " INSERT INTO tblProfile VALUES(@profileName, @profileStatus, @isSelected, @fourtyEightVisibility, @SideBarVisibility, @textColor, @isNew, @isDuplicate)";

            insertCommand.Parameters.AddWithValue("@profileName", Name);
            insertCommand.Parameters.AddWithValue("@profileStatus", status);
            insertCommand.Parameters.AddWithValue("@isSelected", isselect);
            insertCommand.Parameters.AddWithValue("@fourtyEightVisibility", VisibilityStatus);
            insertCommand.Parameters.AddWithValue("@SideBarVisibility", SidebarVisibility);
            insertCommand.Parameters.AddWithValue("@textColor", "Gray");
            insertCommand.Parameters.AddWithValue("@isNew", isnew);
            insertCommand.Parameters.AddWithValue("@isDuplicate", isduplicate);
            DataAccess.InsertData(insertCommand);
        }

        public static void UpdateStatus(string Name, string status, bool SidebarVis, bool isselect, string color)
        {
            SqliteCommand UpdateCommand = new SqliteCommand();
            UpdateCommand.CommandText = "update tblProfile set profileStatus = :info, isSelected = :select, SideBarVisibility = :vis, textColor = :color where profileName = :Name";
            UpdateCommand.Parameters.AddWithValue("info", status);
            UpdateCommand.Parameters.AddWithValue("Name", Name);
            UpdateCommand.Parameters.AddWithValue("select", isselect);
            UpdateCommand.Parameters.AddWithValue("vis", SidebarVis);
            UpdateCommand.Parameters.AddWithValue("color", color);
            DataAccess.UpdateRecord(UpdateCommand);
        }

        public static void DeleteRecords(string Name)
        {
            SqliteCommand DeleteCommand = new SqliteCommand();
            DeleteCommand.CommandText = "DELETE FROM tblProfile WHERE profileName = :Name";
            DeleteCommand.Parameters.AddWithValue("Name", Name);
            DataAccess.DeleteRecord(DeleteCommand);
        }

        public static DataTable GetData()
        {
            DataSet ds = new DataSet();
            string queryCarina = "SELECT* from tblProfile";
            ds = DataAccess.GetData(queryCarina);
            DataTable tbCarina = ds.Tables[0];
            return tbCarina;
        }

        public static void UpdateName(string oldName, string newName)
        {
            SqliteCommand UpdateCommand = new SqliteCommand();
            UpdateCommand.CommandText = "update tblProfile set profileName = :newName where profileName = :oldName";

            UpdateCommand.Parameters.AddWithValue("oldName", oldName);
            UpdateCommand.Parameters.AddWithValue("newName", newName);

            DataAccess.UpdateRecord(UpdateCommand);
        }
    }
}
