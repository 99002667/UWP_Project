﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MixAmp.Common.ViewModels;

namespace MixAmp.Carina.ViewModels
{
    public class MixAmpMixerViewModel : INotifiBaseCls
    {
        public MixerViewModel MixerViewModel { get; set; }
        public MixAmpMixerViewModel()
        {
            MixerViewModel = new MixerViewModel();
        }

    }
}
