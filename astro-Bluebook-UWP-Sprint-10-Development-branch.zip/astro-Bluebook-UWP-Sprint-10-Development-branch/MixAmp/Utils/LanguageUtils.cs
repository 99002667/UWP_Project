﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Globalization;

namespace MixAmp.Utils
{
    public class LanguageUtils
    {
        public static string LoadUserPreferredSystemLanguage()
        {
            string UserPreferredSystemLanguage = Windows.System.UserProfile.GlobalizationPreferences.Languages[0];
            if (UserPreferredSystemLanguage.Equals(Constants.ISO_ARABIC))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_ARABIC);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_BULGARIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_BULGARIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_CZECH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_CZECH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_DANISH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_DANISH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_GERMAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_GERMAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_ENGLISH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_ENGLISH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_SPANISH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_SPANISH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_ESTONIA))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_ESTONIA);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_FINNISH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_FINNISH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_FRENCH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_FRENCH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_CROATIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_CROATIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_HUNGARIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_HUNGARIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_INDONESIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_INDONESIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_ITALIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_ITALIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_JAPANESE))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_JAPANESE);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_KOREAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_KOREAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_LITHUANIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_LITHUANIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_LATVIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_LATVIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_DUTCH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_DUTCH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_NORWEGIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_NORWEGIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_ROMANIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_ROMANIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_RUSSIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_RUSSIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_SLOVAK))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_SLOVAK);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_SLOVENIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_SLOVENIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_SWEDEN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_SWEDEN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_THAI))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_THAI);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_TURKISH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_TURKISH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_UKRAINIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_UKRAINIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_VIETNAMESE))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_VIETNAMESE);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            return UserPreferredSystemLanguage;
        }

        public static void LoadUserPreferredApplicationLanguage(string LanguageName)
        {
            if (LanguageName.Equals(Constants.ENGLISH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_ENGLISH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.FRENCH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_FRENCH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.CHINESE_SIMPLIFIED))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_CHINESE_SIMPLIFIED);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.CHINESE_TRADITIONAL))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_CHINESE_TRADITIONAL);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.ARABIC))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_ARABIC);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.DANISH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_DANISH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.GERMAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_GERMAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.ENGLISH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_ENGLISH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.SPANISH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_SPANISH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.ESTONIA))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_ESTONIA);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.FINNISH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_FINNISH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.FRENCH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_FRENCH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.CROATIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_CROATIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.HUNGARIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_HUNGARIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.INDONESIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_INDONESIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.ITALIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_ITALIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.JAPANESE))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_JAPANESE);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.KOREAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_KOREAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.LITHUANIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_LITHUANIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.LATVIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_LATVIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.DUTCH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_DUTCH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.NORWEGIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_NORWEGIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.ROMANIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_ROMANIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.RUSSIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_RUSSIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.SLOVAK))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_SLOVAK);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.SLOVENIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_SLOVENIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.SWEDEN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_SWEDEN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.THAI))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_THAI);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.TURKISH))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_TURKISH);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.UKRAINIAN))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_UKRAINIAN);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
            else if (LanguageName.Equals(Constants.VIETNAMESE))
            {
                var Culture = new System.Globalization.CultureInfo(Constants.ISO_VIETNAMESE);
                ApplicationLanguages.PrimaryLanguageOverride = Culture.Name;
            }
        }

        public static void CheckUserPreferredLanguage()
        {
            string LanguageName = LanguageSettingsUtils.ReadLanguageSettings();

            if (LanguageName == null)
            {
                LoadUserPreferredSystemLanguage();
            }
            else
            {
                LoadUserPreferredApplicationLanguage(LanguageName);
            }
        }

        public static string GetLanguageName()
        {
            string LanguageName = LanguageSettingsUtils.ReadLanguageSettings();

            if (LanguageName == null)
            {
                return GetSystemLanguageName();
            }
            else
            {
                return LanguageName;
            }
        }

        public static string GetSystemLanguageName()
        {
            string UserPreferredSystemLanguage = LoadUserPreferredSystemLanguage();

            if (UserPreferredSystemLanguage.Equals(Constants.ISO_ARABIC))
            {
                return Constants.ARABIC;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_BULGARIAN))
            {
                return Constants.BULGARIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_CZECH))
            {
                return Constants.CZECH;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_DANISH))
            {
                return Constants.DANISH;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_GERMAN))
            {
                return Constants.GERMAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_ENGLISH))
            {
                return Constants.ENGLISH;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_SPANISH))
            {
                return Constants.SPANISH;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_ESTONIA))
            {
                return Constants.ESTONIA;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_FINNISH))
            {
                return Constants.FINNISH;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_FRENCH))
            {
                return Constants.FRENCH;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_CROATIAN))
            {
                return Constants.CROATIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_HUNGARIAN))
            {
                return Constants.HUNGARIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_INDONESIAN))
            {
                return Constants.INDONESIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_ITALIAN))
            {
                return Constants.ITALIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_JAPANESE))
            {
                return Constants.JAPANESE;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_KOREAN))
            {
                return Constants.KOREAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_LITHUANIAN))
            {
                return Constants.LITHUANIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_LATVIAN))
            {
                return Constants.LATVIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_DUTCH))
            {
                return Constants.DUTCH;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_NORWEGIAN))
            {
                return Constants.NORWEGIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_ROMANIAN))
            {
                return Constants.ROMANIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_RUSSIAN))
            {
                return Constants.RUSSIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_SLOVAK))
            {
                return Constants.SLOVAK;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_SLOVENIAN))
            {
                return Constants.SLOVENIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_SWEDEN))
            {
                return Constants.SWEDEN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_THAI))
            {
                return Constants.THAI;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_TURKISH))
            {
                return Constants.TURKISH;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_UKRAINIAN))
            {
                return Constants.UKRAINIAN;
            }
            else if (UserPreferredSystemLanguage.Equals(Constants.ISO_VIETNAMESE))
            {
                return Constants.VIETNAMESE;
            }
            else
            {
                return Constants.ENGLISH;
            }
        }
    }
}
