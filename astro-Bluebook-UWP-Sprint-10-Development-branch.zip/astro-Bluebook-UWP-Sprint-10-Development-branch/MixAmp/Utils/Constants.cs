﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MixAmp.Utils
{
    public class Constants
    {
        //public const string ARABIC = "ar-AE";
        //public const string BULGARIAN = "bg-BG";
        //public const string CZECH = "cs-CZ";
        //public const string DANISH = "da-DK";
        //public const string GERMAN = "de-DE";
        //public const string ENGLISH = "en-US";
        //public const string SPANISH = "es-ES";
        //public const string ESTONIA = "et-ET";
        //public const string FINNISH = "fi-FI";
        //public const string FRENCH = "fr-FR";
        //public const string CROATIAN = "hr-HR";
        //public const string HUNGARIAN = "hu-HU";
        //public const string INDONESIAN = "id-ID";
        //public const string ITALIAN = "it-IT";
        //public const string JAPANESE = "ja-JP";
        //public const string KOREAN = "ko-KR";
        //public const string LITHUANIAN = "lt-LT";
        //public const string LATVIAN = "lv-LV";
        //public const string DUTCH = "nl-NL";
        //public const string NORWEGIAN = "no-NO";
        //public const string ROMANIAN = "ro-RO";
        //public const string RUSSIAN = "ru-RU";
        //public const string SLOVAK = "sk-SK";
        //public const string SLOVENIAN = "sl-SI";
        //public const string SWEDEN = "sv-SE";
        //public const string THAI = "th-TH";
        //public const string TURKISH = "tr-TR";
        //public const string UKRAINIAN = "uk-UA";
        //public const string VIETNAMESE = "vi-VA";
        public const string ISO_ARABIC = "ar-AE";
        public const string ISO_BULGARIAN = "bg-BG";
        public const string ISO_CZECH = "cs-CZ";
        public const string ISO_CHINESE_TRADITIONAL = "zh-hant-CN";
        public const string ISO_CHINESE_SIMPLIFIED = "zh-hans-CN";
        public const string ISO_DANISH = "da-DK";
        public const string ISO_GERMAN = "de-DE";
        public const string ISO_ENGLISH = "en-US";
        public const string ISO_SPANISH = "es-ES";
        public const string ISO_ESTONIA = "et-ET";
        public const string ISO_FINNISH = "fi-FI";
        public const string ISO_FRENCH = "fr-FR";
        public const string ISO_PORTUGUESE = "pt-PT";
        public const string ISO_CROATIAN = "hr-HR";
        public const string ISO_HUNGARIAN = "hu-HU";
        public const string ISO_INDONESIAN = "id-ID";
        public const string ISO_ITALIAN = "it-IT";
        public const string ISO_JAPANESE = "ja-JP";
        public const string ISO_KOREAN = "ko-KR";
        public const string ISO_LITHUANIAN = "lt-LT";
        public const string ISO_LATVIAN = "lv-LV";
        public const string ISO_DUTCH = "nl-NL";
        public const string ISO_NORWEGIAN = "no-NO";
        public const string ISO_ROMANIAN = "ro-RO";
        public const string ISO_RUSSIAN = "ru-RU";
        public const string ISO_SLOVAK = "sk-SK";
        public const string ISO_SLOVENIAN = "sl-SI";
        public const string ISO_SWEDEN = "sv-SE";
        public const string ISO_THAI = "th-TH";
        public const string ISO_TURKISH = "tr-TR";
        public const string ISO_UKRAINIAN = "uk-UA";
        public const string ISO_VIETNAMESE = "vi-VA";

        public const string ARABIC = "Arabic";
        public const string BULGARIAN = "Bulgarian";
        public const string CZECH = "Czech";
        public const string CHINESE_TRADITIONAL = "Chinese (traditional)";
        public const string CHINESE_SIMPLIFIED = "Chinese (simplified)";
        public const string DANISH = "Danish";
        public const string GERMAN = "German";
        public const string ENGLISH = "English";
        public const string SPANISH = "Spanish";
        public const string ESTONIA = "Estonia";
        public const string FINNISH = "Finnish";
        public const string FRENCH = "French";
        public const string CROATIAN = "Croatian";
        public const string HUNGARIAN = "Hungarian";
        public const string INDONESIAN = "Indonesian";
        public const string ITALIAN = "Italian";
        public const string JAPANESE = "Japanese";
        public const string KOREAN = "Korean";
        public const string LITHUANIAN = "Lithuanian";
        public const string LATVIAN = "Latvian";
        public const string PORTUGUESE = "Portuguese";
        public const string DUTCH = "Dutch";
        public const string NORWEGIAN = "Norvegian";
        public const string ROMANIAN = "Romanian";
        public const string RUSSIAN = "Russian";
        public const string SLOVAK = "Slovak";
        public const string SLOVENIAN = "Slovenian";
        public const string SWEDEN = "Sweden";
        public const string THAI = "Thai";
        public const string TURKISH = "Turkish";
        public const string UKRAINIAN = "Ukrainian";
        public const string VIETNAMESE = "Vietnamese";

        public const string EMPTY_STRING = "";

        public const string CARINA = "Carina";
        public const string LANGUAGE_NAME = "Language_Name";

        public const string BOONTA_EVE = "BoontaEve";

        public const string CARBONITE = "Carbonite";
    }
}
