﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace MixAmp.Utils
{
    public class LanguageSettingsUtils
    {
        public static string ReadLanguageSettings()
        {
            ApplicationDataContainer LocalSettings = Windows.Storage.ApplicationData.Current.LocalSettings;
            string LocalValue = LocalSettings.Values[Constants.LANGUAGE_NAME] as string;
            return LocalValue;
        }

        public static void WriteLanguageSettings(string LanguageName)
        {
            ApplicationDataContainer LocalSettings = Windows.Storage.ApplicationData.Current.LocalSettings;
            LocalSettings.Values[Constants.LANGUAGE_NAME] = LanguageName;
        }

        public static void DeleteLanguageSettings()
        {
            ApplicationData.Current.LocalSettings.Values.Remove(Constants.LANGUAGE_NAME);
            ApplicationData.Current.LocalSettings.Values.Clear();
        }
    }
}
