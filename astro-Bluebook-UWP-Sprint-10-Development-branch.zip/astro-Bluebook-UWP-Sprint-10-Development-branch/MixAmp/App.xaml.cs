﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using static MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel;
using Microsoft.Identity.Client;
using System.Collections.ObjectModel;
using static MixAmp.BoontaEve.ViewModels.BoontaEveDaisyChainBaseScreenLeftPanelVM;
using DataAccessLibrary;
using MixAmp.BoontaEve.ViewModels;
using System.Data;
using MixAmp.Common.ViewModels;
using MixAmp.Carbonite.ViewModels;
using MixAmp.Carina.ViewModels;

namespace MixAmp
{
    /// <summary>
    /// Provides application-specific behavior to supplement the default Application class.
    /// </summary>
    sealed partial class App : Application
    {
        public static TeamUsers teamuser { get; set; }
        public static TeamUsers NonHostUsers { get; set; }
        public static Chain ChainList { get; set; }
        public static NewChain NewChainList { get; set; }
        public static NonhostChangeSetting NonHostList { get; set; }
        public static int selectedChainID { get; set; }
        public static int loggedInUser { get; set; }
        /// <summary>
        /// Initializes the singleton application object.  This is the first line of authored code
        /// executed, and as such is the logical equivalent of main() or WinMain().
        /// </summary>
        public App()
        {
            this.InitializeComponent();
            AppCenter.Start("df4cf793-71ba-4be4-a7b8-10df5904dbd0",
                   typeof(Analytics), typeof(Crashes));
            this.Suspending += OnSuspending;
            BoontaEveDaisyChainCommonViewModel vm = new BoontaEveDaisyChainCommonViewModel();
            DaisyChainStaticCls.CreateDaisyChainTable();
            DeviceSpecificDataViewModel.InitialiseDeviceSpecificSettings();
            ProfileScreenListData.InitializeProfileScreenListData();
            //AstroDeviceSpecificDataViewModel.InitializeDeviceSpecificSettings();
            //BoontaEveDeviceSpecificDataViewModel.InitializeDeviceSpecificSettings();
            DataSet ds = new DataSet();
            //BoontaEveDaisyChainCommonViewModel vm = new BoontaEveDaisyChainCommonViewModel();
            ds = vm.GetChainRecord();
            if (ds.Tables[0].Rows.Count == 0)
            {
                SaveChainRecord();
            }
            ds = vm.GetUserRecord();
            if (ds.Tables[0].Rows.Count == 0)
            {
                SaveUserRecord();
            }

            teamuser = new TeamUsers();
            ChainList = new Chain();
            NewChainList = new NewChain();
            NonHostList = new NonhostChangeSetting();

        }

        /// <summary>
        /// Invoked when the application is launched normally by the end user.  Other entry points
        /// will be used such as when the application is launched to open a specific file.
        /// </summary>
        /// <param name="e">Details about the launch request and process.</param>
        protected override void OnLaunched(LaunchActivatedEventArgs e)
        {
            Frame rootFrame = Window.Current.Content as Frame;
            try
            {
                //Frame rootFrame = Window.Current.Content as Frame;
                // Do not repeat app initialization when the Window already has content,
                // just ensure that the window is active
                if (rootFrame == null)
                {
                    // Create a Frame to act as the navigation context and navigate to the first page
                    rootFrame = new Frame();
                    rootFrame.NavigationFailed += OnNavigationFailed;
                    if (e.PreviousExecutionState == ApplicationExecutionState.Terminated)
                    {
                        //TODO: Load state from previously suspended application
                    }
                    // Place the frame in the current Window
                    Window.Current.Content = rootFrame;
                }
                if (e.PrelaunchActivated == false)
                {
                    if (rootFrame.Content == null)
                    {
                        // When the navigation stack isn't restored navigate to the first page,
                        // configuring the new page by passing required information as a navigation
                        // parameter
                        rootFrame.Navigate(typeof(MainPage), e.Arguments);
                    }
                    // Ensure the current window is active
                    Window.Current.Activate();
                }
            }
            catch (Exception ex)
            {
                ErrorAttachmentLog.AttachmentWithText(ex.Message, ex.StackTrace.ToString());
                throw;
                //rootFrame.Navigate(typeof(MainPage), e.Arguments);
            }
        }
        /// <summary>
        /// Invoked when Navigation to a certain page fails
        /// </summary>
        /// <param name="sender">The Frame which failed navigation</param>
        /// <param name="e">Details about the navigation failure</param>
        void OnNavigationFailed(object sender, NavigationFailedEventArgs e)
        {
            throw new Exception("Failed to load Page " + e.SourcePageType.FullName);
            //throw new Exception(sender.ToString() + e.SourcePageType.FullName);
        }
        /// <summary>
        /// Invoked when application execution is being suspended.  Application state is saved
        /// without knowing whether the application will be terminated or resumed with the contents
        /// of memory still intact.
        /// </summary>
        /// <param name="sender">The source of the suspend request.</param>
        /// <param name="e">Details about the suspend request.</param>
        private void OnSuspending(object sender, SuspendingEventArgs e)
        {
            var deferral = e.SuspendingOperation.GetDeferral();
            ErrorAttachmentLog.AttachmentWithText(e.ToString(), "Suspended");
            //TODO: Save application state and stop any background activity
            deferral.Complete();
        }
        public void SaveChainRecord()
        {
            DaisyChainStaticCls.SaveChainDetails(1, "Team Red", "Connected - 5 Users", true, false, 1, 10, 5, false, false);
            DaisyChainStaticCls.SaveChainDetails(2, "Team Blue", "Not Connected - 5 Users", false, false, 2, 8, 5, false, false);
            DaisyChainStaticCls.SaveChainDetails(3, "Chain 3", "Locked -3 Users", false, true, 3, 5, 5, false, false);
            DaisyChainStaticCls.SaveChainDetails(4, "Chain 4", "Blocked - 3 Users", false, false, 4, 5, 5, true, false);
        }
        public void SaveUserRecord()
        {
            DaisyChainStaticCls.SaveUserDetails(1, "User 1 (You)", 1, false, "Host-Team Red", true, "Team Red", 1, true, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(2, "User 2", 2, false, "Team Red", false, "Team Red", 1, false, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(3, "User 3", 3, false, "Team Red", false, "Team Red", 1, false, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(4, "User 4", 4, false, "Team Red", false, "Team Red", 1, false, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(5, "User 5", 5, false, "Team Red", false, "Team Red", 1, false, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(6, "User 6", 1, false, "Team Blue", true, "Team Blue", 2, false, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(7, "User 7", 2, false, "Team Blue", false, "Team Blue", 2, false, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(8, "User 8", 3, false, "Team Blue", false, "Team Blue", 2, false, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(9, "User 9", 4, false, "Team Blue", false, "Team Blue", 2, false, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(10, "User 10", 5, false, "Team Blue", false, "Team Blue", 2, false, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(11, "User 11", 6, false, "Chain 3", false, "Chain 3", 3, false, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(12, "User 12", 7, false, "Chain 3", false, "Chain 3", 3, false, 0, false, false, false);
            DaisyChainStaticCls.SaveUserDetails(13, "User 13", 8, false, "Chain 3", false, "Chain 3", 3, false, 0, false, false, false);
        }
    }
}