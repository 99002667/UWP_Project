﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;

namespace MixAmp.Common.ViewModels
{
    public class RoutingViewModel
    {
        public string InputDevicename { get; set; }
        public string InputDeviceRouting { get; set; }
        public string Icon { get; set; }
        public Visibility visiblearrow { get; set; }
        public Visibility notvisiblearrow { get; set; }

        public Windows.UI.Xaml.Media.SolidColorBrush selectedColor { get; set; }

        public Visibility DeviceVisible { get; set; }
        public Thickness IconMargin { get; set; }

        public RoutingViewModel(string InputDeviceName, string Icon, Thickness IconMargin, Visibility visiblearrow, Visibility notvisiblearrow, SolidColorBrush selectedColor, string InputDeviceRouting = "PC Game: 70% - PC Chat: 30%")
        {
            this.InputDevicename = InputDeviceName;
            this.InputDeviceRouting = InputDeviceRouting;
            this.Icon = Icon;
            this.visiblearrow = visiblearrow;
            this.notvisiblearrow = notvisiblearrow;
            this.selectedColor = selectedColor;
            this.IconMargin = IconMargin;
        }
    }
    public class RoutingMonitor : ObservableCollection<RoutingViewModel>
    {
        public RoutingMonitor()
        {
            Add(new RoutingViewModel("Headset", "/Assets/USB.png", new Thickness(0, 0, 0, 0), Visibility.Visible, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(32, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            //Add(new RoutingViewModel("AUX", "/Assets/_AUX.png", Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            //Add(new RoutingViewModel("Stream", "/Assets/USB.png", Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            //Add(new RoutingViewModel("Headset", "/Assets/_AUX.png", Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            //Add(new RoutingViewModel("Astro A50", "/Assets/USB.png", Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            //Add(new RoutingViewModel("Astro A30", "/Assets/Headset.png", Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));

        }

    }

    public class AddedRouting : ObservableCollection<RoutingViewModel>
    {
        public AddedRouting()
        {
            Add(new RoutingViewModel("AUX", "/Assets/_AUX.png", new Thickness(10, 5, 0, 0), Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            Add(new RoutingViewModel("Stream", "/Assets/_AUX.png", new Thickness(10, 5, 0, 0), Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            Add(new RoutingViewModel("Headset", "/Assets/_AUX.png", new Thickness(10, 5, 0, 0), Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            Add(new RoutingViewModel("Astro A50", "/Assets/Wifi.png", new Thickness(10, 5, 0, 0),  Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            Add(new RoutingViewModel("Astro A30", "/Assets/Bluetooth_ICON.png", new Thickness(15, 5, 0, 0),  Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
        }
    }

}

