﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MixAmp.Utils;

namespace MixAmp.Common.ViewModels
{
    public class LanguageSettingsViewModel
    {
        public string Name { get; set; }
        public bool IsSelected { get; set; }

        public LanguageSettingsViewModel(string Name, bool IsSelected)
        {
            this.Name = Name;
            this.IsSelected = IsSelected;
        }
    }

    public class Languages : ObservableCollection<LanguageSettingsViewModel>
    {
        public Languages()
        {
            Add(new LanguageSettingsViewModel(Constants.ENGLISH, SetSelected(Constants.ENGLISH)));
            Add(new LanguageSettingsViewModel(Constants.FRENCH, SetSelected(Constants.FRENCH)));
            Add(new LanguageSettingsViewModel(Constants.ARABIC, SetSelected(Constants.ARABIC)));
            Add(new LanguageSettingsViewModel(Constants.GERMAN, SetSelected(Constants.GERMAN)));
            Add(new LanguageSettingsViewModel(Constants.SPANISH, SetSelected(Constants.SPANISH)));
            Add(new LanguageSettingsViewModel(Constants.CHINESE_TRADITIONAL, SetSelected(Constants.CHINESE_TRADITIONAL)));
            Add(new LanguageSettingsViewModel(Constants.CHINESE_SIMPLIFIED, SetSelected(Constants.CHINESE_SIMPLIFIED)));
            Add(new LanguageSettingsViewModel(Constants.DUTCH, SetSelected(Constants.DUTCH)));
            Add(new LanguageSettingsViewModel(Constants.ITALIAN, SetSelected(Constants.ITALIAN)));
            Add(new LanguageSettingsViewModel(Constants.NORWEGIAN, SetSelected(Constants.NORWEGIAN)));
            Add(new LanguageSettingsViewModel(Constants.PORTUGUESE, SetSelected(Constants.PORTUGUESE)));
            Add(new LanguageSettingsViewModel(Constants.RUSSIAN, SetSelected(Constants.RUSSIAN)));
        }

        private bool SetSelected(string LanguageName)
        {
            string SettingsLanguageName = LanguageSettingsUtils.ReadLanguageSettings();

            if (SettingsLanguageName == null)
            {
                if (LanguageName.Equals(Constants.ENGLISH))
                {
                    return true;
                }
            }
            else if (SettingsLanguageName.Equals(LanguageName))
            {
                return true;
            }
            else
            {
                return false;
            }

            return false;
        }
    }


}
