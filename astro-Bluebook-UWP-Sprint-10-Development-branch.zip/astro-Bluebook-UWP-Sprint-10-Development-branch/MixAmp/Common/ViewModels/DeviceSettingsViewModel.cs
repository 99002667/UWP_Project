﻿using DataAccessLibrary;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace MixAmp.Common.ViewModels
{
    public class DeviceSettingsViewModel
    {
        public string Name { get; set; }
        public ImageSource Icon { get; set; }
        public double IconWidth { get; set; }
        public double IconHeight { get; set; }
        public string Actual_Settings_Name { get; set; }
        public Thickness IconMargin { get; set; }
        public Thickness Settings_Name_Margin { get; set; }
        public Thickness Arrow_Right_Margin { get; set; }
        public Visibility Status_Visibility { get; set; }
        public Visibility Arrow_Right_Visibility { get; set; }
        public Visibility Toggle_Button_Visibility { get; set; }
        public Visibility Dot_Visibility { get; set; }
        public bool Toggle_Button_Is_On { get; set; }

        public DeviceSettingsViewModel(string Name, string Actual_Settings_Name, ImageSource Icon, double IconWidth, double IconHeight,
            Thickness IconMargin, Thickness Settings_Name_Margin, Thickness Arrow_Right_Margin, Visibility Status_Visibility,
            Visibility Arrow_Right_Visibility, Visibility Toggle_Button_Visibility, Visibility Dot_Visibility, bool Toggle_Button_Is_On)
        {
            this.Name = Name;
            this.Actual_Settings_Name = Actual_Settings_Name;
            this.Icon = Icon;
            this.IconWidth = IconWidth;
            this.IconHeight = IconHeight;
            this.IconMargin = IconMargin;
            this.Status_Visibility = Status_Visibility;
            this.Settings_Name_Margin = Settings_Name_Margin;
            this.Arrow_Right_Margin = Arrow_Right_Margin;
            this.Arrow_Right_Visibility = Arrow_Right_Visibility;
            this.Toggle_Button_Visibility = Toggle_Button_Visibility;
            this.Dot_Visibility = Dot_Visibility;
            this.Toggle_Button_Is_On = Toggle_Button_Is_On;
        }

    }

    public class DeviceSettings : ObservableCollection<DeviceSettingsViewModel>
    {
        public DeviceSettings()
        {
            Add(new DeviceSettingsViewModel("Name", GetDeviceName(), GetSettingsIcon("Name"), 32, 32, new Thickness(0, 15, 0, 0), new Thickness(50, 10, 0, 0), new Thickness(-20, 10, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, false));
            Add(new DeviceSettingsViewModel("Firmware Update", "6.3 Update Available", GetSettingsIcon("FirmwareUpdate"), 32, 32, new Thickness(0, 23, 0, 0), new Thickness(50, 20, 0, 0), new Thickness(-20, 20, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Collapsed, Visibility.Visible, false));
            Add(new DeviceSettingsViewModel("Phantom Power Warning", "Off", GetSettingsIcon("PhantomPower"), 25, 25, new Thickness(5, 25, 0, 0), new Thickness(50, 20, 0, 0), new Thickness(-25, 25, 0, 0), Visibility.Visible, Visibility.Collapsed, Visibility.Visible, Visibility.Collapsed, GetPhantomStatus()));
            Add(new DeviceSettingsViewModel("Take The Tour", "", GetSettingsIcon("TakeTheTour"), 32, 32, new Thickness(5, 17, 0, 0), new Thickness(50, 21, 0, 0), new Thickness(-20, 8, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, false));
            Add(new DeviceSettingsViewModel("Reset Device", "", GetSettingsIcon("ResetDevice"), 32, 32, new Thickness(5, 9, 0, 0), new Thickness(50, 13, 0, 0), new Thickness(-20, 6, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, false));
        }
        private string GetDeviceName()
        {
            string query = "SELECT* from tblCarina_DeviceSettings";
            DataSet ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            return Convert.ToString(tb.Rows[0]["deviceName"]);
        }
        private bool GetPhantomStatus()
        {
            string query = "SELECT* from tblCarina_DeviceSettings";
            DataSet ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            return Convert.ToBoolean(tb.Rows[0]["isPhantomPowerOn"]);
        }
        private ImageSource GetSettingsIcon(string SettingsName)
        {
            Image image = new Image();
            if (SettingsName.Equals("Name"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Profile.png"));
            }
            else if (SettingsName.Equals("FirmwareUpdate"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Firmware_Settings.png"));
            }
            else if (SettingsName.Equals("PhantomPower"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Phantom_Icon.png"));
            }
            else if (SettingsName.Equals("TakeTheTour"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Tour.png"));
            }
            else if (SettingsName.Equals("ResetDevice"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Reset_Device.png"));
            }
            return image.Source;
        }
    }
    public static class DeviceSpecificDataViewModel
    {
        public static void InitialiseDeviceSpecificSettings()
        {
            //Carina	
            DataSet dataSetCarina = new DataSet();
            string queryCarina = "SELECT* from tblCarina_DeviceSettings";
            dataSetCarina = DataAccess.GetData(queryCarina);
            var tablesCarina = dataSetCarina.Tables[0];
            var rowCarina = tablesCarina.Rows.Count;
            var columnsCarina = tablesCarina.Columns.Count;
            if (rowCarina == 0)
            {
                SqliteCommand insertCommand = new SqliteCommand();
                insertCommand.CommandText = "INSERT INTO tblCarina_DeviceSettings VALUES (@deviceId, @deviceName, @firmwareUpdate, @isPhantomPowerOn)";
                insertCommand.Parameters.AddWithValue("@deviceId", "1");
                insertCommand.Parameters.AddWithValue("@deviceName", "Alec's Mixamp");
                insertCommand.Parameters.AddWithValue("@firmwareUpdate", "Latest Update");
                insertCommand.Parameters.AddWithValue("@isPhantomPowerOn", false);

                DataAccess.InsertData(insertCommand);
            }
            //Carina	
            //Carbonite//	
            DataSet dataSetCarbonite = new DataSet();
            string queryCarbonite = "SELECT* from tblCarbonite_DeviceSettings";
            dataSetCarbonite = DataAccess.GetData(queryCarbonite);
            var tablesCarbonite = dataSetCarbonite.Tables[0];
            var rowCarbonite = tablesCarbonite.Rows.Count;
            var columnsCarbonite = tablesCarbonite.Columns.Count;
            if (rowCarbonite == 0)
            {
                SqliteCommand insertCommand = new SqliteCommand();
                insertCommand.CommandText = "INSERT INTO tblCarbonite_DeviceSettings VALUES (@deviceId, @deviceName, @firmwareUpdate, @sleepMode, @tones)";
                insertCommand.Parameters.AddWithValue("@deviceId", "1");
                insertCommand.Parameters.AddWithValue("@deviceName", "Alec's A30");
                insertCommand.Parameters.AddWithValue("@firmwareUpdate", "Latest Update");
                insertCommand.Parameters.AddWithValue("@sleepMode", "15 Minutes");
                insertCommand.Parameters.AddWithValue("@tones", "All");
                DataAccess.InsertData(insertCommand);
            }
            //Carbonite//	
            //BoontaEve//	
            DataSet dataSetBoontaEve = new DataSet();
            string queryBoontaEve = "SELECT* from tblBoontaEve_DeviceSettings";
            dataSetBoontaEve = DataAccess.GetData(queryBoontaEve);
            var tablesBoontaEve = dataSetBoontaEve.Tables[0];
            var rowBoontaEve = tablesBoontaEve.Rows.Count;
            var columnsBoontaEve = tablesBoontaEve.Columns.Count;
            if (rowBoontaEve == 0)
            {
                SqliteCommand insertCommand = new SqliteCommand();
                insertCommand.CommandText = "INSERT INTO tblBoontaEve_DeviceSettings VALUES (@deviceId, @deviceName, @firmwareUpdate, @brightnessValue, @isAllowmanagementEnabled, @isAutomaticReconnectEnabled, @isBluetoothEnabled, @isChainGameSoundEnabled, @isWifiChainEnabled)";
                insertCommand.Parameters.AddWithValue("@deviceId", "1");
                insertCommand.Parameters.AddWithValue("@deviceName", "Alec's Mixamp Pro TR");
                insertCommand.Parameters.AddWithValue("@firmwareUpdate", "Latest Update");
                insertCommand.Parameters.AddWithValue("@brightnessValue", "0");
                insertCommand.Parameters.AddWithValue("@isAllowmanagementEnabled", false);
                insertCommand.Parameters.AddWithValue("@isAutomaticReconnectEnabled", false);
                insertCommand.Parameters.AddWithValue("@isBluetoothEnabled", false);
                insertCommand.Parameters.AddWithValue("@isChainGameSoundEnabled", false);
                insertCommand.Parameters.AddWithValue("@isWifiChainEnabled", false);
                DataAccess.InsertData(insertCommand);
            }
        }

        public static void UpdatePhantomPower(bool Value, string id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblCarina_DeviceSettings set isPhantomPowerOn = :info where deviceId=:id";
            updateCommand.Parameters.AddWithValue("info", Value);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public static void UpdateSleepMode(string Value, string id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblCarbonite_DeviceSettings set sleepMode = :info where deviceId=:id";
            updateCommand.Parameters.AddWithValue("info", Value);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public static void UpdateTones(string Value, string id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblCarbonite_DeviceSettings set tones = :info where deviceId=:id";
            updateCommand.Parameters.AddWithValue("info", Value);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public static void UpdateBluetooth(bool Value, string id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblBoontaEve_DeviceSettings set isBluetoothEnabled = :info where deviceId=:id";
            updateCommand.Parameters.AddWithValue("info", Value);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public static void UpdateChainToggleStates(bool Value, string id, string name)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            if (name == "Enable WiFi Chain")
            {
                updateCommand.CommandText = "update tblBoontaEve_DeviceSettings set isWifiChainEnabled = :info where deviceId=:id";
                updateCommand.Parameters.AddWithValue("info", Value);
                updateCommand.Parameters.AddWithValue("id", id);
                DataAccess.UpdateRecord(updateCommand);
            }
            else if (name == "Chain Game Sound")
            {
                updateCommand.CommandText = "update tblBoontaEve_DeviceSettings set isChainGameSoundEnabled = :info where deviceId=:id";
                updateCommand.Parameters.AddWithValue("info", Value);
                updateCommand.Parameters.AddWithValue("id", id);
                DataAccess.UpdateRecord(updateCommand);
            }
            else if (name == "Automatic Reconnect")
            {
                updateCommand.CommandText = "update tblBoontaEve_DeviceSettings set isAutomaticReconnectEnabled = :info where deviceId=:id";
                updateCommand.Parameters.AddWithValue("info", Value);
                updateCommand.Parameters.AddWithValue("id", id);
                DataAccess.UpdateRecord(updateCommand);
            }
            else if (name == "Allow Management")
            {
                updateCommand.CommandText = "update tblBoontaEve_DeviceSettings set isAllowmanagementEnabled = :info where deviceId=:id";
                updateCommand.Parameters.AddWithValue("info", Value);
                updateCommand.Parameters.AddWithValue("id", id);
                DataAccess.UpdateRecord(updateCommand);
            }

        }
        public static void UpdateLEDBrightness(int Value, string id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblBoontaEve_DeviceSettings set brightnessValue = :info where deviceId=:id";
            updateCommand.Parameters.AddWithValue("info", Value);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public static void UpdateName(string NewName, string id)
        {
            SqliteCommand UpdateCommand = new SqliteCommand();
            UpdateCommand.CommandText = "update tblCarina_DeviceSettings set deviceName = :info where deviceId = :id";
            UpdateCommand.Parameters.AddWithValue("info", NewName);
            UpdateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(UpdateCommand);
        }
        public static string GetCarinaDeviceName()
        {
            string query = "SELECT* from tblCarina_DeviceSettings";
            DataSet ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            return Convert.ToString(tb.Rows[0]["deviceName"]);
        }
        public static string GetCarboniteDeviceName()
        {
            string query = "SELECT* from tblCarbonite_DeviceSettings";
            DataSet ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            return Convert.ToString(tb.Rows[0]["deviceName"]);
        }
        public static string GetBoontaEveDeviceName()
        {
            string query = "SELECT* from tblBoontaEve_DeviceSettings";
            DataSet ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            return Convert.ToString(tb.Rows[0]["deviceName"]);
        }
    }
}
