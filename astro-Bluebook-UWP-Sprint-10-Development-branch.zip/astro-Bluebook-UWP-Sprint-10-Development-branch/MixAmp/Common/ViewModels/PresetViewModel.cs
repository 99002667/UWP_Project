﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;

namespace MixAmp.Common.ViewModels
{
    public class PresetViewModel
    {
        public string Name { get; set; }
        public string Status { get; set; }
        public bool Is_Selected { get; set; }
        public Visibility FortyEightV_Visibility { get; set; }
        public SolidColorBrush TextColor { get; set; }
        public Visibility SideBorderVisibility { get; set; }

        public PresetViewModel(string Name, string Status, bool Is_Selected, Visibility FortyEightV_Visibility, Visibility SideBorderVisibility, SolidColorBrush TextColor)
        {
            this.Name = Name;
            this.Status = Status;
            this.Is_Selected = Is_Selected;
            this.FortyEightV_Visibility = FortyEightV_Visibility;
            this.SideBorderVisibility = SideBorderVisibility;
            this.TextColor = TextColor;
        }
    }

    public class Presets : ObservableCollection<PresetViewModel>
    {
        public Presets()
        {
            Add(new PresetViewModel("Astro Gaming", "Active", true, Visibility.Collapsed, Visibility.Visible, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0))));
            Add(new PresetViewModel("Astro Pro", "Inactive", false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Colors.Gray)));
            Add(new PresetViewModel("Astro Music", "Inactive", false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Colors.Gray)));
            Add(new PresetViewModel("Custom", "Inactive", false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Colors.Gray)));
        }
    }
}
