﻿using MixAmp.Utils;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace MixAmp.Common.ViewModels
{
   public class AppSettingsViewModel
    {
        public string Name { get; set; }
        public string Status { get; set; }
        public ImageSource Icon { get; set; }
        public double IconWidth { get; set; }
        public double IconHeight { get; set; }
        public Thickness IconMargin { get; set; }
        public Thickness Settings_Name_Margin { get; set; }
        public Thickness Arrow_Right_Margin { get; set; }
        public Visibility Status_Visibility { get; set; }
        public Visibility Arrow_Right_Visibility { get; set; }
        public Visibility Toggle_Button_Visibility { get; set; }
        public bool Toggle_Button_Is_On { get; set; }
        public AppSettingsViewModel(string Name,
            string Status,
            ImageSource Icon,
            double IconWidth,
            double IconHeight,
            Thickness IconMargin,
            Thickness Settings_Name_Margin,
            Thickness Arrow_Right_Margin,
            Visibility Status_Visibility,
            Visibility Arrow_Right_Visibility,
            Visibility Toggle_Button_Visibility, bool Toggle_Button_Is_On)
        {
            this.Name = Name;
            this.Status = Status;
            this.Icon = Icon;
            this.IconWidth = IconWidth;
            this.IconHeight = IconHeight;
            this.IconMargin = IconMargin;
            this.Settings_Name_Margin = Settings_Name_Margin;
            this.Arrow_Right_Margin = Arrow_Right_Margin;
            this.Status_Visibility = Status_Visibility;
            this.Arrow_Right_Visibility = Arrow_Right_Visibility;
            this.Toggle_Button_Visibility = Toggle_Button_Visibility;
            this.Toggle_Button_Is_On = Toggle_Button_Is_On;

        }
    }

    public class AppSettings : ObservableCollection<AppSettingsViewModel>
    {
        public AppSettings()
        {
            Add(new AppSettingsViewModel("App Version", "1.05", GetSettingsIcon("AppVersion"), 32, 32, new Thickness(0, 17, 0, 0), new Thickness(50, 15, 0, 0), new Thickness(-25, 15, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Collapsed, GetOnInfo("AppVersion")));
            Add(new AppSettingsViewModel("Language", LanguageUtils.GetLanguageName(), GetSettingsIcon("Language"), 32, 32, new Thickness(0, 17, 0, 0), new Thickness(50, 15, 0, 0), new Thickness(-25, 15, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Collapsed, GetOnInfo("Language")));
            Add(new AppSettingsViewModel("Notifications", "", GetSettingsIcon("Notifications"), 32, 32, new Thickness(0, 20, 0, 0), new Thickness(50, 25, 0, 0), new Thickness(-25, 15, 0, 0), Visibility.Collapsed, Visibility.Visible, Visibility.Collapsed, GetOnInfo("Notifications")));
            Add(new AppSettingsViewModel("Privacy Disclaimer", "", GetSettingsIcon("PrivacyDisclaimer"), 32, 32, new Thickness(0, 20, 0, 0), new Thickness(50, 25, 0, 0), new Thickness(-25, 15, 0, 0), Visibility.Collapsed, Visibility.Visible, Visibility.Collapsed, GetOnInfo("PrivacyDisclaimer")));
            Add(new AppSettingsViewModel("Share Analytics Data", "Off", GetSettingsIcon("ShareAnalyticsData"), 32, 32, new Thickness(0, 25, 0, 0), new Thickness(50, 20, 0, 0), new Thickness(-25, 20, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Visible, GetOnInfo("Share Analytics Data")));
            Add(new AppSettingsViewModel("Accessibility Mode", "Off", GetSettingsIcon("AccessibilityMode"), 32, 32, new Thickness(0, 25, 0, 0), new Thickness(50, 20, 0, 0), new Thickness(-25, 20, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Visible, GetOnInfo("Accessibility Mode")));
        }
        private bool GetOnInfo(string SettingsName)
        {
            if (SettingsName == "Share Analytics Data")
            {
                Windows.Storage.ApplicationDataContainer AppSettingsSpecificData =
    Windows.Storage.ApplicationData.Current.LocalSettings;
                Windows.Storage.ApplicationDataCompositeValue ReadAppSettingsSpecific =
   (Windows.Storage.ApplicationDataCompositeValue)AppSettingsSpecificData.Values["Share Analytics Data"];
                if (ReadAppSettingsSpecific != null)
                {
                    return (bool)ReadAppSettingsSpecific[SettingsName];
                }
                else
                {
                    return false;
                }
            }
            else if (SettingsName == "Accessibility Mode")
            {
                Windows.Storage.ApplicationDataContainer AppSettingsSpecificData =
    Windows.Storage.ApplicationData.Current.LocalSettings;
                Windows.Storage.ApplicationDataCompositeValue ReadAppSettingsSpecific =
   (Windows.Storage.ApplicationDataCompositeValue)AppSettingsSpecificData.Values["Accessibility Mode"];
                if (ReadAppSettingsSpecific != null)
                {
                    return (bool)ReadAppSettingsSpecific[SettingsName];
                }
                else
                {
                    return false;
                }
            }
            return false;
        }
        private ImageSource GetSettingsIcon(string SettingsName)
        {
            Image image = new Image();
            if (SettingsName.Equals("AppVersion"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/App_Version.png"));
            }
            else if (SettingsName.Equals("Language"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Language.png"));
            }
            else if (SettingsName.Equals("Notifications"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Notification.png"));
            }
            else if (SettingsName.Equals("PrivacyDisclaimer"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/PrivacyDisclaimer.png"));
            }
            else if (SettingsName.Equals("ShareAnalyticsData"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Share.png"));
            }
            else if (SettingsName.Equals("AccessibilityMode"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Accessibility.png"));
            }
            return image.Source;
        }
    }
}
