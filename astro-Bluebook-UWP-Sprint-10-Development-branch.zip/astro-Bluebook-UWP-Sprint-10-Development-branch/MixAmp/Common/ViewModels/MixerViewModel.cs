﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;

namespace MixAmp.Common.ViewModels
{
    public class MixerViewModel : INotifiBaseCls
    {
        public string InputDevicename_;
        public string InputDeviceRouting_;
        public string Icon_; 
       
        public Visibility visiblearrow { get; set; }
        public Visibility notvisiblearrow { get; set; }

        public Windows.UI.Xaml.Media.SolidColorBrush selectedColor { get; set; }

        public Visibility DeviceVisible { get; set; }

        public string SourceA_;
        public string SourceB_;
        public string sourceAValue = "";

        public MixerMonitor MixerMonitor { get; set; }
        public AddedMixer AddedMixer { get; set; }
        public MixerMonitorNew MixerMonitorNew { get; set; }
        public AddedMixerNew AddedMixerNew { get; set; }
        private static bool Isinit = false;


        public string InputDevicename
        {
            get { return InputDevicename_; }
            set
            {
                InputDevicename_ = value;

                OnPropertyChanged(InputDevicename);
            }
        }
        public string InputDeviceRouting
        {
            get { return InputDeviceRouting_; }
            set
            {
                InputDeviceRouting_ = value;
                OnPropertyChanged(nameof(InputDeviceRouting));
            }
        }
        public string Icon
        {
            get { return Icon_; }
            set
            {
                Icon_ = value;
                OnPropertyChanged(Icon);
            }
        }
        public string SourceA
        {
            get { return SourceA_; }
            set
            {
                SourceA_ = value;
                OnPropertyChanged(SourceA);
            }
        }

        double m_Angle = default(double);
        public double Angle
        {
            get { return m_Angle; }
            set
            {

                if (value < 223)
                {
                    SetProperty(ref m_Angle, value);
                    if (value >= 220)
                    {
                        Value = 100;
                    }
                    else if (value < 220)
                    {
                        Value = (int)(value / 2.2);

                    }
                }
            }
        }

        int m_Value = default(int);
        public int Value
        {
            get { return m_Value; }
            set
            {
                SetProperty(ref m_Value, value);
                //  Angle = (double)(value * 2.8);
                Value1 = (int)(100 - value);
                InputDeviceRouting = Value1.ToString();
                // App.sourceAvalue_ = Value1.ToString();
                if (value >= 0 && value < 10)
                {
                    ImageSrc = "/Assets/Images/1.png";
                }
                else if (value == 100)
                {
                    ImageSrc = "/Assets/Images/10.png";
                }
                else
                {
                    ImageSrc = "/Assets/Images/" + Convert.ToString((value / 10) + 1) + ".png";
                }


                /*  if (value > 30 && value < 60)
                  {
                      ImageSrc = "Assets/Images/1.png";
                  }
                  else if (value >= 60)
                  {
                      ImageSrc = "Assets/Images/2.png";
                  }
                  else
                  {
                      ImageSrc = "Assets/Images/3.png";
                  }*/

                // App.Mixercls[0].SourceA = m_Value.ToString();

            }
        }
        int m_Value1 = default(int);
        public int Value1
        {
            get { return m_Value1; }
            set
            {
                SetProperty(ref m_Value1, value);


                // App.Mixercls[0].SourceB = m_Value1.ToString();


            }
        }

        string m_ImageSrc = default(string);
        public string ImageSrc
        {
            get { return m_ImageSrc; }
            set
            {

                SetProperty(ref m_ImageSrc, value);
            }
        }
        Thickness m_IconMargin = default(Thickness);
        public Thickness IconMargin
        {
            get { return m_IconMargin; }

            set
            {
                SetProperty(ref m_IconMargin, value);
            }
        }


        public MixerViewModel(string InputDeviceName, string Icon, Visibility visiblearrow, Visibility notvisiblearrow, SolidColorBrush selectedColor, string InputDeviceRouting, Thickness IconMargin)
        {
            this.InputDevicename = InputDeviceName;
            this.InputDeviceRouting = InputDeviceRouting;
            this.Icon = Icon;
            this.visiblearrow = visiblearrow;
            this.notvisiblearrow = notvisiblearrow;
            this.selectedColor = selectedColor;
            this.IconMargin = IconMargin;
            //this.SourceAValue = SourceAValue;
            //this.SourceBValue = SourceBValue;
            init();

        }
        public MixerViewModel()
        {

            // MixerMonitor MixerMonitor = new MixerMonitor();
            SetProperty(ref m_Value1, 100);
            SetProperty(ref m_ImageSrc, "/Assets/Images/1.png");

            if (Windows.ApplicationModel.DesignMode.DesignModeEnabled)
            {
                Angle = 0;
            }
            Isinit = false;
            init();
        }
       // private static bool Isinit = false;
        void init()
        {
            if (Isinit)
            {
                return;
            }
            Isinit = true;
            MixerMonitor = new MixerMonitor();
            AddedMixer = new AddedMixer();
            MixerMonitorNew = new MixerMonitorNew();
            AddedMixerNew = new AddedMixerNew();
        }
        public void UpdateSource()
        {
            MixerMonitor[0].InputDeviceRouting = $"Source A- {Value1}%";
            MixerMonitorNew[0].InputDeviceRouting = $"Source B- {Value}%";
            // OnPropertyChanged(nameof(MixerViewModel));
        }
    }

    public class MixerMonitor : ObservableCollection<MixerViewModel>
    {
        public MixerMonitor()
        {
            try
            {
                Add(new MixerViewModel("PC Game", "/Assets/USB.png", Visibility.Visible, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(32, 32, 32, 1)), "Source A- 100%", new Thickness(15,5,0,-15)));

            }
            catch (Exception ex)
            {

                throw;
            }
        }

    }

    public class AddedMixer : ObservableCollection<MixerViewModel>
    {
        public AddedMixer()
        {
            Add(new MixerViewModel("PC Game", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "", new Thickness(10,5,0,0)));
            Add(new MixerViewModel("USB Audio", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "", new Thickness(10,5,0,0)));
            Add(new MixerViewModel("AUX", "/Assets/_AUX.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "", new Thickness(10,5,0,0)));
            Add(new MixerViewModel("Bluetooth Device", "/Assets/Bluetooth_ICON.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "", new Thickness(15,5,0,0)));
            //Add(new RoutingViewModel("Astro A50", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            //Add(new RoutingViewModel("Astro A30", "/Assets/Headset.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
        }
    }


    /////////////////////////
    ///
    public class MixerMonitorNew : ObservableCollection<MixerViewModel>
    {
        public MixerMonitorNew()
        {
            Add(new MixerViewModel("PC Chat", "/Assets/USB.png", Visibility.Visible, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(32, 32, 32, 1)), "Source B- 0%", new Thickness(15,5,0,-15)));

        }

    }

    public class AddedMixerNew : ObservableCollection<MixerViewModel>
    {
        public AddedMixerNew()
        {
            Add(new MixerViewModel("PC Chat", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " ", new Thickness(10,5,0,0)));
            Add(new MixerViewModel("USB Audio", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " ", new Thickness(10, 5, 0, 0)));
            Add(new MixerViewModel("AUX", "/Assets/_AUX.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " ", new Thickness(10,5,0,0)));
            Add(new MixerViewModel("Bluetooth Device", "/Assets/Bluetooth_ICON.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " ", new Thickness(15,5,0,0)));
            Add(new MixerViewModel("None", "/Assets/CloseFrame.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " ", new Thickness(10,5,0,0)));

            //Add(new RoutingViewModel("Astro A50", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            //Add(new RoutingViewModel("Astro A30", "/Assets/Headset.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
        }
    }
}

