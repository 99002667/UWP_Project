﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using MixAmp.Common.ViewModels;
using MixAmp.BoontaEve.UserControls;
using MixAmp.Carbonite.ViewModels;
using MixAmp.BoontaEve.ViewModels;
using MixAmp.Common.Views;



// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Common.UserControls.Setting
{
    public sealed partial class MainSettingsMenu : UserControl
    {
        public MainSettingsMenu()
        {
            this.InitializeComponent();
            this.DataContext = this;
            MainSettingsList.ItemsSource = new MainSettings();
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            Button Close_Button = (Button)sender;
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            StackPanel SettingsStackPanel = (StackPanel)SettingsRelativePanel.Parent;
            FlyoutPresenter SettingsFlyoutPresenter = (FlyoutPresenter)SettingsStackPanel.Parent;
            Popup SettingsPopup = (Popup)SettingsFlyoutPresenter.Parent;

            if (SettingsPopup.IsOpen)
            {
                SettingsPopup.IsOpen = false;
            }
        }

        private void Arrow_Right_Click(object sender, RoutedEventArgs e)
        {
            Button Arrow_Right = sender as Button;
            var SettingsViewModel = Arrow_Right.DataContext;
            if (SettingsViewModel is MainSettingsViewModel)
            {
                MainSettingsViewModel MainSettingsViewModel = (MainSettingsViewModel)SettingsViewModel;
                var name = MainSettingsViewModel.Name;
                if (name == DeviceSpecificDataViewModel.GetCarinaDeviceName())
                {
                    this.ShowDeviceSettingsMenu();
                }
                switch (name)
                {
                    //case "Mixamp Studio":
                    //    this.ShowDeviceSettingsMenu();
                    //    break;
                    case "Application":
                        this.ShowAppSettingsMenu();
                        break;
                    case "Support":
                        //this.ShowDeviceSettingsMenu();
                        break;
                    case "Submit Feedback":
                        //var uri = new Uri(URIConstant.SubmitFeedback);
                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;
                        // Launch the URI with a warning prompt
                        var submitsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.SubmitFeedback));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.SubmitFeedback);
                        break;
                    case "Shop Astro":
                        //var uri = new Uri(URIConstant.ShopAstro);
                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;
                        // Launch the URI with a warning prompt
                        var shopsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.ShopAstro));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.ShopAstro);
                        break;
                    case "Log In":
                        this.ShowLoginScreen();
                        break;
                    default:
                        break;
                        //if (MainSettingsViewModel.Name.Equals("Mixamp Studio"))
                        //{
                        //    this.ShowDeviceSettingsMenu();

                        //}
                        //else if (MainSettingsViewModel.Name.Equals("Application"))
                        //{
                        //    this.ShowAppSettingsMenu();
                        //}
                        //else if (MainSettingsViewModel.Name.Equals("Log In"))
                        //{
                        //    this.ShowLoginScreen();
                        //}
                }
            }
            else if (SettingsViewModel is AstroA30MainSettingsViewModel)
            {

                AstroA30MainSettingsViewModel AstroA30MainSettingsViewModel = (AstroA30MainSettingsViewModel)SettingsViewModel;
                var name = AstroA30MainSettingsViewModel.Name;
                if (name == DeviceSpecificDataViewModel.GetCarboniteDeviceName())
                {
                    this.ShowDeviceSettingsMenu();
                }
                switch (name)
                {
                    //case "Astro A30":
                    //    this.ShowDeviceSettingsMenu();
                    //    break;
                    case "Application":
                        this.ShowAppSettingsMenu();
                        break;
                    case "Support":
                        //this.ShowDeviceSettingsMenu();
                        break;
                    case "Submit Feedback":
                        //var uri = new Uri(URIConstant.SubmitFeedback);
                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;
                        // Launch the URI with a warning prompt
                        var submitsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.SubmitFeedback));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.SubmitFeedback);
                        break;
                    case "Shop Astro":
                        //var uri = new Uri(URIConstant.ShopAstro);
                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;
                        // Launch the URI with a warning prompt
                        var shopsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.ShopAstro));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.ShopAstro);
                        break;
                    case "Log In":
                        this.ShowLoginScreen();
                        break;
                    default:
                        break;
                }
                //if (AstroA30MainSettingsViewModel.Name.Equals("Astro A30"))
                //{
                //    this.ShowDeviceSettingsMenu();
                //}
                //else if (AstroA30MainSettingsViewModel.Name.Equals("Application"))
                //{
                //    this.ShowAppSettingsMenu();
                //}
            }
            else if (SettingsViewModel is BoontaEveMainSettingsViewModel)
            {
                BoontaEveMainSettingsViewModel BoontaEveMainSettingsViewModel = (BoontaEveMainSettingsViewModel)SettingsViewModel;
                var name = BoontaEveMainSettingsViewModel.Name;
                if (name == DeviceSpecificDataViewModel.GetBoontaEveDeviceName())
                {
                    this.ShowBoontaEveDeviceSettingsMenu();
                }
                switch (name)
                {
                    //case "Mixamp Pro TR":
                    //    this.ShowBoontaEveDeviceSettingsMenu();
                    //    break;
                    case "Application":
                        this.ShowAppSettingsMenu();
                        break;
                    case "Support":
                        //this.ShowDeviceSettingsMenu();
                        break;
                    case "Submit Feedback":
                        //var uri = new Uri(URIConstant.SubmitFeedback);
                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;
                        // Launch the URI with a warning prompt
                        var submitsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.SubmitFeedback));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.SubmitFeedback);
                        break;
                    case "Shop Astro":
                        //var uri = new Uri(URIConstant.ShopAstro);
                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;
                        // Launch the URI with a warning prompt
                        var shopsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.ShopAstro));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.ShopAstro);
                        break;
                    case "Log In":
                        this.ShowLoginScreen();
                        break;
                    default:
                        break;
                }
                //if (BoontaEveMainSettingsViewModel.Name.Equals("Mixamp Pro TR"))
                //{
                //    this.ShowBoontaEveDeviceSettingsMenu();
                //}
                //else if (BoontaEveMainSettingsViewModel.Name.Equals("Application"))
                //{
                //    this.ShowAppSettingsMenu();
                //}
            }
        }


        private void ShowDeviceSettingsMenu()
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            UIElementCollection UIElements = SettingsRelativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is DeviceSettingsMenu)
                {
                    DeviceSettingsMenu DeviceSettingsMenu = (DeviceSettingsMenu)UIElement;
                    DeviceSettingsMenu.Visibility = Visibility.Visible;
                }
                else if (UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = (MainSettingsMenu)UIElement;
                    MainSettingsMenu.Visibility = Visibility.Collapsed;
                }
            }
        }
        
        private void ShowBoontaEveDeviceSettingsMenu()
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            UIElementCollection UIElements = SettingsRelativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is BoontaEveDeviceSettingsMenu)
                {
                    BoontaEveDeviceSettingsMenu BoontaEveDeviceSettingsMenu = (BoontaEveDeviceSettingsMenu)UIElement;
                    BoontaEveDeviceSettingsMenu.Visibility = Visibility.Visible;
                }
                else if (UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = (MainSettingsMenu)UIElement;
                    MainSettingsMenu.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void ShowAppSettingsMenu()
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            UIElementCollection UIElements = SettingsRelativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is AppSettingsMenu)
                {
                    AppSettingsMenu AppSettingsMenu = (AppSettingsMenu)UIElement;
                    AppSettingsMenu.Visibility = Visibility.Visible;
                }
                else if (UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = (MainSettingsMenu)UIElement;
                    MainSettingsMenu.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void ShowLoginScreen()
        {
            ((Frame)Window.Current.Content).Navigate(typeof(LoginBaseScreen));
        }

    }
}

