﻿using MixAmp.Common.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using MixAmp.Utils;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.ApplicationModel.Core;
using Windows.UI.Popups;
using MixAmp.Carina.Views;
using MixAmp.BoontaEve.Views;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Common.UserControls.Setting
{
    public sealed partial class LanguageSettingsMenu : UserControl
    {
        public LanguageSettingsMenu()
        {
            this.InitializeComponent();
            LanguageSettingsList.ItemsSource = new Languages();
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            Close_Flyout();
        }
        private void Close_Flyout()
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            StackPanel SettingsStackPanel = (StackPanel)SettingsRelativePanel.Parent;
            FlyoutPresenter SettingsFlyoutPresenter = (FlyoutPresenter)SettingsStackPanel.Parent;
            Popup SettingsPopup = (Popup)SettingsFlyoutPresenter.Parent;

            if (SettingsPopup.IsOpen)
            {
                SettingsPopup.IsOpen = false;
            }
        }

        private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        {
            RelativePanel CurrentMenuParent = this.Parent as RelativePanel;
            UIElementCollection UIElements = CurrentMenuParent.Children;

            foreach (var UIElement in UIElements)
            {
                if (UIElement is LanguageSettingsMenu)
                {
                    if (this.Visibility == Visibility.Visible)
                    {
                        this.Visibility = Visibility.Collapsed;
                    }
                }
                else if (UIElement is AppSettingsMenu)
                {
                    AppSettingsMenu AppSettingsMenu = UIElement as AppSettingsMenu;

                    if (AppSettingsMenu.Visibility == Visibility.Collapsed)
                    {
                        AppSettingsMenu.Visibility = Visibility.Visible;
                    }
                }
            }
        }

        private void LanguageSettingsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListView ListView = (ListView)sender as ListView;
            foreach (var item in ListView.Items)
            {
                var ListViewItem = (ListViewItem)ListView.ContainerFromItem(item);
                var ItemViewGrid = (Grid)ListViewItem.ContentTemplateRoot;
                var radioButton = ItemViewGrid.FindName("Language_Radio") as RadioButton;
                LanguageSettingsViewModel LanguageSettingsViewModel = (LanguageSettingsViewModel)item;

                if (ListViewItem.IsSelected)
                {
                    radioButton.IsChecked = true;
                    LanguageSettingsViewModel.IsSelected = true;
                }
                else
                {
                    radioButton.IsChecked = false;
                    LanguageSettingsViewModel.IsSelected = false;
                }
            }
        }

        private void Language_Radio_Click(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = e.OriginalSource as RadioButton;
            if (radioButton != null)
            {
                LanguageSettingsViewModel LanguageSettingsViewModel = radioButton.DataContext as LanguageSettingsViewModel;
                LanguageSettingsList.SelectedItem = LanguageSettingsViewModel;
                LoadUserPreferredApplicationLanguage(LanguageSettingsViewModel);
            }
            ReNavigate();
            Close_Flyout();
        }


        private void WriteToLanguageSettings(LanguageSettingsViewModel LanguageSettingsViewModel)
        {
            string Content = "";
            string LanguageName = LanguageSettingsViewModel.Name;
            if (LanguageName.Equals(Constants.ARABIC))
            {
                Content = Constants.ARABIC;
            }
            else if (LanguageName.Equals(Constants.BULGARIAN))
            {
                Content = Constants.BULGARIAN;
            }
            else if (LanguageName.Equals(Constants.CZECH))
            {
                Content = Constants.CZECH;
            }
            else if (LanguageName.Equals(Constants.CHINESE_TRADITIONAL))
            {
                Content = Constants.CHINESE_TRADITIONAL;
            }
            else if (LanguageName.Equals(Constants.DANISH))
            {
                Content = Constants.DANISH;
            }
            else if (LanguageName.Equals(Constants.GERMAN))
            {
                Content = Constants.GERMAN;
            }
            else if (LanguageName.Equals(Constants.ENGLISH))
            {
                Content = Constants.ENGLISH;
            }
            else if (LanguageName.Equals(Constants.SPANISH))
            {
                Content = Constants.SPANISH;
            }
            else if (LanguageName.Equals(Constants.ESTONIA))
            {
                Content = Constants.ESTONIA;
            }
            else if (LanguageName.Equals(Constants.FINNISH))
            {
                Content = Constants.FINNISH;
            }
            else if (LanguageName.Equals(Constants.FRENCH))
            {
                Content = Constants.FRENCH;
            }
            else if (LanguageName.Equals(Constants.PORTUGUESE))
            {
                Content = Constants.PORTUGUESE;
            }
            else if (LanguageName.Equals(Constants.CROATIAN))
            {
                Content = Constants.CROATIAN;
            }
            else if (LanguageName.Equals(Constants.HUNGARIAN))
            {
                Content = Constants.HUNGARIAN;
            }
            else if (LanguageName.Equals(Constants.INDONESIAN))
            {
                Content = Constants.INDONESIAN;
            }
            else if (LanguageName.Equals(Constants.ITALIAN))
            {
                Content = Constants.ITALIAN;
            }
            else if (LanguageName.Equals(Constants.JAPANESE))
            {
                Content = Constants.JAPANESE;
            }
            else if (LanguageName.Equals(Constants.KOREAN))
            {
                Content = Constants.KOREAN;
            }
            else if (LanguageName.Equals(Constants.LITHUANIAN))
            {
                Content = Constants.LITHUANIAN;
            }
            else if (LanguageName.Equals(Constants.LATVIAN))
            {
                Content = Constants.LATVIAN;
            }
            else if (LanguageName.Equals(Constants.DUTCH))
            {
                Content = Constants.DUTCH;
            }
            else if (LanguageName.Equals(Constants.NORWEGIAN))
            {
                Content = Constants.NORWEGIAN;
            }
            else if (LanguageName.Equals(Constants.ROMANIAN))
            {
                Content = Constants.ROMANIAN;
            }
            else if (LanguageName.Equals(Constants.RUSSIAN))
            {
                Content = Constants.RUSSIAN;
            }
            else if (LanguageName.Equals(Constants.SLOVAK))
            {
                Content = Constants.SLOVAK;
            }
            else if (LanguageName.Equals(Constants.SLOVENIAN))
            {
                Content = Constants.SLOVENIAN;
            }
            else if (LanguageName.Equals(Constants.SWEDEN))
            {
                Content = Constants.SWEDEN;
            }
            else if (LanguageName.Equals(Constants.THAI))
            {
                Content = Constants.THAI;
            }
            else if (LanguageName.Equals(Constants.TURKISH))
            {
                Content = Constants.TURKISH;
            }
            else if (LanguageName.Equals(Constants.UKRAINIAN))
            {
                Content = Constants.UKRAINIAN;
            }
            else if (LanguageName.Equals(Constants.VIETNAMESE))
            {
                Content = Constants.VIETNAMESE;
            }
            //FileUtils.WriteToLanguageFile(LanguageStorageFile, Content);
            LanguageSettingsUtils.WriteLanguageSettings(Content);
        }

        private void LoadUserPreferredApplicationLanguage(LanguageSettingsViewModel LanguageSettingsViewModel)
        {
            string LanguageName = LanguageSettingsViewModel.Name;
            LanguageUtils.LoadUserPreferredApplicationLanguage(LanguageName);
            WriteToLanguageSettings(LanguageSettingsViewModel);
        }

        private async void RestartApplication()
        {
            var result = await CoreApplication.RequestRestartAsync("Application Restart Programatically");

            if (result == AppRestartFailureReason.NotInForeground ||
                result == AppRestartFailureReason.RestartPending ||
                result == AppRestartFailureReason.Other)
            {
                var msgBox = new MessageDialog("Restart Failed", result.ToString());
                await msgBox.ShowAsync();
            }
        }

        private void ReNavigate()
        {
            Frame ParentFrame = Window.Current.Content as Frame;
            var LastPage = ParentFrame.CurrentSourcePageType;

            if (LastPage.FullName.Contains(Constants.CARINA))
            {
                ((Frame)Window.Current.Content).Navigate(typeof(Carina.Views.TabHeader));

            }
            else if (LastPage.FullName.Contains(Constants.BOONTA_EVE))
            {
                ((Frame)Window.Current.Content).Navigate(typeof(BoontaEve.Views.TabHeader));

            }
            else if (LastPage.FullName.Contains(Constants.CARBONITE))
            {
                ((Frame)Window.Current.Content).Navigate(typeof(Carbonite.Views.TabHeader));

            }
            else
            {
                ((Frame)Window.Current.Content).Navigate(typeof(MainPage));
            }

        }
    }
}
