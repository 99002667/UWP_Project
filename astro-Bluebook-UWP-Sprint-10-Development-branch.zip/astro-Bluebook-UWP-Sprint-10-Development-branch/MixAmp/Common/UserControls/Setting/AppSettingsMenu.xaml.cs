﻿using MixAmp.BoontaEve.ViewModels;
using MixAmp.Carbonite.ViewModels;
using MixAmp.Common.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Common.UserControls.Setting
{
    public sealed partial class AppSettingsMenu : UserControl
    {
        Windows.Storage.ApplicationDataContainer AppSettingsSpecificData =
    Windows.Storage.ApplicationData.Current.LocalSettings;
        public AppSettingsMenu()
        {
            this.InitializeComponent();
            AppSettingsList.ItemsSource = new AppSettings();
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            StackPanel SettingsStackPanel = (StackPanel)SettingsRelativePanel.Parent;
            FlyoutPresenter SettingsFlyoutPresenter = (FlyoutPresenter)SettingsStackPanel.Parent;
            Popup SettingsPopup = (Popup)SettingsFlyoutPresenter.Parent;

            if (SettingsPopup.IsOpen)
            {
                SettingsPopup.IsOpen = false;
            }
        }

        private void ToggleSwitch_Toggled(object sender, RoutedEventArgs e)
        {
            Windows.UI.Xaml.Controls.ToggleSwitch ToggleSwitch = sender as Windows.UI.Xaml.Controls.ToggleSwitch;
            RelativePanel ToggleSwitchParent = (RelativePanel)ToggleSwitch.Parent;
            if (ToggleSwitchParent != null)
            {
                Grid Grid = (Grid)ToggleSwitchParent.Parent;
                TextBlock Status = (TextBlock)Grid.FindName("Status");
                TextBlock SettingsName = (TextBlock)Grid.FindName("Settings_Name");
                Windows.Storage.ApplicationDataCompositeValue WriteAppSettingsSpecific =
    new Windows.Storage.ApplicationDataCompositeValue();
                var SettingsViewModel = Grid.DataContext;
                //AppSettingsViewModel AppSettingsViewModel = Grid.DataContext as AppSettingsViewModel;	
                if (SettingsViewModel is AppSettingsViewModel)
                {
                    AppSettingsViewModel AppSettingsViewModel = (AppSettingsViewModel)SettingsViewModel;
                    if (ToggleSwitch.IsOn)
                    {
                        AppSettingsViewModel.Status = "On";
                        WriteAppSettingsSpecific[SettingsName.Text] = (bool)true;
                    }
                    else if (!ToggleSwitch.IsOn)
                    {
                        AppSettingsViewModel.Status = "Off";
                        WriteAppSettingsSpecific[SettingsName.Text] = (bool)false;
                    }
                    Status.Text = AppSettingsViewModel.Status;
                    AppSettingsSpecificData.Values[SettingsName.Text] = WriteAppSettingsSpecific;
                }
                else if (SettingsViewModel is AstroA30AppSettingsViewModel)
                {
                    AstroA30AppSettingsViewModel AstroA30AppSettingsViewModel = (AstroA30AppSettingsViewModel)SettingsViewModel;
                    if (ToggleSwitch.IsOn)
                    {
                        AstroA30AppSettingsViewModel.Status = "On";
                        WriteAppSettingsSpecific[SettingsName.Text] = (bool)true;
                    }
                    else if (!ToggleSwitch.IsOn)
                    {
                        AstroA30AppSettingsViewModel.Status = "Off";
                        WriteAppSettingsSpecific[SettingsName.Text] = (bool)false;
                    }
                    Status.Text = AstroA30AppSettingsViewModel.Status;
                    AppSettingsSpecificData.Values[SettingsName.Text] = WriteAppSettingsSpecific;

                }
            }
        }

        private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        {
            RelativePanel CurrentMenuParent = this.Parent as RelativePanel;
            UIElementCollection UIElements = CurrentMenuParent.Children;

            foreach (var UIElement in UIElements)
            {
                if (UIElement is AppSettingsMenu)
                {
                    if (this.Visibility == Visibility.Visible)
                    {
                        this.Visibility = Visibility.Collapsed;
                    }
                }
                else if (UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = UIElement as MainSettingsMenu;
                    if (MainSettingsMenu.Visibility == Visibility.Collapsed)
                    {
                        MainSettingsMenu.Visibility = Visibility.Visible;
                    }
                }
            }
        }

        private void Arrow_Right_Click(object sender, RoutedEventArgs e)
        {
            Button Arrow_Right = sender as Button;
            var SettingsViewModel = Arrow_Right.DataContext;
            if (SettingsViewModel is AppSettingsViewModel)
            {
                AppSettingsViewModel AppSettingsViewModel = (AppSettingsViewModel)SettingsViewModel;
                var name = AppSettingsViewModel.Name;
                switch (name)
                {
                    case "Notifications":
                        //this.ShowDeviceSettingsMenu();
                        break;
                    case "Privacy Disclaimer":
                        //var uri = new Uri(URIConstant.SubmitFeedback);

                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;

                        // Launch the URI with a warning prompt
                        var submitsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.PrivacyDisclaimer));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.SubmitFeedback);
                        break;
                    case "Shop Astro":
                        //var uri = new Uri(URIConstant.ShopAstro);

                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;

                        // Launch the URI with a warning prompt
                        var shopsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.ShopAstro));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.ShopAstro);
                        break;
                    case "Language":
                        ShowLanguageSettingsMenu();
                        break;
                    default:
                        break;
                }
                //if (MainSettingsViewModel.Name.Equals("Mixamp Studio"))
                //{
                //    this.ShowDeviceSettingsMenu();

                //}
                //else if (MainSettingsViewModel.Name.Equals("Application"))
                //{
                //    this.ShowAppSettingsMenu();
                //}
            }
            else if (SettingsViewModel is AstroA30AppSettingsViewModel)
            {
                AstroA30AppSettingsViewModel AstroA30MainSettingsViewModel = (AstroA30AppSettingsViewModel)SettingsViewModel;
                var name = AstroA30MainSettingsViewModel.Name;
                switch (name)
                {
                    case "Privacy Disclaimer":
                        //var uri = new Uri(URIConstant.SubmitFeedback);

                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;

                        // Launch the URI with a warning prompt
                        var privacy = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.PrivacyDisclaimer));
                        break;
                    case "Support":
                        //this.ShowDeviceSettingsMenu();
                        break;
                    case "Submit Feedback":
                        //var uri = new Uri(URIConstant.SubmitFeedback);

                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;

                        // Launch the URI with a warning prompt
                        var submitsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.SubmitFeedback));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.SubmitFeedback);
                        break;
                    case "Shop Astro":
                        //var uri = new Uri(URIConstant.ShopAstro);

                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;

                        // Launch the URI with a warning prompt
                        var shopsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.ShopAstro));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.ShopAstro);
                        break;
                    case "Language":
                        ShowLanguageSettingsMenu();
                        break;
                    default:
                        break;
                }
                //if (AstroA30MainSettingsViewModel.Name.Equals("Astro A30"))
                //{
                //    this.ShowDeviceSettingsMenu();
                //}
                //else if (AstroA30MainSettingsViewModel.Name.Equals("Application"))
                //{
                //    this.ShowAppSettingsMenu();
                //}
            }
            else if (SettingsViewModel is BoontaEveMainSettingsViewModel)
            {
                BoontaEveMainSettingsViewModel BoontaEveMainSettingsViewModel = (BoontaEveMainSettingsViewModel)SettingsViewModel;
                var name = BoontaEveMainSettingsViewModel.Name;
                switch (name)
                {

                    case "Privacy Disclaimer":
                        //this.ShowDeviceSettingsMenu();
                        break;
                    case "Submit Feedback":
                        //var uri = new Uri(URIConstant.SubmitFeedback);

                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;

                        // Launch the URI with a warning prompt
                        var submitsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.SubmitFeedback));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.SubmitFeedback);
                        break;
                    case "Shop Astro":
                        //var uri = new Uri(URIConstant.ShopAstro);

                        // Set the option to show a warning
                        //var options = new Windows.System.LauncherOptions();
                        //options.TreatAsUntrusted = true;

                        // Launch the URI with a warning prompt
                        var shopsuccess = Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.ShopAstro));
                        //helpLinkButton.NavigateUri = new Uri(URIConstant.ShopAstro);
                        break;
                    default:
                        break;
                }
                //if (BoontaEveMainSettingsViewModel.Name.Equals("Mixamp Pro TR"))
                //{
                //    this.ShowBoontaEveDeviceSettingsMenu();
                //}
                //else if (BoontaEveMainSettingsViewModel.Name.Equals("Application"))
                //{
                //    this.ShowAppSettingsMenu();
                //}
            }

        }

        private void ShowLanguageSettingsMenu()
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            UIElementCollection UIElements = SettingsRelativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is LanguageSettingsMenu)
                {
                    LanguageSettingsMenu LanguageSettingsMenu = (LanguageSettingsMenu)UIElement;
                    LanguageSettingsMenu.Visibility = Visibility.Visible;
                }
                else if (UIElement is AppSettingsMenu)
                {
                    AppSettingsMenu AppSettingsMenu = (AppSettingsMenu)UIElement;
                    AppSettingsMenu.Visibility = Visibility.Collapsed;
                }
            }
        }
    }
}
