﻿using MixAmp.Carbonite.ViewModels;
using MixAmp.Carbonite.Views;
using MixAmp.Common.ViewModels;
using MixAmp.Common.Views;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Common.UserControls
{
    public sealed partial class TestSound : UserControl
    {
        public TestSound()
        {
            this.InitializeComponent();
            this.DataContext = this;
            TestSoundList.ItemsSource = new TestSounds();
        }

        private void Arrow_Down_Click(object sender, RoutedEventArgs e)
        {
            Button Arrow_Down = (Button)sender;
            RelativePanel ArrowPanel = (RelativePanel)Arrow_Down.Parent;
            Button Arrow_Up = (Button)ArrowPanel.FindName("Arrow_Up");
            Arrow_Down.Visibility = Visibility.Collapsed;
            Arrow_Up.Visibility = Visibility.Visible;
            if (TestSoundList.Visibility == Visibility.Collapsed)
            {
                TestSoundList.Visibility = Visibility.Visible;
            }
        }

        private void Arrow_Up_Click(object sender, RoutedEventArgs e)
        {
            Button Arrow_Up = (Button)sender;
            RelativePanel ArrowPanel = (RelativePanel)Arrow_Up.Parent;
            Button Arrow_Down = (Button)ArrowPanel.FindName("Arrow_Down");
            Arrow_Up.Visibility = Visibility.Collapsed;
            Arrow_Down.Visibility = Visibility.Visible;
            if (TestSoundList.Visibility == Visibility.Visible)
            {
                TestSoundList.Visibility = Visibility.Collapsed;
            }
        }

        //private void TestSoundList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    ListView TestSoundList = (ListView)sender;
        //    foreach (var item in TestSoundList.Items)
        //    {
        //        ListViewItem ListViewItem = TestSoundList.ContainerFromItem(item) as ListViewItem;
        //        TestSoundViewModel testSoundViewModel = (TestSoundViewModel)item;
        //        if (ListViewItem.IsSelected)
        //        {
        //            TestSound_Type.Text = testSoundViewModel.Name;
        //        }
        //    }
        //}
        private void TestSoundList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListView TestSoundList = (ListView)sender;
            foreach (var item in TestSoundList.Items)
            {
                ListViewItem ListViewItem = TestSoundList.ContainerFromItem(item) as ListViewItem;
                if (ListViewItem != null)
                {
                    TestSoundViewModel testSoundViewModel = (TestSoundViewModel)item;
                    if (ListViewItem.IsSelected)
                    {
                        TestSound_Type.Text = testSoundViewModel.Name;
                        Frame parentFrame = Window.Current.Content as Frame;
                        var lastpage = parentFrame.SourcePageType;
                        if (lastpage.FullName.Contains("Carbonite"))
                        {
                            var stack = this.Parent as StackPanel;
                            var grid = stack.Parent as Grid;
                            var carbonitepreset = grid.Parent as CarbonitePresetScreen;
                            var equalizerscreen = grid.Parent as EqualizerScreen;
                            if (equalizerscreen != null)
                            {
                                var relative = equalizerscreen.Parent as RelativePanel;
                                var carbonitepreset1 = relative.FindName("CarbonitePresetScreen") as CarbonitePresetScreen;
                                var testSound = carbonitepreset1.FindName("testSound") as TestSound;
                                var testSoundListView = testSound.FindName("TestSoundList") as ListView;
                                var TestSound_TypeInside = testSound.FindName("TestSound_Type") as TextBlock;
                                TestSound_TypeInside.Text = testSoundViewModel.Name;
                                if (testSoundViewModel.Name == "Immersive")
                                {
                                    testSoundListView.SelectedIndex = 0;
                                }
                                else
                                {
                                    testSoundListView.SelectedIndex = 1;
                                }
                                AstroA30DatabaseFunctions.UpdateTestSound(testSoundViewModel.Name);
                            }
                            else
                            {
                                var relative = carbonitepreset.Parent as RelativePanel;
                                var equalizerscreen1 = relative.FindName("EqualizerScreen") as EqualizerScreen;
                                var testSound = equalizerscreen1.FindName("testSound") as TestSound;
                                var testSoundListView = testSound.FindName("TestSoundList") as ListView;
                                var TestSound_TypeInside = testSound.FindName("TestSound_Type") as TextBlock;
                                TestSound_TypeInside.Text = testSoundViewModel.Name;
                                if (testSoundViewModel.Name == "Immersive")
                                {
                                    testSoundListView.SelectedIndex = 0;
                                }
                                else
                                {
                                    testSoundListView.SelectedIndex = 1;
                                }
                                AstroA30DatabaseFunctions.UpdateTestSound(testSoundViewModel.Name);
                            }
                        }
                    }

                }
            }
        }
    }
}

