﻿using MixAmp.Carina.Views;
using MixAmp.Common.ViewModels;
using MixAmp.Common.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Common.UserControls.Mixer
{
    public sealed partial class MixerLeftPanel_UserControl : UserControl
    {
        Size size;
        public MixerLeftPanel_UserControl()
        {
            // DataContext = new MixerViewModel();
            this.InitializeComponent();
            //this.DataContext = new MixerViewModel();
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
             size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            //scrlist.Height = size.Height - 480;
            //listPanel.Height = size.Height - 200;
            scrlist.Height = size.Height - 220;
            listPanel.Height = size.Height - 210;
            //MixerList.ItemsSource = new MixerMonitor();
            //AddedList.ItemsSource = new AddedMixer();
            //MixerList1.ItemsSource = new MixerMonitorNew();
            //AddedList1.ItemsSource = new AddedMixerNew();
            var languagueSelected = Utils.LanguageSettingsUtils.ReadLanguageSettings();

            if (languagueSelected.ToUpper() == "ARABIC")
            {
               //if (scaleFactor == 1) { 
                
                //    //imgSpeeker.Margin = new Thickness(0, 17, 0, 0);
                    

                //} 
                 if (scaleFactor == 1.25)
                {
                    Slider.Width = 230;
                    Slider.Margin = new Thickness(-10, 0, 0, 0);
                    imgSpeeker.Margin = new Thickness(15, 17, 0, 0);
                    stkrect.Margin = new Thickness(80, -13, 0, 0);
                }
                else if (scaleFactor == 1.5)
                {
                    Slider.Width = 245;

                }
                else if (scaleFactor == 1.75)
                {
                    Slider.Width = 255;
                    Slider.Margin = new Thickness(-15, 0, 0, 0);
                }

            }
            else
            {
                if (scaleFactor == 1.25)
                {
                    Slider.Width = 230;
                }
                else if (scaleFactor == 1.5)
                {
                    Slider.Width = 245;
                }
                else if (scaleFactor == 1.75)
                {
                    Slider.Width = 255;
                }
            }
            //SourceA.DataContext = App.Mixercls[0].SourceA;
            //SourceB.DataContext = App.Mixercls[0].SourceB; 
            //  this.DataContext = new MixerViewModel();
            //TestSoundList.ItemsSource = new TestSounds();
        }
        //private void RoutingList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{

        //}
        private void Slider_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            try
            {
                string value = String.Format(e.NewValue.ToString());
                sliderValue.Text = value + "%";

                if (sliderValue.Text == "0%")
                {
                    imgSpeeker.Source = new BitmapImage(new Uri("ms-appx:///Assets/Mute_Gray.png"));
                }
                else
                {
                    if (e.NewValue > 1 && e.NewValue < 10)
                    {
                        imgSpeeker.Source = new BitmapImage(new Uri("ms-appx:///Assets/Loud_Speaker.png"));
                    }
                }
                if (e.NewValue > 2)
                {
                    rect1.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect1.Fill = new SolidColorBrush(Colors.Gray);

                }
                if (e.NewValue > 3.5)
                {
                    rect2.Fill = new SolidColorBrush(Colors.White);

                }
                else
                {
                    rect2.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 6)
                {
                    rect3.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect3.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 8.5)
                {
                    rect4.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect4.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 11)
                {
                    rect5.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect5.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 13.5)
                {
                    rect6.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect6.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 16)
                {
                    rect7.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect7.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 18.5)
                {
                    rect8.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect8.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 22)
                {
                    rect9.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect9.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 24.5)
                {
                    rect10.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect10.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 27)
                {
                    rect11.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect11.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 29.5)
                {
                    rect12.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect12.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 32)
                {
                    rect13.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect13.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 34.5)
                {
                    rect14.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect14.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 37)
                {
                    rect15.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect15.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 39.5)
                {
                    rect16.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect16.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 42)
                {
                    rect17.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect17.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 44.5)
                {
                    rect18.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect18.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 47)
                {
                    rect19.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect19.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 49.5)
                {
                    rect20.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect20.Fill = new SolidColorBrush(Colors.Gray);
                }


                if (e.NewValue > 53)
                {
                    rect21.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect21.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 55.5)
                {
                    rect22.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect22.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 58)
                {
                    rect23.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect23.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 60.5)
                {
                    rect24.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect24.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 63)
                {
                    rect25.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect25.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 65.5)
                {
                    rect26.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect26.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 68)
                {
                    rect27.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect27.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 70.5)
                {
                    rect28.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect28.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 73)
                {
                    rect29.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect29.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 75.5)
                {
                    rect30.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect30.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 78)
                {
                    rect31.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect31.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 80.5)
                {
                    rect32.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect32.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 83)
                {
                    rect33.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect33.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 85.5)
                {
                    rect34.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect34.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue > 88)
                {
                    rect35.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect35.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue >= 90.5)
                {
                    rect36.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect36.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue >= 93)
                {
                    rect37.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect37.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue >= 95.5)
                {
                    rect38.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect38.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue >= 98)
                {
                    rect39.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect39.Fill = new SolidColorBrush(Colors.Gray);
                }
                if (e.NewValue >= 100)
                {
                    rect40.Fill = new SolidColorBrush(Colors.White);
                }
                else
                {
                    rect40.Fill = new SolidColorBrush(Colors.Gray);
                }

            }
            catch (Exception ex)
            {

            }

        }


        //private void Button_Click(object sender, RoutedEventArgs e)
        //{

        //    if (AddedList.Visibility != Visibility.Visible)
        //    {

        //        AddedList.Visibility = Visibility.Visible;
        //        upArrow.Visibility = Visibility.Collapsed;
        //        downArrow.Visibility = Visibility.Visible;
        //    }
        //    else
        //    {
        //        AddedList.Visibility = Visibility.Collapsed;
        //        upArrow.Visibility = Visibility.Visible;
        //        downArrow.Visibility = Visibility.Collapsed;
        //    }
        //}

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (AddedList.Visibility != Visibility.Visible)
            {

                AddedList.Visibility = Visibility.Visible;
                scrlist.Height = size.Height - 380;
                var lists = MixerList.ItemsSource as ObservableCollection<MixerViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {

                    item.notvisiblearrow = Visibility.Visible;
                    item.visiblearrow = Visibility.Collapsed;
                }

                MixerList.ItemsSource = null;
                MixerList.ItemsSource = lists;

                //close other open list 

                AddedList1.Visibility = Visibility.Collapsed;
                var lists1 = MixerList1.ItemsSource as ObservableCollection<MixerViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists1)
                {
                    item.notvisiblearrow = Visibility.Collapsed;
                    item.visiblearrow = Visibility.Visible;
                }
                MixerList1.ItemsSource = null;
                MixerList1.ItemsSource = lists1;

            }

            else
            {
                AddedList.Visibility = Visibility.Collapsed;
                scrlist.Height = size.Height - 180;
                var lists = MixerList.ItemsSource as ObservableCollection<MixerViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {
                    item.notvisiblearrow = Visibility.Collapsed;
                    item.visiblearrow = Visibility.Visible;
                }
                MixerList.ItemsSource = null;
                MixerList.ItemsSource = lists;


            }
        }
        private void AddedList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                var selecteditem = ((Windows.UI.Xaml.Controls.Primitives.Selector)sender).SelectedValue;
               var viewPage = (((((((((((sender as Selector).Parent as Grid).Parent as StackPanel).Parent as StackPanel).Parent as ScrollViewer).Parent as Grid).Parent as Grid).Parent as MixerLeftPanel_UserControl).Parent as Grid).Parent as Grid).Parent as MixAmpMixerScreen);
                var rightcontrol = viewPage.FindName("MixerRightPanel") as UserControl;
                var sourceATxtBx = rightcontrol.FindName("SourceA1") as TextBlock;
                sourceATxtBx.Text = ((MixerViewModel)selecteditem).InputDevicename;
                var lists = MixerList.ItemsSource as ObservableCollection<MixerViewModel>;
                // Your UI update code goes here!
                foreach (var items in lists)
                {
                    items.Icon = ((MixerViewModel)selecteditem).Icon;
                    
                    if(((MixerViewModel)selecteditem).InputDevicename.Equals("Blutooth Device"))
                    {
                        items.IconMargin = new Thickness(25, 5, 0, -15);
                    }
                    else
                    {
                        items.IconMargin = new Thickness(15, 5, 0, -15);
                    }

                    items.InputDevicename = ((MixerViewModel)selecteditem).InputDevicename;
                    items.notvisiblearrow = Visibility.Collapsed;
                    items.visiblearrow = Visibility.Visible;
                }
                MixerList.ItemsSource = null;
                MixerList.ItemsSource = lists;
                AddedList.Visibility = Visibility.Collapsed;
                scrlist.Height = size.Height - 180;
            }
            catch (Exception ex)
            {

            }


        }


        private void MixerList1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void AddedList1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selecteditem = ((Windows.UI.Xaml.Controls.Primitives.Selector)sender).SelectedValue;
            var viewPageB = (((((((((((sender as Selector).Parent as Grid).Parent as StackPanel).Parent as StackPanel).Parent as ScrollViewer).Parent as Grid).Parent as Grid).Parent as MixerLeftPanel_UserControl).Parent as Grid).Parent as Grid).Parent as MixAmpMixerScreen);
            var rightcontrol = viewPageB.FindName("MixerRightPanel") as UserControl;
            var sourceBTxtBx = rightcontrol.FindName("SourceB1") as TextBlock;
            sourceBTxtBx.Text = ((MixerViewModel)selecteditem).InputDevicename;
            var lists = MixerList1.ItemsSource as ObservableCollection<MixerViewModel>;
            // Your UI update code goes here!
            foreach (var items in lists)
            {
                items.Icon = ((MixerViewModel)selecteditem).Icon;
                items.InputDevicename = ((MixerViewModel)selecteditem).InputDevicename;
                if (((MixerViewModel)selecteditem).InputDevicename.Equals("Blutooth Device"))
                {
                    items.IconMargin = new Thickness(25, 5, 0, -15);
                }
                else
                {
                    items.IconMargin = new Thickness(15, 5, 0, -15);
                }
                //MixerRightPanel_UserControl.SourceB = items.InputDevicename;
                items.notvisiblearrow = Visibility.Collapsed;
                items.visiblearrow = Visibility.Visible;
            }
            MixerList1.ItemsSource = null;
            MixerList1.ItemsSource = lists;
            AddedList1.Visibility = Visibility.Collapsed;
            scrlist.Height = size.Height - 180;

        }




        private void selectArrow2_Click(object sender, RoutedEventArgs e)
        {
            if (AddedList1.Visibility != Visibility.Visible)
            {
                    scrlist.Height = size.Height - 380;
                AddedList1.Visibility = Visibility.Visible;
                
                var lists = MixerList1.ItemsSource as ObservableCollection<MixerViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {

                    item.notvisiblearrow = Visibility.Visible;
                    item.visiblearrow = Visibility.Collapsed;
                }

                MixerList1.ItemsSource = null;
                MixerList1.ItemsSource = lists;

                //Close other open lists
                AddedList.Visibility = Visibility.Collapsed;
               
                var lists1 = MixerList.ItemsSource as ObservableCollection<MixerViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists1)
                {
                    item.notvisiblearrow = Visibility.Collapsed;
                    item.visiblearrow = Visibility.Visible;
                }
                MixerList.ItemsSource = null;
                MixerList.ItemsSource = lists1;
            }

            else
            {
                scrlist.Height = size.Height - 180;
                AddedList1.Visibility = Visibility.Collapsed;
                var lists = MixerList1.ItemsSource as ObservableCollection<MixerViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {
                    item.notvisiblearrow = Visibility.Collapsed;
                    item.visiblearrow = Visibility.Visible;
                }
                MixerList1.ItemsSource = null;
                MixerList1.ItemsSource = lists;


            }
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                Frame parentFrame = Window.Current.Content as Frame;
                parentFrame.Navigate(typeof(Carina.Views.TabHeader));
            }
            catch (Exception ex)
            {


            }
        }

        private void AddedList_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }



    }
}
