﻿using MixAmp.Carina.Views;
using MixAmp.Common.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Common.UserControls.Mixer
{
    public sealed partial class MixerRightPanel_UserControl : UserControl
    {
       // MixAmpMixerScreen MixAmpMixerScreen;
        public MixerRightPanel_UserControl()
        {
            this.InitializeComponent();

        }
        private void Grid_ManipulationDelta(object sender, ManipulationDeltaRoutedEventArgs e)
        {
            //MixAmpMixerScreen = new MixAmpMixerScreen();
            try
            {
                // var txtt = (((this.Parent as ScrollViewer).Parent as Grid).Parent as Grid).Parent as MixAmpMixerScreen;
                var grid = sender as Grid;
                var angle = GetAngle(e.Position, grid.RenderSize);
                (this.DataContext as MixerViewModel).Angle = angle;
                (this.DataContext as MixerViewModel).UpdateSource();
                
            }
            catch (Exception ex)
            {

            }

        }

        public enum Quadrants : int { nw = 2, ne = 1, sw = 4, se = 3 }

        private double GetAngle(Point touchPoint, Size circleSize)
        {
            var _X = touchPoint.X - (circleSize.Width / 2d);
            var _Y = circleSize.Height - touchPoint.Y - (circleSize.Height / 2d);
            var _Hypot = Math.Sqrt(_X * _X + _Y * _Y);
            var _Value = Math.Asin(_Y / _Hypot) * 180 / Math.PI;
            var _Quadrant = (_X >= 0) ?
                (_Y >= 0) ? Quadrants.ne : Quadrants.se :
                (_Y >= 0) ? Quadrants.nw : Quadrants.sw;
            switch (_Quadrant)
            {
                case Quadrants.ne: _Value = 90 - _Value; break;
                case Quadrants.nw: _Value = 270 + _Value; break;
                case Quadrants.se: _Value = 90 - _Value; break;
                case Quadrants.sw: _Value = 270 + _Value; break;
            }
            return _Value;
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            //  this.Frame.Navigate(typeof(NewPage));
        }

        private void LeftIndicatorText_DataContextChanged(FrameworkElement sender, DataContextChangedEventArgs args)
        {
            //var viewpage = (sender as Selector).Parent;
            //var items = MixerLeftPanel_UserControl.FindName("SourceA") as TextBlock;
            //items.Text = LeftIndicatorText.Text;
        }

        //private void LeftIndicatorText_DataContextChanged(FrameworkElement sender, DataContextChangedEventArgs args)
        //{
        //    ////var viewPage = ((sender as Selector).Parent as Grid);
        //    //TextBlock aa = (TextBlock)sender;
        //    //var asd = aa.Parent;
        //    //MixerLeftPanel_UserControl asddd = new MixerLeftPanel_UserControl();
        //    //var txtgame=asddd.FindName("PCGame") as TextBlock;
        //    //txtgame.Text= LeftIndicatorText.Text;
        //    App.sourceAvalue_ = LeftIndicatorText.Text;

        //}
    }


}

