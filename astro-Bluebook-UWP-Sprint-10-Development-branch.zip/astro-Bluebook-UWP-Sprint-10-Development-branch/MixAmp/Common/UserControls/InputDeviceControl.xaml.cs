﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Common.UserControls
{
    public sealed partial class InputDeviceControl : UserControl
    {
        public InputDeviceControl()
        {
            this.InitializeComponent();
            Load();
        }

        private void Load()
        {
            Mute_Cross.Visibility = Visibility.Visible;
            Mute_Mic.Visibility = Visibility.Visible;
            Mic.Visibility = Visibility.Collapsed;
            //rect8.Fill = new SolidColorBrush(Colors.Red);
            txtValue.Text = "0 db";
        }

        private void Slider4_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            int value = Convert.ToInt32(e.NewValue.ToString());
           if((value > 0 && value <= 10))
                txtValue.Text = "0 db";
            if ((value > 10 && value <= 20))
                txtValue.Text = "-1 db";
            if ((value > 20 && value <= 30))
                txtValue.Text = "-2 db";
            if ((value >30 && value <= 40))
                txtValue.Text = "-3 db";
            if ((value > 40 && value <= 50))
                txtValue.Text = "-4 db";
            if ((value > 50 && value <= 60))
                txtValue.Text = "-5 db";
            if ((value > 60 && value <= 70))
                txtValue.Text = "-6 db";
            if ((value > 70 && value <= 80))
                txtValue.Text = "-7 db";
            if ((value > 80 && value <= 90))
                txtValue.Text = "-8 db";
            if ((value > 90 && value <= 95))
                txtValue.Text = "-9 db";
            if ((value == 100))
                txtValue.Text = "-10 db";



            if (value > 0)
            {
                Mute_Cross.Visibility = Visibility.Collapsed;
                Mute_Mic.Visibility = Visibility.Collapsed;
                Mic.Visibility = Visibility.Visible;
            }
            else
            {
                Mute_Cross.Visibility = Visibility.Visible;
                Mute_Mic.Visibility = Visibility.Visible;
                Mic.Visibility = Visibility.Collapsed;
            }

            if (value == 0)
            {
                rect9.Fill = new SolidColorBrush(Colors.Red);
                //rect10.Fill = new SolidColorBrush(Colors.Gray);
                //rect11.Fill = new SolidColorBrush(Colors.Gray);
                //rect12.Fill = new SolidColorBrush(Colors.Gray);
                //rect13.Fill = new SolidColorBrush(Colors.Gray);
                //rect14.Fill = new SolidColorBrush(Colors.Gray);
                //rect15.Fill = new SolidColorBrush(Colors.Gray);
                //rect16.Fill = new SolidColorBrush(Colors.Gray);
                //rect17.Fill = new SolidColorBrush(Colors.Gray);
                //rect18.Fill = new SolidColorBrush(Colors.Gray);
                //rect19.Fill = new SolidColorBrush(Colors.Gray);
                //rect20.Fill = new SolidColorBrush(Colors.Gray);
                //rect21.Fill = new SolidColorBrush(Colors.Gray);
                //rect22.Fill = new SolidColorBrush(Colors.Gray);
                //rect23.Fill = new SolidColorBrush(Colors.Gray);
                //rect24.Fill = new SolidColorBrush(Colors.Gray);
                //rect25.Fill = new SolidColorBrush(Colors.Gray);
                //rect26.Fill = new SolidColorBrush(Colors.Gray);
                //rect27.Fill = new SolidColorBrush(Colors.Gray);
                //rect28.Fill = new SolidColorBrush(Colors.Gray);
                //rect29.Fill = new SolidColorBrush(Colors.Gray);
                //rect30.Fill = new SolidColorBrush(Colors.Gray);
                //rect31.Fill = new SolidColorBrush(Colors.Gray);
                //rect32.Fill = new SolidColorBrush(Colors.Gray);
                //rect33.Fill = new SolidColorBrush(Colors.Gray);
                //rect34.Fill = new SolidColorBrush(Colors.Gray);
                //rect35.Fill = new SolidColorBrush(Colors.Gray);
                //rect36.Fill = new SolidColorBrush(Colors.Gray);
                //rect37.Fill = new SolidColorBrush(Colors.Gray);
                //rect38.Fill = new SolidColorBrush(Colors.Gray);
                //rect39.Fill = new SolidColorBrush(Colors.Gray);
                //rect40.Fill = new SolidColorBrush(Colors.Gray);
                //rect41.Fill = new SolidColorBrush(Colors.Gray);
            }

            if (value > 2.38)
            {
                rect10.Fill = new SolidColorBrush(Colors.Red);
                rect9.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect10.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if(value == 3.8)
            //    rect9.Fill = new SolidColorBrush(Colors.White);
            if (value > 4.8)
            {
                rect11.Fill = new SolidColorBrush(Colors.Red);
                rect10.Fill = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                rect11.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 7.1)
            {
                rect12.Fill = new SolidColorBrush(Colors.Red);
                rect10.Fill = new SolidColorBrush(Colors.White);
                rect11.Fill = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                rect12.Fill = new SolidColorBrush(Colors.Gray);

            }
            //if (value == 7.6)
            //    rect10.Fill = new SolidColorBrush(Colors.White);
            if (value > 9.52)
            {
                rect13.Fill = new SolidColorBrush(Colors.Red);
                rect12.Fill = new SolidColorBrush(Colors.Gray);
            }
            else
            {
                rect13.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 11.9)
            {
                rect14.Fill = new SolidColorBrush(Colors.Red);
                rect13.Fill = new SolidColorBrush(Colors.Gray);
                rect11.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect14.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value == 11.4)
            //    rect11.Fill = new SolidColorBrush(Colors.White);
            if (value > 14.2)
            {
                rect14.Fill = new SolidColorBrush(Colors.Gray);
                rect15.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect15.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 15.2)
            //    rect12.Fill = new SolidColorBrush(Colors.White);
            if (value > 16.6)
            {
                rect16.Fill = new SolidColorBrush(Colors.Red);
                rect15.Fill = new SolidColorBrush(Colors.Gray);
                rect12.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect16.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 19.0)
            {
                rect17.Fill = new SolidColorBrush(Colors.Red);
                rect16.Fill = new SolidColorBrush(Colors.Gray);
                rect13.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect17.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 21.42)
            {
                rect17.Fill = new SolidColorBrush(Colors.Gray);
                rect18.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect18.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 22.8)
            //    rect14.Fill = new SolidColorBrush(Colors.White);
            if (value > 23.8)
            {
                rect18.Fill = new SolidColorBrush(Colors.Gray);
                rect19.Fill = new SolidColorBrush(Colors.Red);
                rect14.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect19.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 26.1)
            {
                rect19.Fill = new SolidColorBrush(Colors.Gray);
                rect20.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect20.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 28.57)
            {
                rect20.Fill = new SolidColorBrush(Colors.Gray);
                rect21.Fill = new SolidColorBrush(Colors.Red);
                rect15.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect21.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 30.9)
            {
                rect21.Fill = new SolidColorBrush(Colors.Gray);
                rect22.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect22.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 33.3)
            {
                rect22.Fill = new SolidColorBrush(Colors.Gray);
                rect23.Fill = new SolidColorBrush(Colors.Red);
                rect16.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect23.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 34.2)
            //    rect17.Fill = new SolidColorBrush(Colors.White);
            if (value > 35.7)
            {
                rect23.Fill = new SolidColorBrush(Colors.Gray);
                rect24.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect24.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 38.08)
            {
                rect24.Fill = new SolidColorBrush(Colors.Gray);
                rect25.Fill = new SolidColorBrush(Colors.Red);
                rect17.Fill = new SolidColorBrush(Colors.White);
                //rect18.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect25.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 40.4)
            {
                rect25.Fill = new SolidColorBrush(Colors.Gray);
                rect26.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect26.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 42.6)
            //{

            //    rect19.Fill = new SolidColorBrush(Colors.White);
            //}
            if (value > 42.8)
            {
                rect26.Fill = new SolidColorBrush(Colors.Gray);
                rect27.Fill = new SolidColorBrush(Colors.Red);
                rect18.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect27.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 45.22)
            {
                rect27.Fill = new SolidColorBrush(Colors.Gray);
                rect28.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect28.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if(value > 46.4)
            //    rect18.Fill = new SolidColorBrush(Colors.White);
            if (value > 47.6)
            {
                rect28.Fill = new SolidColorBrush(Colors.Gray);
                rect29.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect29.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 50.2)
            //    rect19.Fill = new SolidColorBrush(Colors.White);
            if (value > 49.9)
            {
                rect29.Fill = new SolidColorBrush(Colors.Gray);
                rect19.Fill = new SolidColorBrush(Colors.White);
                rect30.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect30.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 52.36)
            {
                rect30.Fill = new SolidColorBrush(Colors.Gray);
                rect31.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect31.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 50.2)
            //    rect20.Fill = new SolidColorBrush(Colors.White);
            if (value > 54.7)
            {
                rect31.Fill = new SolidColorBrush(Colors.Gray);
                rect32.Fill = new SolidColorBrush(Colors.Red);
                rect20.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect32.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 57.12)
            {
                rect32.Fill = new SolidColorBrush(Colors.Gray);
                rect33.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect33.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 57.8)
            //{
            //    rect21.Fill = new SolidColorBrush(Colors.White);
            //}
            if (value > 59.5)
            {
                rect33.Fill = new SolidColorBrush(Colors.Gray);
                rect21.Fill = new SolidColorBrush(Colors.White);
                rect34.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect34.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 61.88)
            {
                rect34.Fill = new SolidColorBrush(Colors.Gray);
                rect35.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect35.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 64.2)
            {
                rect35.Fill = new SolidColorBrush(Colors.Gray);
                rect22.Fill = new SolidColorBrush(Colors.White);
                rect36.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect36.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 65.4)
            //{
            //    rect23.Fill = new SolidColorBrush(Colors.White);
            //}
            if (value > 66.6)
            {
                rect36.Fill = new SolidColorBrush(Colors.Gray);
                rect23.Fill = new SolidColorBrush(Colors.White);
                rect37.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect37.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 69)
            {
                rect37.Fill = new SolidColorBrush(Colors.Gray);
                rect38.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect38.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 71.4)
            {
                rect38.Fill = new SolidColorBrush(Colors.Gray);
                rect24.Fill = new SolidColorBrush(Colors.White);
                rect39.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect39.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 73)
            //{
            //    rect25.Fill = new SolidColorBrush(Colors.White);
            //}
            if (value > 73.7)
            {
                rect39.Fill = new SolidColorBrush(Colors.Gray);
                rect40.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect40.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 76)
            {
                rect40.Fill = new SolidColorBrush(Colors.Gray);
                rect25.Fill = new SolidColorBrush(Colors.White);
                rect41.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect41.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 76.8)
            //{
            //    rect26.Fill = new SolidColorBrush(Colors.White);
            //}
            if (value > 78.5)
            {
                rect41.Fill = new SolidColorBrush(Colors.Gray);
                rect42.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect42.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 80.5)
            {
                rect42.Fill = new SolidColorBrush(Colors.Gray);
                rect26.Fill = new SolidColorBrush(Colors.White);

                rect43.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect43.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 83.3)
            {
                rect43.Fill = new SolidColorBrush(Colors.Gray);
                rect44.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect44.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 84.4)
            //{
            //    rect28.Fill = new SolidColorBrush(Colors.White);
            //}
            if (value > 85.6)
            {
                rect44.Fill = new SolidColorBrush(Colors.Gray);
                rect27.Fill = new SolidColorBrush(Colors.White);
                rect45.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect45.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 88)
            {
                rect45.Fill = new SolidColorBrush(Colors.Gray);
                rect46.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect46.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 90)
            {
                rect46.Fill = new SolidColorBrush(Colors.Gray);
                rect28.Fill = new SolidColorBrush(Colors.White);
                rect47.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect47.Fill = new SolidColorBrush(Colors.Gray);
            }
            //if (value > 92)
            //{
            //    rect30.Fill = new SolidColorBrush(Colors.White);
            //}
            if (value > 92.82)
            {
                rect47.Fill = new SolidColorBrush(Colors.Gray);
                rect48.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect48.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 95.2)
            {
                rect48.Fill = new SolidColorBrush(Colors.Gray);
                rect29.Fill = new SolidColorBrush(Colors.White);
                rect49.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect49.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (value > 97.5)
            {
                rect49.Fill = new SolidColorBrush(Colors.Gray);
                rect29.Fill = new SolidColorBrush(Colors.White);
                rect50.Fill = new SolidColorBrush(Colors.Red);
            }
            else
            {
                rect50.Fill = new SolidColorBrush(Colors.Gray);
            }

        }

    }
}
