﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Common.UserControls
{
    public sealed partial class BezierCurve : UserControl
    {
        public BezierCurve()
        {
            this.InitializeComponent();
        }
        private void MySlider_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {

            MyCurve1.Point1 = new Point(50, (250 - (e.NewValue * 2.27)));
            MyCurve1.Point2 = new Point(100, (250 - (e.NewValue * 2.27)));
            MyCurve1.Point3 = new Point(150, (250 - (e.NewValue * 2.27)));
            MyCurve2.Point1 = new Point(225, (250 - (e.NewValue * 2.27)));


        }

        private void MySlider2_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {

            MyCurve2.Point2 = new Point(225, (250 - (e.NewValue * 2.27)));
            MyCurve2.Point3 = new Point(300, (250 - (e.NewValue * 2.27)));
            MyCurve3.Point1 = new Point(375, (250 - (e.NewValue * 2.27)));

        }

        private void MySlider3_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {

            MyCurve3.Point2 = new Point(375, (250 - (e.NewValue * 2.27)));
            MyCurve3.Point3 = new Point(450, (250 - (e.NewValue * 2.27)));
            MyCurve4.Point1 = new Point(525, (250 - (e.NewValue * 2.27)));

        }

        private void MySlider4_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {

            MyCurve4.Point2 = new Point(525, (250 - (e.NewValue * 2.27)));
            MyCurve4.Point3 = new Point(600, (250 - (e.NewValue * 2.27)));
            MyCurve5.Point1 = new Point(675, (250 - (e.NewValue * 2.27)));

        }

        private void MySlider5_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {

            MyCurve5.Point3 = new Point(750, (250 - (e.NewValue * 2.27)));
            MyCurve6.Point1 = new Point(800, (250 - (e.NewValue * 2.27)));
            MyCurve6.Point2 = new Point(850, (250 - (e.NewValue * 2.27)));
            MyCurve5.Point2 = new Point(675, (250 - (e.NewValue * 2.27)));

        }

        private void Bezier_Grid_Loaded(object sender, RoutedEventArgs e)
        {
            var view = DisplayInformation.GetForCurrentView();
            var scale = view.ResolutionScale == ResolutionScale.Invalid ? 1 : view.RawPixelsPerViewPixel;
            var resolution = new Size(view.ScreenWidthInRawPixels, view.ScreenHeightInRawPixels);
            var screenheight = resolution.Height;

            if (scale != 2)
            {
                screenheight = resolution.Height - (resolution.Height * (scale - 1));
            }
            else
            {
                screenheight = resolution.Height - (resolution.Height * (1.75 - 1));
            }

            if (screenheight < 1000 && screenheight > 850)
            {
                var success = BezierScroll.ChangeView(null, null, 0.9f);
            }
            else if (screenheight < 850 && screenheight > 700)
            {
                var success = BezierScroll.ChangeView(null, null, 0.8f);
            }
            else if (screenheight < 700 && screenheight > 450)
            {
                var success = BezierScroll.ChangeView(null, null, 0.7f);
            }
            else if (screenheight < 450)
            {
                var success = BezierScroll.ChangeView(null, null, 0.6f);
            }
        }
    }
}
