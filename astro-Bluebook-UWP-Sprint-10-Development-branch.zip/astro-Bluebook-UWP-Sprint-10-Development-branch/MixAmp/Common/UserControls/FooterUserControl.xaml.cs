﻿using DataAccessLibrary;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Common.UserControls
{
    public sealed partial class FooterUserControl : UserControl
    {
        public FooterUserControl()
        {
            this.InitializeComponent();
            string query = "SELECT* from tblCarina_DeviceSettings";
            DataSet ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            txtDevice.Text = Convert.ToString(tb.Rows[0]["deviceName"]);
        }
        private void Navigate_Home(object sender, RoutedEventArgs e)
        {
            Frame parentFrame = Window.Current.Content as Frame;
            parentFrame.Navigate(typeof(MainPage));
        }
    }
}
