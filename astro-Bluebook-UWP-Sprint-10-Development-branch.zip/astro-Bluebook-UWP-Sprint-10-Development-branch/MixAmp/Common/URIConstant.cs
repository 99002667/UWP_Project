﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MixAmp.Common
{
    public static class URIConstant
    {
        public const string SubmitFeedback = @"https://help.astrogaming.com/hc/en-us/requests/new?";
        public const string ShopAstro = @"http://www.astrogaming.com.";
        public const string PrivacyDisclaimer = @" https://www.logitech.com/en-us/legal/web-privacy-policy.html";
        public const string PrivacyPolicy = @" https://www.logitech.com/en-us/legal/web-privacy-policy.html";
    }
}
