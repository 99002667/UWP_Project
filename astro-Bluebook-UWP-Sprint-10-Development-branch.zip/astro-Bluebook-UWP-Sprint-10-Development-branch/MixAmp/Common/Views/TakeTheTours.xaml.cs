﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Common.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class TakeTheTours : Page
    {
        private string deviceselected;

        public TakeTheTours()
        {
            this.InitializeComponent();
            deviceselected = string.Empty;
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            deviceselected = e.Parameter.ToString();
            switch (deviceselected)
            {
                case "Mixamp Studio":
                    MixAmpTakeTheTourScreens.Visibility = Visibility.Visible;
                    CarboniteTakeTheTourScreens.Visibility = Visibility.Collapsed;
                    break;
                case "Astro A30":
                    MixAmpTakeTheTourScreens.Visibility = Visibility.Collapsed;
                    CarboniteTakeTheTourScreens.Visibility = Visibility.Visible;
                    break;
                case "Alec's A30":
                    MixAmpTakeTheTourScreens.Visibility = Visibility.Collapsed;
                    CarboniteTakeTheTourScreens.Visibility = Visibility.Visible;
                    break;
                default:
                    break;
            }
        }
        private void Close(object sender, RoutedEventArgs e)
        {
            Frame parentFrame = Window.Current.Content as Frame;
            var lastPage = parentFrame.BackStack.Last().SourcePageType;
            if (!lastPage.FullName.Contains("MainPage"))
            {
                ((Frame)Window.Current.Content).GoBack();
            }
            else
            {
                switch (deviceselected)
                {
                    case "Astro A30":
                        ((Frame)Window.Current.Content).Navigate(typeof(MainPage), "Carbonite");
                        break;
                    case "Mixamp Studio":
                        ((Frame)Window.Current.Content).Navigate(typeof(MainPage));
                        break;
                }
            }
        }


    }
}
