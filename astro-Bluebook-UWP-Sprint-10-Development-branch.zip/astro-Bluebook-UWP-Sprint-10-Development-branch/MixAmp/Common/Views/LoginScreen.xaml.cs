﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text.RegularExpressions;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using MixAmp.Common.UserControls;
using Windows.ApplicationModel.Activation;
using System.Threading.Tasks;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Common.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class LoginScreen : Page
    {
        public LoginScreen()
        {
            this.InitializeComponent();
            //Password_TextBox.HorizontalContentAlignment = (HorizontalAlignment)AlignmentX.Center;
            Password_TextBox.HorizontalContentAlignment = (HorizontalAlignment)TextAlignment.Center;
            this.HandleElementFocus(Email_TextBox);
            this.HandleElementFocus(Password_TextBox);

        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            RelativePanel LoginBaseScreenRelativePanel = (RelativePanel)Parent;
            Grid LoginBaseScreenRelativePanelParent = (Grid)LoginBaseScreenRelativePanel.Parent;
            MessageBar MessageBar = (MessageBar)LoginBaseScreenRelativePanelParent.FindName("Message_Bar");
            if (MessageBar.Visibility == Visibility.Visible)
            {
                MessageBar.Visibility = Visibility.Collapsed;
            }
            string Email = Email_TextBox.Text;
            string Password = Password_TextBox.Password;
            bool IsEmailValid = this.IsEmailValid(Email);
            string ValidationErrorMessage = "";
            bool IsError = false;
            if (Email.Length == 0)
            {
                ValidationErrorMessage += "Email ID is empty\n";
                IsError = true;
            }
            else if (!IsEmailValid)
            {
                ValidationErrorMessage += "Email ID is not valid\n";
                IsError = true;
            }
            if (Password.Length == 0)
            {
                ValidationErrorMessage += "Password is empty\n";
                IsError = true;
            }
            if(IsError)
            {
                this.SetMessageBarTimeout(MessageBar, ValidationErrorMessage);
            }
        }

        private MessageBar GetMessageBar()
        {
            RelativePanel LoginBaseScreenRelativePanel = (RelativePanel)Parent;
            Grid LoginBaseScreenRelativePanelParent = (Grid)LoginBaseScreenRelativePanel.Parent;
            MessageBar MessageBar = (MessageBar)LoginBaseScreenRelativePanelParent.FindName("Message_Bar");
            return MessageBar;
        }

        private async void SetMessageBarTimeout(MessageBar MessageBar, string ValidationErrorMessage)
        {
            this.ShowValidationErrorMessage(MessageBar, ValidationErrorMessage);
            await Task.Delay(3000);
            this.HideValidationErrorMessage(MessageBar);
        }

        private bool IsEmailValid(string Email)
        {
            bool isEmail = Regex.IsMatch(Email, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            return isEmail;
        }

        private void ShowValidationErrorMessage(MessageBar MessageBar, string ValidationErrorMessage)
        {
            if (MessageBar.Visibility == Visibility.Collapsed)
            {
                RelativePanel relative = (RelativePanel)MessageBar.FindName("relative");
                TextBlock Message_Text_Box = (TextBlock)MessageBar.FindName("Message_Text");
                Button Close_Message = (Button)MessageBar.FindName("Close_Message");
                Close_Message.VerticalAlignment = VerticalAlignment.Center;
                Message_Text_Box.VerticalAlignment = (VerticalAlignment)AlignmentY.Center;
                Message_Text_Box.TextAlignment = TextAlignment.Center;
                Message_Text_Box.HorizontalTextAlignment = TextAlignment.Center;
                Message_Text_Box.HorizontalAlignment = HorizontalAlignment.Center;

                if (ValidationErrorMessage.Length > 25)
                {
                    relative.Width = 170;
                    relative.Height = 50;                   
                    Close_Message.Margin = new Thickness(0, 10, 0, 0);                    
                    Message_Text_Box.Margin = new Thickness(17, 7, 0, 0);                  
                }
                else
                {
                    relative.Width = 160;
                    relative.Height = 35;                   
                    Close_Message.Margin = new Thickness(0, 2, 0, 0);                   
                    Message_Text_Box.Margin = new Thickness(13, 10, 0, 0);                   
                }
                Message_Text_Box.Text = ValidationErrorMessage;
                MessageBar.Visibility = Visibility.Visible;
            }
        }

        private void HideValidationErrorMessage(MessageBar MessageBar)
        {
            if (MessageBar.Visibility == Visibility.Visible)
            {
                MessageBar.Visibility = Visibility.Collapsed;
            }
        }

        private async void Privacy_Policy_Click(object sender, RoutedEventArgs e)
        {
            await Windows.System.Launcher.LaunchUriAsync(new Uri(URIConstant.PrivacyPolicy));
        }

        private void Create_Account_Click(object sender, RoutedEventArgs e)
        {
            RelativePanel LoginBaseScreenRelativePanel = (RelativePanel)Parent;
            CreateAccountScreen CreateAccountScreen = (CreateAccountScreen)LoginBaseScreenRelativePanel.FindName("CreateAccountScreen");
            MessageBar MessageBar = this.GetMessageBar();

            if (CreateAccountScreen.Visibility == Visibility.Collapsed)
            {
                CreateAccountScreen.Visibility = Visibility.Visible;
                this.Visibility = Visibility.Collapsed;
            }

            if(MessageBar.Visibility == Visibility.Visible)
            {
                MessageBar.Visibility = Visibility.Collapsed;
            }
            
        }

        private void HandleElementFocus(UIElement UIElement)
        {
            if(UIElement is TextBox)
            {
                Email_TextBox.GotFocus += Email_TextBox_GotFocus;
                Email_TextBox.LostFocus += Email_TextBox_LostFocus;
            }
            else if (UIElement is PasswordBox)
            {
                Password_TextBox.GotFocus += Password_TextBox_GotFocus;
                Password_TextBox.LostFocus += Password_TextBox_LostFocus;
            }
        }

        private void Password_TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            PasswordBox PasswordBox = (PasswordBox)sender;
            PasswordBox.PlaceholderText = "Enter your password";
        }

        private void Password_TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            PasswordBox PasswordBox = (PasswordBox)sender;
            PasswordBox.PlaceholderText = "";
        }

        private void Email_TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox EmailTextBox = (TextBox)sender;
            EmailTextBox.PlaceholderText = "Enter your email";
        }

        private void Email_TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox EmailTextBox = (TextBox)sender;
            EmailTextBox.PlaceholderText = "";
        }
    }
}
