﻿using DataAccessLibrary;
using Microsoft.Data.Sqlite;
using MixAmp.BoontaEve.UserControls;
using MixAmp.BoontaEve.ViewModels;
using MixAmp.BoontaEve.Views;
using MixAmp.Carbonite.ViewModels;
using MixAmp.Carina.Views;
using MixAmp.Common.UserControls;
using MixAmp.Common.UserControls.Mixer;
using MixAmp.Common.UserControls.Setting;
using MixAmp.Common.ViewModels;
using MixAmp.Utils;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.Storage;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace MixAmp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        readonly IEnumerable<string> lst;
        const string alec = "Alec's";
        SettingsViewModel _settingsViewModel;
        private string MixAmpName;
        private string A30_Name;
        private string Boontaeve_Name;

        int MaxHeightCarina=700;
        int MaxHeightA30=600;
        int MaxHeightC40=700;
        int MaxHeightA50=700;
        int MaxHeightBoonta=700;

        public MainPage()
        {
            this.InitializeComponent();
            lst = new List<string>() { "MixAmp", "A30", "A50", "C40", "Pro TR" };
            MixAmpName = DeviceSpecificDataViewModel.GetCarinaDeviceName();
            txtDevice.Text = MixAmpName;
            A30_Name = DeviceSpecificDataViewModel.GetCarboniteDeviceName();
            Boontaeve_Name = DeviceSpecificDataViewModel.GetBoontaEveDeviceName();
            //string query = "SELECT* from tblCarina_DeviceSettings";
            //DataSet ds = DataAccess.GetData(query);
            //var tb = ds.Tables[0];
            //MixAmpName = Convert.ToString(tb.Rows[0]["deviceName"]);
            //txtDevice.Text = MixAmpName; 
            //string query2 = "SELECT* from tblCarbonite_DeviceSettings";

            //DataSet ds1 = DataAccess.GetData(query2);
            //var tb1 = ds1.Tables[0];
            //A30_Name = Convert.ToString(tb1.Rows[0]["deviceName"]);
            //string query1 = "SELECT* from tblBoontaEve_DeviceSettings";
            //DataSet ds2 = DataAccess.GetData(query1);
            //var tb2 = ds2.Tables[0];
            //Boontaeve_Name = Convert.ToString(tb2.Rows[0]["deviceName"]);
            LoadPage();
        }

        public void LoadPage()
        {
            // Added the code by Rakesh for resolution of the app 21 Jan 2021
            var view = DisplayInformation.GetForCurrentView();

            // Get the screen resolution (APIs available from 14393 onward).
            var resolution = new Size(view.ScreenWidthInRawPixels, view.ScreenHeightInRawPixels);

            // Calculate the screen size in effective pixels. 
            // Note the height of the Windows Taskbar is ignored here since the app will only be given the maxium available size.
            var scale = view.ResolutionScale == ResolutionScale.Invalid ? 1 : view.RawPixelsPerViewPixel;
            var bounds = new Size(resolution.Width / scale, resolution.Height / scale);

            ApplicationView.PreferredLaunchViewSize = new Size(bounds.Width, bounds.Height);
            ApplicationView.PreferredLaunchWindowingMode = ApplicationViewWindowingMode.PreferredLaunchViewSize;
            // end Added the code 

            _settingsViewModel = new SettingsViewModel();
            //txtDevice.Text = alec + " Mixamp";
            btnMixAmp.Visibility = Visibility.Visible;
            btnA30.Visibility = Visibility.Collapsed;
            btnMixAmpPro.Visibility = Visibility.Collapsed;


            ProductImageSizeCheck(resolution.Height-(resolution.Height*(scale-1)));

        }

        private void ProductImageSizeCheck(double screenHeight)
        {
            double imagegrid = (screenHeight / 10) * 7.5;
            if (imagegrid > 250)
            {
                imgMixAmp.MaxHeight = (screenHeight > 1000) ? MaxHeightCarina : imagegrid - 75;
                imgA30.MaxHeight = (screenHeight > 1000) ? MaxHeightA30 : imagegrid - 175;
                imgA50.MaxHeight = (screenHeight > 1000) ? MaxHeightA50 : imagegrid - 65;
                imgC40.MaxHeight = (screenHeight > 1000) ? MaxHeightC40 : imagegrid - 175;
                imgBoonta.MaxHeight = (screenHeight > 1000) ? MaxHeightBoonta : imagegrid - 75;
            }
            else {
                imgMixAmp.MaxHeight =  imagegrid + 100;
                imgA30.MaxHeight = imagegrid + 100;
                imgA50.MaxHeight =  imagegrid + 100;
                imgC40.MaxHeight = imagegrid + 100;
                imgBoonta.MaxHeight = imagegrid  + 100;

            }
            
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            if (e.Parameter != null)
            {
                var text = e.Parameter.ToString();
                if (text == "Carbonite")
                {
                    txtDevice.Text = alec + " A30";
                    btnA30.Visibility = Visibility.Visible;
                    imgBattery.Visibility = Visibility.Visible;
                    btnA50.Visibility = Visibility.Collapsed;
                    btnMixAmp.Visibility = Visibility.Collapsed;
                }
                else if (text == "Alec's A30")
                {
                    txtDevice.Text = A30_Name;
                    btnA30.Visibility = Visibility.Visible;
                    imgBattery.Visibility = Visibility.Visible;
                    btnMixAmp.Visibility = Visibility.Collapsed;
                    btnA50.Visibility = Visibility.Collapsed;
                }
                else if (text == "BoontaEve")
                {
                    txtDevice.Text = Boontaeve_Name;
                    btnMixAmpPro.Visibility = Visibility.Visible;
                    btnMixAmp.Visibility = Visibility.Collapsed;
                    btnA50.Visibility = Visibility.Collapsed;
                    btnC40.Visibility = Visibility.Collapsed;
                    imgBattery.Visibility = Visibility.Collapsed;
                }

            }
            LanguageUtils.CheckUserPreferredLanguage();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var button = (Button)sender;
                Frame parentFrame = Window.Current.Content as Frame;
                // Test12();
                switch (button.Name)
                {
                    case "btnMixAmp":
                        this.Frame.Navigate(typeof(Carina.Views.TabHeader));
                        MixAmpMixerScreen MixCarina = new MixAmpMixerScreen();
                        return;
                    case "btnA30":
                        AstroA30DatabaseFunctions.CreateCarboniteTable();
                        this.Frame.Navigate(typeof(Carbonite.Views.TabHeader));
                        return;
                    case "btnMixAmpPro":
                        this.Frame.Navigate(typeof(BoontaEve.Views.TabHeader));
                        BoontaEve.Views.TabHeader bnt = new BoontaEve.Views.TabHeader();
                        BoontaEveMixerScreen MixBoonta = new BoontaEveMixerScreen();
                        return;
                }


                //string[] files = Directory.GetFiles("/BoontaEve", "*", SearchOption.AllDirectories);
                //var item =  ApplicationData.Current.LocalFolder.TryGetItemAsync("/BoontaEve/Views/TabHeader");

                //string rootDirectory = Windows.ApplicationModel.Package.Current.InstalledLocation.Path;
                //string path = rootDirectory + @"\Carina";

                //IReadOnlyList<StorageFile>  files1 =await ApplicationData.Current.LocalFolder.GetFileAsync();

                //var storageFolder = await ApplicationData.Current.LocalFolder.GetFolderAsync("Assets");
                //var files = await storageFolder.GetFilesAsync();

                //StorageFolder folder = StorageFolder.GetFolderFromPathAsync(path);

                // this.Frame.Navigate(typeof(BoontaEve.Views.TabHeader));
            }
            catch (Exception ex)
            {

            }
        }
        public static string Test12()
        {

            //var enviroment = System.Environment.CurrentDirectory;
            //string projectDirectory = Directory.GetParent(enviroment).Parent.FullName;

            String appSettingsPath = Directory.GetCurrentDirectory();

            if (!File.Exists(Path.Combine(appSettingsPath, "appsettings.json")))
                appSettingsPath = Path.GetDirectoryName(Path.GetDirectoryName(appSettingsPath));

            //var storageFolder = await ApplicationData.Current.LocalFolder.GetFolderAsync("Carina");
            //  var files = await storageFolder.GetFilesAsync();
            // string[] files12 = Directory.GetFiles("~/MixAmp", "*", SearchOption.AllDirectories);
            //  var asd = Directory.Exists("~/Carina");
            //var sas = Directory.GetDirectoryRoot()
            // var item = ApplicationData.Current.LocalFolder.TryGetItemAsync("/BoontaEve/Views/TabHeader");
            // StorageFolder folder = StorageFolder.GetFolderFromPathAsync(path);
            return null;
        }

        private void Navigation_Right(object sender, RoutedEventArgs e)
        {
            //var navigatedevice = txtDevice.Text;
            if (txtDevice.Text == (string)MixAmpName)
            {
                txtDevice.Text = alec + " A50";
                imgBattery.Visibility = Visibility.Visible;
                btnA50.Visibility = Visibility.Visible;
                btnMixAmp.Visibility = Visibility.Collapsed;
                btnA30.Visibility = Visibility.Collapsed;
                btnMixAmpPro.Visibility = Visibility.Collapsed;
            }
            else if (txtDevice.Text == Boontaeve_Name)
            {
                txtDevice.Text = MixAmpName;
                btnMixAmp.Visibility = Visibility.Visible;
                btnMixAmpPro.Visibility = Visibility.Collapsed;
                imgBattery.Visibility = Visibility.Collapsed;
                btnA30.Visibility = Visibility.Collapsed;
            }
            else if (txtDevice.Text == A30_Name)
            {
                txtDevice.Text = alec + " C40";
                btnC40.Visibility = Visibility.Visible;
                imgBattery.Visibility = Visibility.Visible;
                btnA30.Visibility = Visibility.Collapsed;
                btnMixAmp.Visibility = Visibility.Collapsed;
                btnMixAmpPro.Visibility = Visibility.Collapsed;
            }
            else if (txtDevice.Text == "Alec's A50")
            {
                txtDevice.Text = A30_Name;
                btnA30.Visibility = Visibility.Visible;
                imgBattery.Visibility = Visibility.Visible;
                btnA50.Visibility = Visibility.Collapsed;
                btnMixAmp.Visibility = Visibility.Collapsed;
                btnMixAmpPro.Visibility = Visibility.Collapsed;
            }
            else if (txtDevice.Text == "Alec's C40")
            {
                txtDevice.Text = Boontaeve_Name;
                btnMixAmpPro.Visibility = Visibility.Visible;
                btnC40.Visibility = Visibility.Collapsed;
                imgBattery.Visibility = Visibility.Collapsed;
                btnMixAmp.Visibility = Visibility.Collapsed;
                btnA30.Visibility = Visibility.Collapsed;
            }
            //switch (navigatedevice)
            //{
            //    //case "Alec's Mixamp":
            //    //    txtDevice.Text = alec + " A50";
            //    //    imgBattery.Visibility = Visibility.Visible;
            //    //    btnA50.Visibility = Visibility.Visible;
            //    //    btnMixAmp.Visibility = Visibility.Collapsed;
            //    //    break;
            //    case "Alec's A50":
            //        txtDevice.Text = alec + " A30";
            //        btnA30.Visibility = Visibility.Visible;
            //        imgBattery.Visibility = Visibility.Visible;
            //        btnA50.Visibility = Visibility.Collapsed;
            //        break;
            //    case "Alec's A30":
            //        txtDevice.Text = alec + " C40";
            //        btnC40.Visibility = Visibility.Visible;
            //        imgBattery.Visibility = Visibility.Visible;
            //        btnA30.Visibility = Visibility.Collapsed;
            //        break;
            //    case "Alec's C40":
            //        txtDevice.Text = alec + " Mixamp Pro TR";
            //        btnMixAmpPro.Visibility = Visibility.Visible;
            //        btnC40.Visibility = Visibility.Collapsed;
            //        imgBattery.Visibility = Visibility.Collapsed;
            //        break;
            //    //case "Alec's Mixamp Pro TR":
            //    //    txtDevice.Text = alec + " Mixamp";
            //    //    btnMixAmp.Visibility = Visibility.Visible;
            //    //    btnMixAmpPro.Visibility = Visibility.Collapsed;
            //    //    imgBattery.Visibility = Visibility.Collapsed;
            //    //    break;

            //}

        }

        private void Navigation_Left(object sender, RoutedEventArgs e)
        {
            var navigatedevice = txtDevice.Text;
            if (txtDevice.Text == (string)MixAmpName)
            {
                txtDevice.Text = Boontaeve_Name;
                btnMixAmpPro.Visibility = Visibility.Visible;
                btnMixAmp.Visibility = Visibility.Collapsed;
                imgBattery.Visibility = Visibility.Collapsed;
                btnA30.Visibility = Visibility.Collapsed;
            }
            else if (txtDevice.Text == "Alec's A50")
            {
                txtDevice.Text = MixAmpName;
                btnMixAmp.Visibility = Visibility.Visible;
                btnA50.Visibility = Visibility.Collapsed;
                imgBattery.Visibility = Visibility.Collapsed;
                btnA30.Visibility = Visibility.Collapsed;
                btnMixAmpPro.Visibility = Visibility.Collapsed;
            }
            else if (txtDevice.Text == A30_Name)
            {
                txtDevice.Text = alec + " A50";
                btnA50.Visibility = Visibility.Visible;
                btnA30.Visibility = Visibility.Collapsed;
                imgBattery.Visibility = Visibility.Visible;
                btnMixAmpPro.Visibility = Visibility.Collapsed;
                btnMixAmp.Visibility = Visibility.Collapsed;
            }
            else if (txtDevice.Text == Boontaeve_Name)
            {
                txtDevice.Text = alec + " C40";
                btnC40.Visibility = Visibility.Visible;
                btnMixAmpPro.Visibility = Visibility.Collapsed;
                imgBattery.Visibility = Visibility.Visible;
                btnA30.Visibility = Visibility.Collapsed;
                btnMixAmp.Visibility = Visibility.Collapsed;
            }
            else if (txtDevice.Text == "Alec's C40")
            {
                txtDevice.Text = A30_Name;
                btnA30.Visibility = Visibility.Visible;
                btnC40.Visibility = Visibility.Collapsed;
                imgBattery.Visibility = Visibility.Visible;
                btnMixAmp.Visibility = Visibility.Collapsed;
                btnMixAmpPro.Visibility = Visibility.Collapsed;
            }
            //switch (navigatedevice)
            //{
            //    //case "Alec's Mixamp":
            //    //    txtDevice.Text = alec + " Mixamp Pro TR";
            //    //    btnMixAmpPro.Visibility = Visibility.Visible;
            //    //    btnMixAmp.Visibility = Visibility.Collapsed;
            //    //    imgBattery.Visibility = Visibility.Collapsed;
            //    //    break;
            //    case "Alec's A50":
            //        txtDevice.Text = alec + " Mixamp";
            //        btnMixAmp.Visibility = Visibility.Visible;
            //        btnA50.Visibility = Visibility.Collapsed;
            //        imgBattery.Visibility = Visibility.Collapsed;
            //        break;
            //    case "Alec's A30":
            //        txtDevice.Text = alec + " A50";
            //        btnA50.Visibility = Visibility.Visible;
            //        btnA30.Visibility = Visibility.Collapsed;
            //        imgBattery.Visibility = Visibility.Visible;
            //        break;
            //    case "Alec's C40":
            //        txtDevice.Text = alec + " A30";
            //        btnA30.Visibility = Visibility.Visible;
            //        btnC40.Visibility = Visibility.Collapsed;
            //        imgBattery.Visibility = Visibility.Visible;
            //        break;
            //    //case "Alec's Mixamp Pro TR":
            //    //    txtDevice.Text = alec + " C40";
            //    //    btnC40.Visibility = Visibility.Visible;
            //    //    btnMixAmpPro.Visibility = Visibility.Collapsed;
            //    //    imgBattery.Visibility = Visibility.Visible;
            //    //    break;

            //}
        }


        ///New setting cahnges 
        ///
        private void Settings(object sender, RoutedEventArgs e)
        {
            Button SettingsButton = (Button)sender;
            Flyout SettingsFlyout = (Flyout)SettingsButton.Flyout;
            StackPanel SettingsStackPanel = (StackPanel)SettingsFlyout.Content;
            UIElementCollection UIElements = SettingsStackPanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is RelativePanel)
                {
                    RelativePanel RelativePanel = (RelativePanel)UIElement;
                    this.SetDeviceName(RelativePanel);
                }
            }
        }



        private void SetDeviceName(RelativePanel RelativePanel)
        {
            UIElementCollection UIElements = RelativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = (MainSettingsMenu)UIElement;
                    ListView MainSettingsList = (ListView)MainSettingsMenu.FindName("MainSettingsList");
                    string DeviceName = txtDevice.Text;
                    if (DeviceName.Equals(Boontaeve_Name))
                    {
                        MainSettingsList.ItemsSource = new BoontaEveMainSettings();
                    }
                    else if (DeviceName.Equals(A30_Name))
                    {
                        MainSettingsList.ItemsSource = new AstroA30MainSettings();
                    }
                    else if (DeviceName.Equals(MixAmpName))
                    {
                        MainSettingsList.ItemsSource = new MainSettings();
                    }
                }
                else if (UIElement is DeviceSettingsMenu)
                {
                    DeviceSettingsMenu DeviceSettingsMenu = (DeviceSettingsMenu)UIElement;
                    ListView DeviceSettingsList = (ListView)DeviceSettingsMenu.FindName("DeviceSettingsList");
                    TextBlock DeviceNameText = (TextBlock)DeviceSettingsMenu.FindName("DeviceNameText");
                    string DeviceName = txtDevice.Text;
                    if (DeviceName.Equals(MixAmpName))
                    {
                        DeviceSettingsList.ItemsSource = new DeviceSettings();
                        DeviceNameText.Text = MixAmpName;
                        //DeviceNameText.Text = "Mixamp Studio";
                    }
                    else if (DeviceName.Equals(A30_Name))
                    {
                        DeviceSettingsList.ItemsSource = new AstroA30DeviceSettings();
                        DeviceNameText.Text = A30_Name;
                        //DeviceNameText.Text = "Astro A30";
                    }
                    else if (DeviceName.Equals(Boontaeve_Name))
                    {
                        DeviceSettingsList.ItemsSource = new BoontaEveDeviceSettings();
                        DeviceNameText.Text = Boontaeve_Name;
                        //DeviceNameText.Text = "Alec's MIXAMP PRO TR";
                    }

                    //this.SetNameInDeviceSettingsList(DeviceSettingsMenu);
                }
                else if (UIElement is AppSettingsMenu)
                {
                    AppSettingsMenu AppSettingsMenu = (AppSettingsMenu)UIElement;
                    ListView AppSettingsList = (ListView)AppSettingsMenu.FindName("AppSettingsList");
                    string DeviceName = txtDevice.Text;
                    if (DeviceName.Equals(Boontaeve_Name))
                    {
                        AppSettingsList.ItemsSource = new AppSettings();
                    }
                    else if (DeviceName.Equals(A30_Name))
                    {
                        AppSettingsList.ItemsSource = new AstroA30AppSettings();
                    }
                    else if (DeviceName.Equals(MixAmpName))
                    {
                        AppSettingsList.ItemsSource = new AppSettings();
                    }


                }
                else if (UIElement is BoontaEveDeviceSettingsMenu)
                {
                    BoontaEveDeviceSettingsMenu BoontaEveDeviceSettingsMenu = (BoontaEveDeviceSettingsMenu)UIElement;
                    string DeviceName = txtDevice.Text;
                    //if (DeviceName.Equals(alec + " Mixamp Pro TR"))
                    if (DeviceName.Equals(Boontaeve_Name))
                    {
                        TextBlock DeviceNameText = (TextBlock)BoontaEveDeviceSettingsMenu.FindName("DeviceNameText");
                        DeviceNameText.Text = Boontaeve_Name;
                    }
                }

            }
        }
        private void settings_flyout_Closed(object sender, object e)
        {
            if (btnMixAmp.Visibility == Visibility.Visible)
            {
                MixAmpName = DeviceSpecificDataViewModel.GetCarinaDeviceName();
                txtDevice.Text = MixAmpName;
            }
            else if (btnMixAmpPro.Visibility == Visibility.Visible)
            {
                Boontaeve_Name = DeviceSpecificDataViewModel.GetBoontaEveDeviceName();
                txtDevice.Text = Boontaeve_Name;
            }
            else if (btnA30.Visibility == Visibility.Visible)
            {
                A30_Name = DeviceSpecificDataViewModel.GetCarboniteDeviceName();
                txtDevice.Text = A30_Name;
            }
            Flyout flyout = (sender) as Flyout;
            var SettingsStackPanel = flyout.Content as StackPanel;
            UIElementCollection UIElements = SettingsStackPanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is RelativePanel)
                {
                    RelativePanel RelativePanel = (RelativePanel)UIElement;
                    this.RefreshSettingsUI(RelativePanel);
                }
            }
        }
        private void RefreshSettingsUI(RelativePanel relativePanel)
        {
            UIElementCollection UIElements = relativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is MainSettingsMenu)
                {
                    UIElement.Visibility = Visibility.Visible;
                }
                else
                {
                    UIElement.Visibility = Visibility.Collapsed;
                }
            }
        }
    }
}
