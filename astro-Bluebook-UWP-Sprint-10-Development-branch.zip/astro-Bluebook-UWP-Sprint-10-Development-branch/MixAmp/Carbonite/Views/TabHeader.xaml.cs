﻿using MixAmp.Common.UserControls;
using MixAmp.Common.Views;
using MixAmp.Common.UserControls.Setting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using MixAmp.Carbonite.ViewModels;
using System.Data;
using DataAccessLibrary;
using MixAmp.Common.ViewModels;
using Windows.UI;
using Windows.UI.ViewManagement;
using Windows.Graphics.Display;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Carbonite.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class TabHeader : Page
    {
        public TabHeader()
        {
            try
            {
                this.InitializeComponent();
                Load();
                AppCenter.Start("df4cf793-71ba-4be4-a7b8-10df5904dbd0",
                       typeof(Analytics), typeof(Crashes));
            }
            catch (Exception ex)
            {
                ErrorAttachmentLog.AttachmentWithText(ex.Message, ex.StackTrace.ToString());
                throw;
                //throw;
            }
            //this.InitializeComponent();
        }

        private void Load()
        {
            Size ScreenSize = this.GetScreenResolution();
            double ScreenWidth = this.GetScreenWidth(ScreenSize);
            internalprofile.MaxWidth = (ScreenWidth / 2)-50;
            Group.MaxWidth = internalprofile.MaxWidth - 250;

            var footercontrol = TabHeaderView.FindName("FooterControl") as UserControl;
            var text = footercontrol.FindName("txtDevice") as TextBlock;
            var battery = footercontrol.FindName("imgBattery") as Image;
            battery.Visibility = Visibility.Visible;
            //string query1 = "SELECT* from tblCarbonite_DeviceSettings";
            //DataSet ds1 = DataAccess.GetData(query1);
            //var tb1 = ds1.Tables[0];
            //text.Text = Convert.ToString(tb1.Rows[0]["deviceName"]);
            //text.Text = "Alec's A30";
            text.Text = DeviceSpecificDataViewModel.GetCarboniteDeviceName();
        }

        private Size GetScreenResolution()
        {
            var bounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            Size size = new Size(bounds.Width * scaleFactor, bounds.Height * scaleFactor);
            return size;
        }
        private double GetScreenHeight(Size size)
        {
            return size.Height;
        }

        private double GetScreenWidth(Size size)
        {
            return size.Width;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Settings(object sender, RoutedEventArgs e)
        {
            Button SettingsButton = (Button)sender;
            Flyout SettingsFlyout = (Flyout)SettingsButton.Flyout;
            StackPanel SettingsStackPanel = (StackPanel)SettingsFlyout.Content;
            UIElementCollection UIElements = SettingsStackPanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is RelativePanel)
                {
                    RelativePanel RelativePanel = (RelativePanel)UIElement;
                    this.SetDeviceName(RelativePanel);
                }
            }
            // selectedDevice.Text = txtDevice.Text;
        }

        private void SetDeviceName(RelativePanel RelativePanel)
        {
            UIElementCollection UIElements = RelativePanel.Children;
            var basescreen = TabHeaderView.FindName("FooterControl") as UserControl;
            var txtDevice = basescreen.FindName("txtDevice") as TextBlock;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = (MainSettingsMenu)UIElement;
                    ListView MainSettingsList = (ListView)MainSettingsMenu.FindName("MainSettingsList");
                    TextBlock DeviceNameTextBlock = (TextBlock)MainSettingsMenu.FindName("SelectedDevice");
                    string DeviceName = DeviceSpecificDataViewModel.GetCarboniteDeviceName();
                    //string DeviceName = "Astro A30";
                    MainSettingsList.ItemsSource = new AstroA30MainSettings();
                    DeviceNameTextBlock.Text = DeviceName;
                }
                else if (UIElement is DeviceSettingsMenu)
                {
                    DeviceSettingsMenu DeviceSettingsMenu = (DeviceSettingsMenu)UIElement;
                    ListView DeviceSettingsList = (ListView)DeviceSettingsMenu.FindName("DeviceSettingsList");
                    TextBlock DeviceNameText = (TextBlock)DeviceSettingsMenu.FindName("DeviceNameText");
                    DeviceSettingsList.ItemsSource = new AstroA30DeviceSettings();
                    string DeviceName = DeviceSpecificDataViewModel.GetCarboniteDeviceName();
                    //string DeviceName = "Astro A30";
                    DeviceNameText.Text = DeviceName;
                }

                else if (UIElement is AppSettingsMenu)
                {
                    AppSettingsMenu AppSettingsMenu = (AppSettingsMenu)UIElement;
                    ListView AppSettingsList = (ListView)AppSettingsMenu.FindName("AppSettingsList");
                    TextBlock DeviceNameTextBlock = (TextBlock)AppSettingsMenu.FindName("AppSettingsText");

                    string DeviceName = "Application";
                    AppSettingsList.ItemsSource = new AstroA30AppSettings();
                    DeviceNameTextBlock.Text = DeviceName;
                }
            }
        }

        private void settings_flyout_Closed(object sender, object e)
        {
            var footercontrol = TabHeaderView.FindName("FooterControl") as UserControl;
            var footerText = footercontrol.FindName("txtDevice") as TextBlock;
            string A30Name = DeviceSpecificDataViewModel.GetCarboniteDeviceName();
            footerText.Text = A30Name;

            Flyout flyout = (sender) as Flyout;
            var SettingsStackPanel = flyout.Content as StackPanel;
            UIElementCollection UIElements = SettingsStackPanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is RelativePanel)
                {
                    RelativePanel RelativePanel = (RelativePanel)UIElement;
                    this.RefreshSettingsUI(RelativePanel);
                }
            }
        }
        private void RefreshSettingsUI(RelativePanel relativePanel)
        {
            UIElementCollection UIElements = relativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is MainSettingsMenu)
                {
                    UIElement.Visibility = Visibility.Visible;
                }
                else
                {
                    UIElement.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            //if (settings_flyout.IsOpen)
            //{
            //    settings_flyout.Hide();
            //}
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            bool navigationdone = false;
            string input = string.Empty;
            if (e.Parameter != null)
            {
                var text = ((Windows.UI.Xaml.FrameworkElement)e.Parameter).Name;
                // var controls = (Controls)e.Parameter;
                if (e.Parameter.GetType() == typeof(TextBlock))
                {
                    input = ((Windows.UI.Xaml.Controls.TextBlock)e.Parameter).Text;
                }
                //input = ((Windows.UI.Xaml.Controls.TextBlock)e.Parameter).Text;

                if (text == "xlrText" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 4;
                    navigationdone = true;
                }
                if (text == "pcText" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 4;
                    navigationdone = true;
                }
                if (text == "inputdevicename" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                   // routingtab.Margin = new Thickness(0, 0, 12, 0);
                    // MixAmpRoutingScreen mix = new MixAmpRoutingScreen();
                    //mix.Margin = new Thickness(20, 0, 0, 0);
                    //routingtab.Content = mix;
                    navigationdone = true;
                }
                if (text == "ProfileList" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                    object items = ((Windows.UI.Xaml.Controls.Primitives.Selector)e.Parameter).SelectedItem;
                  //  routingtab.Margin = new Thickness(0, 0, 12, 0);
                    // routingtab.Content = new MixAmpRoutingScreen(items);

                    navigationdone = true;
                }
                if (input == "Selected" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 3;
                    //routingtab.Content = new StreamMix(input);
                    navigationdone = true;
                }
                else if (input != "Selected" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                    // routingtab.Content = new StreamMix(input);
                    navigationdone = true;
                }



            }
            else
            {
                TabHeaderView.SelectedIndex = 1;
            }
            //Debug.WriteLine("Navigated");
        }

        private void TabHeaderView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var basescreen = TabHeaderView.FindName("EqualizerBaseScreen") as EqualizerBaseScreen;
            var equalizerscreen = basescreen.FindName("EqualizerScreen") as EqualizerScreen;
            var carbonitePresetScreen = basescreen.FindName("CarbonitePresetScreen") as CarbonitePresetScreen;
            var image = equalizerscreen.FindName("CarboniteImage") as Image;
            //image.Source = new BitmapImage(new Uri("ms-appx:///BoontaEve/Assets/Boonta Eve, Equalizer.png"));
            internalprofile.Visibility = Visibility.Collapsed;
            CarboniteEqualizerImage.Visibility = Visibility.Collapsed;
            Group.Visibility = Visibility.Collapsed;


            PivotItem pivot = (PivotItem)(sender as Pivot).SelectedItem;
            Pivot pivotMain = (sender as Pivot);
            switch (pivot.Name)
            {
                case "MicrophoneTab":
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 1;
                    EqualizerIcon.Opacity = 0.5;
                    internalprofile.Visibility = Visibility.Visible;

                    var microphone = TabHeaderView.FindName("CarboniteMicrophoneScreen") as CarboniteMicrophoneScreen;
                    var profileToggle = microphone.FindName("toggleswitch") as ToggleSwitch;
                    if (profileToggle.IsOn)
                    {
                        Group.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        Group.Visibility = Visibility.Collapsed;
                    }
                    break;
                case "EqualizerTab":
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 0.5;
                    EqualizerIcon.Opacity = 1;

                    CarboniteEqualizerImage.Visibility = Visibility.Visible;

                    var testSound = equalizerscreen.FindName("testSound") as TestSound;
                    var TestSound_Type = testSound.FindName("TestSound_Type") as TextBlock;
                    var testSoundListView = testSound.FindName("TestSoundList") as ListView;
                    var testSoundInside = carbonitePresetScreen.FindName("testSound") as TestSound;
                    var TestSound_TypeInside = testSoundInside.FindName("TestSound_Type") as TextBlock;
                    var testSoundListViewInside = testSoundInside.FindName("TestSoundList") as ListView;
                    TestSound_Type.Text = AstroA30DatabaseFunctions.GetTestSound();
                    testSoundListView.SelectedIndex = (TestSound_Type.Text == "Immersive" ? 0 : 1);
                    testSoundListViewInside.SelectedIndex = (TestSound_Type.Text == "Immersive" ? 0 : 1);
                    TestSound_TypeInside.Text = TestSound_Type.Text;
                    var presetList = equalizerscreen.FindName("PresetList") as ListView;
                    var selectedItem = AstroA30DatabaseFunctions.GetSelectedPresetItem();
                    foreach (var item in presetList.Items)
                    {
                        var ListViewItem = (ListViewItem)presetList.ContainerFromItem(item) as ListViewItem;
                        if (ListViewItem != null)
                        {
                            var ItemViewGrid = (Grid)ListViewItem.ContentTemplateRoot as Grid;
                            var radioButton = ItemViewGrid.FindName("Radio_Preset") as RadioButton;
                            var sideBar = ItemViewGrid.FindName("SideBorder") as Border;
                            var presetStatus = ItemViewGrid.FindName("Preset_Status") as TextBlock;
                            PresetViewModel presetViewModel = (PresetViewModel)item;
                            if (selectedItem.ToUpper() == ((item as PresetViewModel).Name.Replace(" ", string.Empty).ToUpper()))
                            {
                                presetStatus.Text = "Active";
                                presetStatus.Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 54, 0));
                                presetViewModel.Is_Selected = true;
                                presetViewModel.Status = "Active";
                                radioButton.IsChecked = true;
                                sideBar.Visibility = Visibility.Visible;
                                presetStatus.FontWeight = Windows.UI.Text.FontWeights.SemiBold;
                            }
                            else
                            {
                                presetStatus.Text = "Inactive";
                                presetStatus.Foreground = new SolidColorBrush(Colors.Gray);
                                presetViewModel.Is_Selected = false;
                                presetViewModel.Status = "Inactive";
                                radioButton.IsChecked = false;
                                sideBar.Visibility = Visibility.Collapsed;
                                presetStatus.FontWeight = Windows.UI.Text.FontWeights.Normal;
                            }
                        }
                        else
                        {
                            if (selectedItem.ToUpper() == ((item as PresetViewModel).Name.Replace(" ", string.Empty).ToUpper()))
                            {
                                (item as PresetViewModel).Status = "Active";
                                (item as PresetViewModel).TextColor = new SolidColorBrush(Color.FromArgb(255, 255, 54, 0));
                                (item as PresetViewModel).Is_Selected = true;
                                (item as PresetViewModel).SideBorderVisibility = Visibility.Visible;
                            }
                            else
                            {
                                (item as PresetViewModel).Status = "Inactive";
                                (item as PresetViewModel).TextColor = new SolidColorBrush(Colors.Gray);
                                (item as PresetViewModel).Is_Selected = false;
                                (item as PresetViewModel).SideBorderVisibility = Visibility.Collapsed;
                            }
                        }
                    }
                    break;
                case "MixerTab":
                    MixerIcon.Opacity = 1;
                    MicrophoneIcon.Opacity = 0.5;
                    EqualizerIcon.Opacity = 0.5;
                    break;
                case "":
                    Frame parentFrame = Window.Current.Content as Frame;
                    parentFrame.Navigate(typeof(MainPage));
                    break;        
                default:
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 1;
                    EqualizerIcon.Opacity = 0.5;
                    break;
            }
            image.Visibility = Visibility.Visible;
        }
    }
}
