﻿using MixAmp.Carbonite.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Carbonite.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class CarboniteMicrophoneScreen : Page
    {

        RadioButton RadioOff;
        RadioButton RadioNight;
        RadioButton RadioOnTheGo;
        RadioButton RadioHome;
        TextBlock lblHome;
        TextBlock lbloff;
        TextBlock lblOnthego;
        TextBlock lblNight;
        Slider sideTone;
        string deviceID;

        public CarboniteMicrophoneScreen()
        {
            this.InitializeComponent();
            Load();
        }

        private void Load()
        {
            ScrollViewer Scroll = ucforNoiseGate.FindName("Scroll") as ScrollViewer;
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            var size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            Scroll.Height = (size.Height / 2) - 200;

            RadioOff = ucforNoiseGate.FindName("Off") as RadioButton;
            RadioNight = ucforNoiseGate.FindName("Night") as RadioButton;
            RadioOnTheGo = ucforNoiseGate.FindName("OntheGO") as RadioButton;
            RadioHome = ucforNoiseGate.FindName("Home") as RadioButton;
            lblHome = ucforNoiseGate.FindName("lblHome") as TextBlock;
            lbloff = ucforNoiseGate.FindName("lbloff") as TextBlock;
            lblOnthego = ucforNoiseGate.FindName("lblOnthego") as TextBlock;
            lblNight = ucforNoiseGate.FindName("lblNight") as TextBlock;
            sideTone = ucforNoiseGate.FindName("sideTone") as Slider;
            deviceID = AstroA30DatabaseFunctions.GetDeviceId();

            toggleswitch.IsOn = AstroA30DatabaseFunctions.GetProfileStatus();


            var internalSelected = AstroA30DatabaseFunctions.GetNoiseGateSelected("INTERNAL");
            var boomSelected = AstroA30DatabaseFunctions.GetNoiseGateSelected("BOOM");
            var internalSideTone = AstroA30DatabaseFunctions.GetSideToneValue("INTERNAL");
            var boomSideTone = AstroA30DatabaseFunctions.GetSideToneValue("BOOM");

            if (!toggleswitch.IsOn)
            {
                sideTone.Value = Convert.ToInt32(internalSideTone);

                switch (internalSelected)
                {
                    case "Off":
                        RadioOff.IsChecked = true;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.White);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                    case "Night":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = true;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.White);
                        break;
                    case "OnTheGo":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = true;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.White);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                    case "Home":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = true;
                        lblHome.Foreground = new SolidColorBrush(Colors.White);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                }
            }
            else
            {
                sideTone.Value = Convert.ToInt32(boomSideTone);

                switch (boomSelected)
                {
                    case "Off":
                        RadioOff.IsChecked = true;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.White);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                    case "Night":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = true;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.White);
                        break;
                    case "OnTheGo":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = true;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.White);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                    case "Home":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = true;
                        lblHome.Foreground = new SolidColorBrush(Colors.White);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                }
            }



        }

        private void toggleswitch_Toggled(object sender, RoutedEventArgs e)
        {
            if (!toggleswitch.IsOn)
            {
                internalprofile.Visibility = Visibility.Visible;
                boomprofile.Visibility = Visibility.Collapsed;

                AstroA30DatabaseFunctions.UpdateProfileSelected("Internal", deviceID);

                var internalSelected = AstroA30DatabaseFunctions.GetNoiseGateSelected("INTERNAL");

                sideTone.Value = Convert.ToInt32(AstroA30DatabaseFunctions.GetSideToneValue("INTERNAL"));

                RelativePanel relativePanel = toggleswitch.Parent as RelativePanel;
                var stackPanel = relativePanel.Parent as StackPanel;
                var grid = stackPanel.Parent as Grid;
                var microphone = grid.Parent as CarboniteMicrophoneScreen;
                var pivotItem = microphone.Parent as PivotItem;
                var pivot = pivotItem.Parent as Pivot;
                var GroupImage = pivot.FindName("Group") as Image;
                GroupImage.Visibility = Visibility.Collapsed;

                switch (internalSelected)
                {
                    case "Off":
                        RadioOff.IsChecked = true;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.White);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                    case "Night":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = true;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.White);
                        break;
                    case "OnTheGo":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = true;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.White);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                    case "Home":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = true;
                        lblHome.Foreground = new SolidColorBrush(Colors.White);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                }

            }
            else
            {
                boomprofile.Visibility = Visibility.Visible;
                internalprofile.Visibility = Visibility.Collapsed;

                AstroA30DatabaseFunctions.UpdateProfileSelected("Boom", deviceID);

                var boomSelected = AstroA30DatabaseFunctions.GetNoiseGateSelected("BOOM");
                sideTone.Value = Convert.ToInt32(AstroA30DatabaseFunctions.GetSideToneValue("BOOM"));

                
                RelativePanel relativePanel = toggleswitch.Parent as RelativePanel;
                if (relativePanel != null)
                {
                    var stackPanel = relativePanel.Parent as StackPanel;
                    var grid = stackPanel.Parent as Grid;
                    var microphone = grid.Parent as CarboniteMicrophoneScreen;
                    var pivotItem = microphone.Parent as PivotItem;
                    var pivot = pivotItem.Parent as Pivot;
                    var GroupImage = pivot.FindName("Group") as Image;
                    GroupImage.Visibility = Visibility.Visible;
                }

                switch (boomSelected)
                {
                    case "Off":
                        RadioOff.IsChecked = true;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.White);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                    case "Night":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = true;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.White);
                        break;
                    case "OnTheGo":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = true;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = false;
                        lblHome.Foreground = new SolidColorBrush(Colors.Gray);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.White);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                    case "Home":
                        RadioOff.IsChecked = false;
                        RadioOnTheGo.IsChecked = false;
                        RadioNight.IsChecked = false;
                        RadioHome.IsChecked = true;
                        lblHome.Foreground = new SolidColorBrush(Colors.White);
                        lbloff.Foreground = new SolidColorBrush(Colors.Gray);
                        lblOnthego.Foreground = new SolidColorBrush(Colors.Gray);
                        lblNight.Foreground = new SolidColorBrush(Colors.Gray);
                        break;
                }
            }

        }
    }
}
