﻿using System;
using MixAmp.Carbonite.ViewModels;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using MixAmp.Common.UserControls.Setting;
using MixAmp.Common.ViewModels;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Carbonite.UserControls
{
    public sealed partial class SleepModeSettingsMenu : UserControl
    {
        public SleepModeSettingsMenu()
        {
            this.InitializeComponent();
            SleepModeSettingsList.ItemsSource = new SleepModes();
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            StackPanel SettingsStackPanel = (StackPanel)SettingsRelativePanel.Parent;
            FlyoutPresenter SettingsFlyoutPresenter = (FlyoutPresenter)SettingsStackPanel.Parent;
            Popup SettingsPopup = (Popup)SettingsFlyoutPresenter.Parent;

            if (SettingsPopup.IsOpen)
            {
                SettingsPopup.IsOpen = false;
            }
        }

        private void Radio_Sleep_Click(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = e.OriginalSource as RadioButton;
            if (radioButton != null)
            {
                SleepModeViewModel SleepModeViewModel = radioButton.DataContext as SleepModeViewModel;
                SleepModeSettingsList.SelectedItem = SleepModeViewModel;
            }
        }

        private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        {
            RelativePanel CurrentMenuParent = this.Parent as RelativePanel;
            UIElementCollection UIElements = CurrentMenuParent.Children;

            foreach (var UIElement in UIElements)
            {
                if (UIElement is SleepModeSettingsMenu)
                {
                    if (this.Visibility == Visibility.Visible)
                    {
                        this.Visibility = Visibility.Collapsed;
                    }
                }
                else if (UIElement is DeviceSettingsMenu)
                {
                    DeviceSettingsMenu DeviceSettingsMenu = UIElement as DeviceSettingsMenu;
                    if (DeviceSettingsMenu.Visibility == Visibility.Collapsed)
                    {
                        DeviceSettingsMenu.Visibility = Visibility.Visible;
                    }
                }
            }
        }

        private void SleepModeSettingsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListView ListView = (ListView)sender as ListView; 
            StackPanel stackPanel = ListView.Parent as StackPanel;
            Grid Grid = (Grid)stackPanel.Parent;
            var sleepmode = Grid.Parent as SleepModeSettingsMenu;
            var relativePanel = sleepmode.Parent as RelativePanel;
            
            var deviceSettings = relativePanel.FindName("DeviceSettingsMenu") as DeviceSettingsMenu;
            var deviceList = deviceSettings.FindName("DeviceSettingsList") as ListView;
            foreach (var item in ListView.Items)
            {
                var ListViewItem = (ListViewItem)ListView.ContainerFromItem(item);
                var ItemViewGrid = (Grid)ListViewItem.ContentTemplateRoot;
                var radioButton = ItemViewGrid.FindName("Radio_Sleep") as RadioButton;
                var sleepTimer = ItemViewGrid.FindName("Sleep_Timer_Text") as TextBlock;
                SleepModeViewModel SleepModeViewModel = (SleepModeViewModel)item;

                if (ListViewItem.IsSelected)
                {
                    radioButton.IsChecked = true;
                    SleepModeViewModel.Is_Selected = true;
                    string id = "1";
                    DeviceSpecificDataViewModel.UpdateSleepMode(sleepTimer.Text, id);
                    foreach (var item1 in deviceList.Items)
                    {
                        if ((item1 as AstroA30DeviceSettingsViewModel).Name == "Sleep Mode")
                        {
                            var DeviceListItem = (ListViewItem)deviceList.ContainerFromItem(item1);
                            if (DeviceListItem != null)
                            {
                                var DeviceItemViewGrid = (Grid)DeviceListItem.ContentTemplateRoot;
                                var text = DeviceItemViewGrid.FindName("Actual_Settings_Name") as TextBlock;
                                text.Text = sleepTimer.Text;
                            }
                            (item1 as AstroA30DeviceSettingsViewModel).Actual_Settings_Name = sleepTimer.Text;
                        }
                    }
                }
                else
                {
                    radioButton.IsChecked = false;
                    SleepModeViewModel.Is_Selected = false;
                }
            }
        }
    }
}
