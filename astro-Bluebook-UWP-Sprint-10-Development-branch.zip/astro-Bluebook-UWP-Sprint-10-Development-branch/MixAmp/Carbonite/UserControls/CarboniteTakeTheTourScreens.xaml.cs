﻿using MixAmp.Carbonite.ViewModels;
using MixAmp.Carbonite.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.Carbonite.UserControls
{
    public sealed partial class CarboniteTakeTheTourScreens : UserControl
    {
        public ObservableCollection<TakeTheTourViewModel> CarboniteTourList { get; set; }
        public CarboniteTakeTheTourScreens()
        {
            this.InitializeComponent();
            CarboniteTourList = new ObservableCollection<TakeTheTourViewModel>();
            CarboniteTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Carbonite/Assets/Welcome.png",
                TextHeading = "WELCOME",
                TextContent = "Welcome to the ASTRO Mobile Command Center App. Here you will be able to " +
                "customize and control your A30 + Bluetooth Gaming Headset experience."
            });
            CarboniteTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Carbonite/Assets/Source Selection.png",
                TextHeading = "SOURCE SELECTION",
                TextContent = "Your A30 Headset has the " +
                "ability to connect to three audio sources at one time." +
                " You can connect to other devices using the 3.5mm audio cable, USB-C cable, and Bluetooth."
            });
            CarboniteTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Carbonite/Assets/Mixer.png",
                TextHeading = "MIXER",
                TextContent = "Select two audio sources from within the mixing sources section to balance between them. Adding more volume " +
                "to one source will decrease the volume of the other source."
            });
            CarboniteTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Carbonite/Assets/Microphone.png",
                TextHeading = "MICROPHONE",
                TextContent = "The ASTRO A30 Headset has two sets of microphones. " +
                "The first is the external boom mic, for " +
                "gaming and chat. The second is an internal mic arrray. For on-the-go use. "
            });
            CarboniteTourList.Add(new TakeTheTourViewModel()
            {
                Image = "/Carbonite/Assets/Thumb Stick.png",
                TextHeading = "THUMB STICK",
                TextContent = "When listening to music or other media using Bluetooth, use the center thumb stick to press 1x " +
                "to play or pause,2x to skip track,and 3x to skip back to previous track."
            });
        }
        private void Next_Click(object sender, RoutedEventArgs e)
        {


            if (GalleryIndicator.SelectedIndex < CarboniteTourList.Count - 1)
            {

                GalleryIndicator.SelectedIndex = GalleryIndicator.SelectedIndex + 1;
                btn.Content = "NEXT";
            }
            else
            {
                Frame parentFrame = Window.Current.Content as Frame;
                var lastPage = parentFrame.BackStack.Last().SourcePageType;
                if (lastPage.FullName.Contains("TabHeader"))
                {
                    ((Frame)Window.Current.Content).Navigate(typeof(TabHeader));
                }
                else
                {
                    ((Frame)Window.Current.Content).Navigate(typeof(MainPage), "Carbonite");
                }
            }
            if (GalleryIndicator.SelectedIndex == CarboniteTourList.Count - 1)
            {
                btnSkip.Visibility = Visibility.Collapsed;
                btn.Content = "COMPLETE";
            }



        }

        private void GalleryIndicator_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (GalleryIndicator.SelectedIndex < CarboniteTourList.Count - 1)
            {
                btnSkip.Visibility = Visibility.Visible;
                btn.Content = "NEXT";
            }

            if (GalleryIndicator.SelectedIndex == CarboniteTourList.Count - 1)
            {
                btnSkip.Visibility = Visibility.Collapsed;
                btn.Content = "COMPLETE";
            }
        }

        private void btnSkip_Click(object sender, RoutedEventArgs e)
        {

            // ((Frame)Window.Current.Content).GoBack();
            Frame parentFrame = Window.Current.Content as Frame;
            var lastPage = parentFrame.BackStack.Last().SourcePageType;
            if (lastPage.FullName.Contains("TabHeader"))
            {
                ((Frame)Window.Current.Content).Navigate(typeof(TabHeader));
            }
            else
            {
                ((Frame)Window.Current.Content).Navigate(typeof(MainPage), "Carbonite");
            }
            var tabheaderview = ((System.Reflection.FieldInfo[])((System.Reflection.TypeInfo)lastPage).DeclaredFields)[0];
            var pivotheader = ((System.Reflection.MemberInfo[])((System.Reflection.TypeInfo)lastPage).DeclaredMembers)[11];
            //((Frame)Window.Current.Content).Navigate(typeof(MainPage));
        }

    }
}
