﻿using DataAccessLibrary;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;


namespace MixAmp.Carbonite.ViewModels
{
   public class AstroA30MainSettingsViewModel
    {
        public string Name { get; set; }
        public ImageSource Icon { get; set; }
        public double IconWidth { get; set; }
        public double IconHeight { get; set; }
        public string Status { get; set; }
        public Visibility StatusVisibility { get; set; }
        public Thickness IconMargin { get; set; }
        public Thickness Settings_Name_Margin { get; set; }
        public Thickness Arrow_Right_Margin { get; set; }
        public string _SelectedDevice;

        public AstroA30MainSettingsViewModel(string Name, ImageSource Icon, double IconWidth, double IconHeight, string Status, 
            Visibility StatusVisibility, Thickness IconMargin, Thickness Settings_Name_Margin, Thickness Arrow_Right_Margin)
        {
            this.Name = Name;
            this.Icon = Icon;
            this.IconWidth = IconWidth;
            this.IconHeight = IconHeight;
            this.Status = Status;
            this.StatusVisibility = StatusVisibility;
            this.IconMargin = IconMargin;
            this.Settings_Name_Margin = Settings_Name_Margin;
            this.Arrow_Right_Margin = Arrow_Right_Margin;
        }
    }

    public class AstroA30MainSettings : ObservableCollection<AstroA30MainSettingsViewModel>
    {
        public AstroA30MainSettings()
        {
            Add(new AstroA30MainSettingsViewModel(GetDeviceName(), GetSettingsIcon("AstroA30"), 32, 32, "Update 1.3 Available", Visibility.Visible, new Thickness(0, 15, 0, 0), new Thickness(50, 15, 0, 0), new Thickness(-10, 15, 0, 0)));
            Add(new AstroA30MainSettingsViewModel("Application", GetSettingsIcon("AppSettings"), 32, 32, "Version 1.05", Visibility.Visible, new Thickness(0, 20, 0, 0), new Thickness(50, 20, 0, 0), new Thickness(-10, 15, 0, 0)));
            Add(new AstroA30MainSettingsViewModel("Support", GetSettingsIcon("Support"), 32, 32, "", Visibility.Collapsed, new Thickness(0, 15, 0, 0), new Thickness(50, 20, 0, 0), new Thickness(-10, 15, 0, 0)));
            Add(new AstroA30MainSettingsViewModel("Submit Feedback", GetSettingsIcon("SubmitFeedback"), 32, 32, "", Visibility.Collapsed, new Thickness(0, 20, 0, 0), new Thickness(50, 25, 0, 0), new Thickness(-10, 17, 0, 0)));
            Add(new AstroA30MainSettingsViewModel("Shop Astro", GetSettingsIcon("ShopAstro"), 32, 32, "", Visibility.Collapsed, new Thickness(0, 20, 0, 0), new Thickness(50, 25, 0, 0), new Thickness(-10, 17, 0, 0)));
            Add(new AstroA30MainSettingsViewModel("Log In", GetSettingsIcon("LogIn"), 32, 32, "", Visibility.Collapsed, new Thickness(0, 20, 0, 0), new Thickness(50, 25, 0, 0), new Thickness(-10, 17, 0, 0)));
        }
        private string GetDeviceName()
        {
            string query = "SELECT* from tblCarbonite_DeviceSettings";
            DataSet ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            return Convert.ToString(tb.Rows[0]["deviceName"]);
        }
        private ImageSource GetSettingsIcon(string SettingsName)
        {
            Image image = new Image();

            if (SettingsName.Equals("AstroA30"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Device_Settings.png"));
            }
            else if (SettingsName.Equals("AppSettings"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/App_Settings.png"));
            }
            else if (SettingsName.Equals("Support"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Support.png"));
            }
            else if (SettingsName.Equals("ShopAstro"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Shop_Astro.png"));
            }
            else if (SettingsName.Equals("LogIn"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Login_Settings.png"));
            }
            else if (SettingsName.Equals("SubmitFeedback"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Submit_Feedback.png"));
            }
            return image.Source;
        }
    }


}
