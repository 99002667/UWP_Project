﻿using DataAccessLibrary;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace MixAmp.Carbonite.ViewModels
{
   public class AstroA30DeviceSettingsViewModel
    {
        public string Name { get; set; }
        public ImageSource Icon { get; set; }
        public double IconWidth { get; set; }
        public double IconHeight { get; set; }
        public string Actual_Settings_Name { get; set; }
        public Thickness IconMargin { get; set; }
        public Thickness Settings_Name_Margin { get; set; }
        public Thickness Arrow_Right_Margin { get; set; }
        public Visibility Status_Visibility { get; set; }
        public Visibility Arrow_Right_Visibility { get; set; }
        public Visibility Toggle_Button_Visibility { get; set; }
        public Visibility Dot_Visibility { get; set; }
        public bool Toggle_Button_Is_On { get; set; }
        public AstroA30DeviceSettingsViewModel(string Name, string Actual_Settings_Name, ImageSource Icon, double IconWidth, double IconHeight, Thickness IconMargin, Thickness Settings_Name_Margin, Thickness Arrow_Right_Margin, Visibility Status_Visibility, Visibility Arrow_Right_Visibility, 
            Visibility Toggle_Button_Visibility, Visibility Dot_Visibility, bool Toggle_Button_Is_On)
        {
            this.Name = Name;
            this.Actual_Settings_Name = Actual_Settings_Name;
            this.Icon = Icon;
            this.IconWidth = IconWidth;
            this.IconHeight = IconHeight;
            this.IconMargin = IconMargin;
            this.Settings_Name_Margin = Settings_Name_Margin;
            this.Arrow_Right_Margin = Arrow_Right_Margin;
            this.Status_Visibility = Status_Visibility;
            this.Arrow_Right_Visibility = Arrow_Right_Visibility;
            this.Toggle_Button_Visibility = Toggle_Button_Visibility;
            this.Dot_Visibility = Dot_Visibility; this.Toggle_Button_Is_On = Toggle_Button_Is_On;

        }
    }

    public class AstroA30DeviceSettings : ObservableCollection<AstroA30DeviceSettingsViewModel>
    {
        public AstroA30DeviceSettings()
        {
            Add(new AstroA30DeviceSettingsViewModel("Name", GetDeviceName(), GetSettingsIcon("Name"), 32, 32, new Thickness(0, 15, 0, 0), new Thickness(50, 15, 0, 0), new Thickness(-25, 15, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, false));
            Add(new AstroA30DeviceSettingsViewModel("Firmware Update", "6.3 Update Available", GetSettingsIcon("FirmwareUpdate"), 32, 32, new Thickness(0, 20, 0, 0), new Thickness(50, 20, 0, 0), new Thickness(-25, 15, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Collapsed, Visibility.Visible, false));
            Add(new AstroA30DeviceSettingsViewModel("Sleep Mode", GetValue("SleepMode"), GetSettingsIcon("SleepMode"), 25, 25, new Thickness(5, 25, 0, 0), new Thickness(50, 20, 0, 0), new Thickness(-25, 15, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, false));
            Add(new AstroA30DeviceSettingsViewModel("Tones", GetValue("Tones"), GetSettingsIcon("Tones"), 32, 32, new Thickness(5, 25, 0, 0), new Thickness(50, 20, 0, 0), new Thickness(-25, 17, 0, 0), Visibility.Visible, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, false));
            Add(new AstroA30DeviceSettingsViewModel("Take The Tour", "", GetSettingsIcon("TakeTheTour"), 32, 32, new Thickness(5, 20, 0, 0), new Thickness(50, 25, 0, 0), new Thickness(-25, 17, 0, 0), Visibility.Collapsed, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, false));
            Add(new AstroA30DeviceSettingsViewModel("Reset Device", "", GetSettingsIcon("ResetDevice"), 32, 32, new Thickness(5, 20, 0, 0), new Thickness(50, 25, 0, 0), new Thickness(-25, 17, 0, 0), Visibility.Collapsed, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, false));
        }
        private string GetDeviceName()
        {
            string query = "SELECT* from tblCarbonite_DeviceSettings";
            DataSet ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            return Convert.ToString(tb.Rows[0]["deviceName"]);
        }
        private string GetValue(string input)
        {
            string query = "SELECT* from tblCarbonite_DeviceSettings";
            DataSet dataSet = DataAccess.GetData(query);
            var table = dataSet.Tables[0];
            if (input == "SleepMode")
            {
                return Convert.ToString(table.Rows[0]["sleepMode"]);
            }
            else if (input == "Tones")
            {
                return Convert.ToString(table.Rows[0]["tones"]);
            }
            return "";
        }
        private ImageSource GetSettingsIcon(string SettingsName)
        {
            Image image = new Image();
            if (SettingsName.Equals("Name"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Profile.png"));
            }
            else if (SettingsName.Equals("FirmwareUpdate"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Firmware_Settings.png"));
            }
            else if (SettingsName.Equals("Tones"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Tones.png"));
            }
            else if (SettingsName.Equals("SleepMode"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Sleep_Mode.png"));
            }
            else if (SettingsName.Equals("TakeTheTour"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Tour.png"));
            }
            else if (SettingsName.Equals("ResetDevice"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Reset_Device.png"));
            }
            return image.Source;
        }
    }

    public static class AstroDeviceSpecificDataViewModel
    {
        public static void InitializeDeviceSpecificSettings()
        {
            DataSet ds = new DataSet();
            string queryCarina = "SELECT* from tblCarbonite_DeviceSettings";
            ds = DataAccess.GetData(queryCarina);
            var tbCarina = ds.Tables[0];
            var rowCarina = tbCarina.Rows.Count;
            var columnsCarina = tbCarina.Columns.Count;
            if (rowCarina == 0)
            {
                SqliteCommand insertCommand = new SqliteCommand();
                insertCommand.CommandText = " INSERT INTO tblCarbonite_DeviceSettings VALUES(@deviceId, @deviceName, @firmwareUpdate, @sleepMode, @tones);";
                insertCommand.Parameters.AddWithValue("@deviceId", "1");
                insertCommand.Parameters.AddWithValue("@deviceName", "Alec's A30");
                insertCommand.Parameters.AddWithValue("firmwareUpdate", "6.3 Upadte Available");
                insertCommand.Parameters.AddWithValue("@sleepMode", "15 Minutes");
                insertCommand.Parameters.AddWithValue("@tones", "All");
                DataAccess.InsertData(insertCommand);
            }
        }
        public static void UpdateName(string NewName, string id)
        {
            SqliteCommand UpdateCommand = new SqliteCommand();
            UpdateCommand.CommandText = "update tblCarbonite_DeviceSettings set deviceName = :info where deviceId = :id";
            UpdateCommand.Parameters.AddWithValue("info", NewName);
            UpdateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(UpdateCommand);
        }
    }
}
