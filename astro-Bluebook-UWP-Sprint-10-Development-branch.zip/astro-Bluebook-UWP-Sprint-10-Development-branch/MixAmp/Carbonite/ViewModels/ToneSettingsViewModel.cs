﻿using DataAccessLibrary;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MixAmp.Carbonite.ViewModels
{
   public class ToneSettingsViewModel
    {
        public string ToneType { get; set; }
        public bool Is_Selected { get; set; }

        public ToneSettingsViewModel(string ToneType, bool Is_Selected)
        {
            this.ToneType = ToneType;
            this.Is_Selected = Is_Selected;
        }
    }

    public class Tones : ObservableCollection<ToneSettingsViewModel>
    {
        public Tones()
        {
            Add(new ToneSettingsViewModel("All", GetToneStatus("All")));
            Add(new ToneSettingsViewModel("Minimal", GetToneStatus("Minimal")));
            Add(new ToneSettingsViewModel("None", GetToneStatus("None")));
        }
        private bool GetToneStatus(string status)
        {
            string query = "SELECT* from tblCarbonite_DeviceSettings";
            DataSet dataSet = DataAccess.GetData(query);
            var table = dataSet.Tables[0];
            var time = table.Rows[0]["tones"];
            if (status == (string)time)
            {
                return true;
            }
            return false;
        }
    }
}
