﻿using DataAccessLibrary;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MixAmp.Carbonite.ViewModels
{
   public class SleepModeViewModel
    {
        public string SleepTimer { get; set; }
        public bool Is_Selected { get; set; }

        public SleepModeViewModel(string SleepTimer, bool Is_Selected)
        {
            this.SleepTimer = SleepTimer;
            this.Is_Selected = Is_Selected;
        }
    }

    public class SleepModes : ObservableCollection<SleepModeViewModel>
    {
        public SleepModes()
        {
            Add(new SleepModeViewModel("15 Minutes", GetSleepStatus("15 Minutes")));
            Add(new SleepModeViewModel("30 Minutes", GetSleepStatus("30 Minutes")));
            Add(new SleepModeViewModel("60 Minutes", GetSleepStatus("60 Minutes")));
            Add(new SleepModeViewModel("Disabled", GetSleepStatus("Disabled")));
        }
        private bool GetSleepStatus(string status)
        {
            string query = "SELECT* from tblCarbonite_DeviceSettings";
            DataSet dataSet = DataAccess.GetData(query);
            var table = dataSet.Tables[0];
            var time = table.Rows[0]["sleepMode"];
            if (status == (string)time)
            {
                return true;
            }
            return false;
        }
    }
}
