﻿using DataAccessLibrary;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MixAmp.Carbonite.ViewModels
{
    public static class AstroA30DatabaseFunctions
    {
        public static void CreateCarboniteTable()
        {
            String[] tableCommand = new String[2];

            tableCommand[0] = "CREATE TABLE IF NOT " +
                            "EXISTS tblCarboniteMicrophone (serialNumber NVARCHAR(200) PRIMARY KEY, " +
                            "profilesSelected NVARCHAR(200) NULL, " +
                            "internalNoiseGate NVARCHAR(200) NULL, " +
                            "boomNoiseGate NVARCHAR(200) NULL, " +
                            "boomSideTone NVARCHAR(200) NULL, " +
                            "internalSideTone NVARCHAR(200) NULL)";

            tableCommand[1] = "CREATE TABLE IF NOT " +
                            "EXISTS tblCarboniteEqualizer (serialNumber NVARCHAR(200) PRIMARY KEY, " +
                            "presetSelected NVARCHAR(200) NULL, " +
                            "testSound NVARCHAR(200) NULL, " +
                            "astroGamingSlider NVARCHAR(200) NULL, " +
                            "astroProSlider NVARCHAR(200) NULL, " +
                            "astroMusicSlider NVARCHAR(200) NULL, " +
                            "customSlider NVARCHAR(200) NULL)";

            DataAccess.InitializeDatabase(tableCommand);

            InitialiseCarbonateMicrophone();

            InitialiseCarbonateEqualizer();

        }

        private static void InitialiseCarbonateEqualizer()
        {
            var tb = GetCarboniteEqualizerTableData();

            string deviceid = GetDeviceId();

            if (tb.Rows.Count == 0)
            {
                SqliteCommand insertCommand = new SqliteCommand();
                insertCommand.CommandText = "INSERT INTO tblCarboniteEqualizer VALUES (@serialNumber, @presetSelected, @testSound, @astroGamingSlider, @astroProSlider, @astroMusicSlider, @customSlider)";
                insertCommand.Parameters.AddWithValue("@serialNumber", deviceid);
                insertCommand.Parameters.AddWithValue("@presetSelected", "AstroGaming");
                insertCommand.Parameters.AddWithValue("@testSound", "Immersive");
                insertCommand.Parameters.AddWithValue("@astroGamingSlider", "36,95,30,-68,62");
                insertCommand.Parameters.AddWithValue("@astroProSlider", "-15,-75,68,-42,30");
                insertCommand.Parameters.AddWithValue("@astroMusicSlider", "36,95,-86,45,-31");
                insertCommand.Parameters.AddWithValue("@customSlider", "0,0,0,0,0");
                DataAccess.InsertData(insertCommand);
            }
            else
            {
                int count = 0;
                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    if ((string)tb.Rows[i]["serialNumber"] == deviceid)
                    {
                        count++;
                        break;
                    }
                }

                if (count == 0)
                {
                    SqliteCommand insertCommand = new SqliteCommand();
                    insertCommand.CommandText = "INSERT INTO tblCarboniteEqualizer VALUES (@serialNumber, @presetSelected, @testSound, @astroGamingSlider, @astroProSlider, @astroMusicSlider, @customSlider)";
                    insertCommand.Parameters.AddWithValue("@serialNumber", deviceid);
                    insertCommand.Parameters.AddWithValue("@presetSelected", "AstroGaming");
                    insertCommand.Parameters.AddWithValue("@testSound", "Immersive");
                    insertCommand.Parameters.AddWithValue("@astroGamingSlider", "36,95,30,-68,62");
                    insertCommand.Parameters.AddWithValue("@astroProSlider", "-15,-75,68,-42,30");
                    insertCommand.Parameters.AddWithValue("@astroMusicSlider", "36,95,-86,45,-31");
                    insertCommand.Parameters.AddWithValue("@customSlider", "0,0,0,0,0");
                    DataAccess.InsertData(insertCommand);
                }
            }

        }

        private static void InitialiseCarbonateMicrophone()
        {
            var tb = GetCarboniteMicrophoneTableData();

            string deviceid = GetDeviceId();

            if (tb.Rows.Count == 0)
            {
                SqliteCommand insertCommand = new SqliteCommand();
                insertCommand.CommandText = "INSERT INTO tblCarboniteMicrophone VALUES (@serialNumber, @profilesSelected, @internalNoiseGate, @boomNoiseGate, @boomSideTone, @internalSideTone)";
                insertCommand.Parameters.AddWithValue("@serialNumber", deviceid);
                insertCommand.Parameters.AddWithValue("@profilesSelected", "Internal");
                insertCommand.Parameters.AddWithValue("@internalNoiseGate", "Off");
                insertCommand.Parameters.AddWithValue("@boomNoiseGate", "Off");
                insertCommand.Parameters.AddWithValue("@boomSideTone", "0");
                insertCommand.Parameters.AddWithValue("@internalSideTone", "0");
                DataAccess.InsertData(insertCommand);
            }
            else
            {
                int count = 0;
                for (int i = 0; i < tb.Rows.Count; i++)
                {
                    if ((string)tb.Rows[i]["serialNumber"] == deviceid)
                    {
                        count++;
                        break;
                    }
                }

                if (count == 0)
                {
                    SqliteCommand insertCommand = new SqliteCommand();
                    insertCommand.CommandText = "INSERT INTO tblCarboniteMicrophone VALUES (@serialNumber, @profilesSelected, @internalNoiseGate, @boomNoiseGate, @boomSideTone, @internalSideTone)";
                    insertCommand.Parameters.AddWithValue("@serialNumber", deviceid);
                    insertCommand.Parameters.AddWithValue("@profilesSelected", "Internal");
                    insertCommand.Parameters.AddWithValue("@internalNoiseGate", "Off");
                    insertCommand.Parameters.AddWithValue("@boomNoiseGate", "Off");
                    insertCommand.Parameters.AddWithValue("@boomSideTone", "0");
                    insertCommand.Parameters.AddWithValue("@internalSideTone", "0");
                    DataAccess.InsertData(insertCommand);
                }
            }
        }

        public static string GetDeviceId()
        {
            return "7FDFB0E2-33F3-42BF-900E-A2E62C23B1F1";
        }

        public static bool GetProfileStatus()
        {
            var tb = GetCarboniteMicrophoneTableData();
            string deviceid = GetDeviceId();

            for (int i = 0; i < tb.Rows.Count; i++)
            {
                if ((string)tb.Rows[i]["serialNumber"] == deviceid)
                {
                    return ((string)tb.Rows[i]["profilesSelected"]).ToUpper() != "INTERNAL";
                }
            }
            return false;
        }

        private static DataTable GetCarboniteMicrophoneTableData()
        {
            string query = "SELECT* from tblCarboniteMicrophone";
            DataSet ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            return tb;
        }

        private static DataTable GetCarboniteEqualizerTableData()
        {
            string query = "SELECT* from tblCarboniteEqualizer";
            DataSet ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            return tb;
        }

        public static string GetNoiseGateSelected(string profile)
        {
            var tb = GetCarboniteMicrophoneTableData();
            string deviceid = GetDeviceId();

            for (int i = 0; i < tb.Rows.Count; i++)
            {
                if ((string)tb.Rows[i]["serialNumber"] == deviceid)
                {
                    if (profile == "INTERNAL")
                    {
                        return (string)tb.Rows[i]["internalNoiseGate"];
                    }
                    else
                    {
                        return (string)tb.Rows[i]["boomNoiseGate"];
                    }
                }
            }
            return "";
        }

        public static string GetSideToneValue(string profile)
        {
            var tb = GetCarboniteMicrophoneTableData();
            string deviceid = GetDeviceId();

            for (int i = 0; i < tb.Rows.Count; i++)
            {
                if ((string)tb.Rows[i]["serialNumber"] == deviceid)
                {
                    if (profile == "INTERNAL")
                    {
                        return (string)tb.Rows[i]["internalSideTone"];
                    }
                    else
                    {
                        return (string)tb.Rows[i]["boomSideTone"];
                    }
                }
            }
            return "";
        }

        public static void UpdateProfileSelected(string Value, string id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblCarboniteMicrophone set profilesSelected = :value where serialNumber=:id";
            updateCommand.Parameters.AddWithValue("value", Value);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }

        public static void UpdateNoiseGate(string Value, string id, string profile)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblCarboniteMicrophone set " + profile.ToLower() + "NoiseGate = :value where serialNumber=:id";
            updateCommand.Parameters.AddWithValue("value", Value);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }

        public static void UpdateSideTone(string Value, string id, string profile)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblCarboniteMicrophone set " + profile.ToLower() + "SideTone = :value where serialNumber=:id";
            updateCommand.Parameters.AddWithValue("value", Value);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }

        public static string GetProfileSelected()
        {
            var tb = GetCarboniteMicrophoneTableData();
            string deviceid = GetDeviceId();

            for (int i = 0; i < tb.Rows.Count; i++)
            {
                if ((string)tb.Rows[i]["serialNumber"] == deviceid)
                {
                    return ((string)tb.Rows[i]["profilesSelected"]);
                }
            }
            return "";
        }

        public static string GetTestSound()
        {
            var tb = GetCarboniteEqualizerTableData();
            string deviceid = GetDeviceId();

            for (int i = 0; i < tb.Rows.Count; i++)
            {
                if ((string)tb.Rows[i]["serialNumber"] == deviceid)
                {
                    return ((string)tb.Rows[i]["testSound"]);
                }
            }
            return "";
        }

        public static string GetSelectedPresetItem()
        {
            var tb = GetCarboniteEqualizerTableData();
            string deviceid = GetDeviceId();

            for (int i = 0; i < tb.Rows.Count; i++)
            {
                if ((string)tb.Rows[i]["serialNumber"] == deviceid)
                {
                    return ((string)tb.Rows[i]["presetSelected"]);
                }
            }
            return "";
        }

        public static void UpdateTestSound(string Value)
        {
            string id = GetDeviceId();
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblCarboniteEqualizer set testSound = :value where serialNumber=:id";
            updateCommand.Parameters.AddWithValue("value", Value);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }

        public static void UpdatePresetSelected(string Value)
        {
            string id = GetDeviceId();
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblCarboniteEqualizer set presetSelected = :value where serialNumber=:id";
            updateCommand.Parameters.AddWithValue("value", Value);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }

        public static string GetEqualizerBezierValues(string value)
        {
            var tb = GetCarboniteEqualizerTableData();
            string deviceid = GetDeviceId();

            for (int i = 0; i < tb.Rows.Count; i++)
            {
                if ((string)tb.Rows[i]["serialNumber"] == deviceid)
                {
                    return ((string)tb.Rows[i][value]);
                }
            }
            return "";
        }

        public static void UpdateCustomBezier(string Value)
        {
            string id = GetDeviceId();
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblCarboniteEqualizer set customSlider = :value where serialNumber=:id";
            updateCommand.Parameters.AddWithValue("value", Value);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }

    }
}
