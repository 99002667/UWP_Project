﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace MixAmp.ViewModels
{
    public class MainSettingsViewModel
    {
        public string Name { get; set; }
        public ImageSource Icon { get; set; }
        public double IconWidth { get; set; }
        public double IconHeight { get; set; }
        public string Status { get; set; }
        public Visibility StatusVisibility { get; set; }
        public Thickness IconMargin { get; set; }
        public string _SelectedDevice;


        public MainSettingsViewModel(string Name, ImageSource Icon, double IconWidth, double IconHeight, string Status, Visibility StatusVisibility, Thickness IconMargin)
        {
            this.Name = Name;
            this.Icon = Icon;
            this.IconWidth = IconWidth;
            this.IconHeight = IconHeight;
            this.Status = Status;
            this.StatusVisibility = StatusVisibility;
            this.IconMargin = IconMargin;
        }

    }

    public class MainSettings : ObservableCollection<MainSettingsViewModel>
    {
        public MainSettings()
        {
            Add(new MainSettingsViewModel("Device Settings", GetSettingsIcon("DeviceSettings"), 32, 32, "Update 1.3 Available", Visibility.Visible, new Thickness(0, 10, 0, 0)));
            Add(new MainSettingsViewModel("App Settings", GetSettingsIcon("AppSettings"), 32, 32, "Version 1.05", Visibility.Visible, new Thickness(0, 10, 0, 0)));
            Add(new MainSettingsViewModel("Support", GetSettingsIcon("Support"), 32, 32, "", Visibility.Collapsed, new Thickness(0, 5, 0, 0)));
            Add(new MainSettingsViewModel("Take The Tour", GetSettingsIcon("TakeTheTour"), 32, 32, "", Visibility.Collapsed, new Thickness(0, 5, 0, 0)));
            Add(new MainSettingsViewModel("Shop Astro", GetSettingsIcon("ShopAstro"), 32, 32, "", Visibility.Collapsed, new Thickness(0, 5, 0, 0)));
            Add(new MainSettingsViewModel("Log In", GetSettingsIcon("LogIn"), 32, 32, "", Visibility.Collapsed, new Thickness(0, 5, 0, 0)));
        }

        private ImageSource GetSettingsIcon(string SettingsName)
        {
            Image image = new Image();

            if(SettingsName.Equals("DeviceSettings"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Device_Settings.png"));
            }
            else if(SettingsName.Equals("AppSettings"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/App_Settings.png"));
            }
            else if(SettingsName.Equals("Support"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Support.png"));
            }
            else if(SettingsName.Equals("TakeTheTour"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Tour.png"));
            }
            else if(SettingsName.Equals("ShopAstro"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Shop_Astro.png"));
            }
            else if(SettingsName.Equals("LogIn"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Login_Settings.png"));
            }
            return image.Source;
        }
    }
}
