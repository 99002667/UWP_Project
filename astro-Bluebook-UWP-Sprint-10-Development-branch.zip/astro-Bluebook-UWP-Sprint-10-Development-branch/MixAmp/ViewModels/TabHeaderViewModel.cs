﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI;
using Windows.UI.Xaml.Media;
using MixAmp.Views;

namespace MixAmp.ViewModels
{
    public class TabHeaderViewModel
    {
        public String Icon { get; set; }
        public String Text { get; set; }
        public SolidColorBrush TextColor { get; set; }
        public Type ClassType { get; set; }

        public TabHeaderViewModel(String Icon, String Text, SolidColorBrush TextColor, Type ClassType)
        {
            this.Icon = Icon;
            this.Text = Text;
            this.TextColor = TextColor;
            this.ClassType = ClassType;
        }
    }

    public class Headers : ObservableCollection<TabHeaderViewModel>
    {
        public Headers()
        {
            Add(new TabHeaderViewModel("/Assets/Profiles.png", "PROFILES", new SolidColorBrush(Colors.White), typeof(MixAmpProfilesScreen)));
            Add(new TabHeaderViewModel("/Assets/Sources.png", "ROUTING", new SolidColorBrush(Colors.Gray), typeof(MixAmpRoutingScreen)));
            Add(new TabHeaderViewModel("/Assets/Mixer.png", "MIXER", new SolidColorBrush(Colors.Gray), typeof(MixAmpMixerScreen)));
            Add(new TabHeaderViewModel("/Assets/Microphone.png", "MICROPHONE", new SolidColorBrush(Colors.Gray), typeof(MixAmpMicrophoneScreen)));
            Add(new TabHeaderViewModel("/Assets/Equalizer.png", "EQUALIZER", new SolidColorBrush(Colors.Gray), typeof(MixAmpEqualizerScreen)));
            Add(new TabHeaderViewModel("/Assets/Modules.png", "MODULES", new SolidColorBrush(Colors.Gray), typeof(MixAmpModulesScreen)));
            Add(new TabHeaderViewModel("/Assets/Video.png", "VIDEO", new SolidColorBrush(Colors.Gray), typeof(MixAmpVideoScreen)));
        }
    }
}
