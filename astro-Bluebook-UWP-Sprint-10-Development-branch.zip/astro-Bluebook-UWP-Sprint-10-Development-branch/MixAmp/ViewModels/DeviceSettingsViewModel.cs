﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace MixAmp.ViewModels
{
    public class DeviceSettingsViewModel
    {
        public string Name { get; set; }
        public ImageSource Icon {get; set;}
        public double IconWidth { get; set; }
        public double IconHeight { get; set; }
        public string Actual_Settings_Name { get; set; }
        public Thickness IconMargin { get; set; }
        public Visibility Arrow_Right_Visibility { get; set; }
        public Visibility Toggle_Button_Visibility { get; set; }
        public Visibility Dot_Visibility { get; set; }

        public DeviceSettingsViewModel(string Name, string Actual_Settings_Name, ImageSource Icon, double IconWidth, double IconHeight, Thickness IconMargin, Visibility Arrow_Right_Visibility, Visibility Toggle_Button_Visibility, Visibility Dot_Visibility)
        {
            this.Name = Name;
            this.Actual_Settings_Name = Actual_Settings_Name;
            this.Icon = Icon;
            this.IconWidth = IconWidth;
            this.IconHeight = IconHeight;
            this.IconMargin = IconMargin;
            this.Arrow_Right_Visibility = Arrow_Right_Visibility;
            this.Toggle_Button_Visibility = Toggle_Button_Visibility;
            this.Dot_Visibility = Dot_Visibility;
        }

    }

    public class DeviceSettings : ObservableCollection<DeviceSettingsViewModel>
    {
        public DeviceSettings()
        {
            Add(new DeviceSettingsViewModel("Name", "Alec's Mixamp", GetSettingsIcon("Name"), 32, 32, new Thickness(0, 15, 0, 0), Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed));
            Add(new DeviceSettingsViewModel("Firmware Update", "6.3 Update Available", GetSettingsIcon("FirmwareUpdate"), 32, 32, new Thickness(0, 15, 0, 0), Visibility.Visible, Visibility.Collapsed, Visibility.Visible));
            Add(new DeviceSettingsViewModel("Phantom Power Warning", "Off", GetSettingsIcon("PhantomPower"), 25, 25, new Thickness(5, 15, 0, 0), Visibility.Collapsed, Visibility.Visible, Visibility.Collapsed));
        }

        private ImageSource GetSettingsIcon(string SettingsName)
        {
            Image image = new Image();
            if(SettingsName.Equals("Name"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Profile.png"));
            }
            else if(SettingsName.Equals("FirmwareUpdate"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Firmware_Settings.png"));
            }
            else if (SettingsName.Equals("PhantomPower"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Phantom_Icon.png"));
            }
            return image.Source;
        }
    }

}
