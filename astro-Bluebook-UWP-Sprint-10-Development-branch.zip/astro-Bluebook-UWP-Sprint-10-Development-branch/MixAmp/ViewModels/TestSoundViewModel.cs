﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using System.Collections.ObjectModel;

namespace MixAmp.ViewModels
{
    public class TestSoundViewModel
    {
        public string Name { get; set; }
        public ImageSource EqualizerIcon { get; set; }
        public ImageSource TestSoundIcon { get; set; }

        public TestSoundViewModel(string Name, ImageSource EqualizerIcon, ImageSource TestSoundIcon)
        {
            this.Name = Name;
            this.EqualizerIcon = EqualizerIcon;
            this.TestSoundIcon = TestSoundIcon;
        }
    }

    public class TestSounds : ObservableCollection<TestSoundViewModel>
    {
        public TestSounds()
        {
            Add(new TestSoundViewModel("Immersive", GetIcon("EqualizerIcon"), GetIcon("TestSoundIcon")));
            Add(new TestSoundViewModel("Footsteps", GetIcon("EqualizerIcon"), GetIcon("TestSoundIcon")));

        }

        private ImageSource GetIcon(string IconName)
        {
            Image image = new Image();

            if(IconName == "EqualizerIcon")
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Equalizer.png"));
            }
            else if(IconName == "TestSoundIcon")
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Nine_Dots_Square.png"));
            }
            return image.Source;
        }
    }
}
