﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;
using Windows.UI;

namespace MixAmp.ViewModels
{
    public class ProfileViewModel
    {
        public string Name { get; set; }
        public string Status { get; set; }
        public bool Is_Selected { get; set; }
        public Visibility FortyEightV_Visibility { get; set; }

        public Windows.UI.Xaml.Media.SolidColorBrush TextColor { get; set; }
        public Visibility SideBorderVisibility { get; set; }

        public bool Is_New { get; set; }
        public bool Is_Duplicate { get; set; }


        public ProfileViewModel(string Name, string Status, bool Is_Selected, Visibility FortyEightV_Visibility, Visibility SideBorderVisibility, SolidColorBrush TextColor, bool Is_New, bool Is_Duplicate)
        {
            this.Name = Name;
            this.Status = Status;
            this.Is_Selected = Is_Selected;
            this.FortyEightV_Visibility = FortyEightV_Visibility;
            this.SideBorderVisibility = SideBorderVisibility;
            this.TextColor = TextColor;
            this.Is_New = Is_New;
            this.Is_Duplicate = Is_Duplicate;
        }
    }

    public class Profiles : ObservableCollection<ProfileViewModel>
    {
        public Profiles()
        {
            //Add(new ProfileViewModel("Xbox", "Active Profile", true, true, new SolidColorBrush(Colors.FromArgb(255,255,4,255))));
            Add(new ProfileViewModel("Xbox", "Active Profile", true, Visibility.Visible, Visibility.Visible, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false));
            Add(new ProfileViewModel("PC", "Inactive Profile", false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Colors.Gray), false, false));
            Add(new ProfileViewModel("Stream", "Inactive Profile", false, Visibility.Visible, Visibility.Collapsed, new SolidColorBrush(Colors.Gray), false, false));
            Add(new ProfileViewModel("Tournament", "Inactive Profile", false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Colors.Gray), false, false));
        }
    }
}
