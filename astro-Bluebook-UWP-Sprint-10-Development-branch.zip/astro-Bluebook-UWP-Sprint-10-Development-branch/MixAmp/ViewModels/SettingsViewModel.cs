﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MixAmp.ViewModels
{
    public class SettingsViewModel : ViewModelBase, INotifyPropertyChanged
    {
        public string _selectedDevice;

        public SettingsViewModel()
        {
            SettingsMetaData(_selectedDevice);
        }

        public string SelectedDevice
        {
            get { return _selectedDevice; }
            set
            {
                _selectedDevice = value;
                RaisePropertyChanged("SelectedDevice");
            }
        }


        //public event PropertyChangedEventHandler PropertyChanged;
        //protected void PropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        public void SettingsMetaData(string deviceSelected)
        {
            RaisePropertyChanged("SelectedDevice");           

        }

    }
}
