﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;

namespace MixAmp.ViewModels
{
    public class MixerViewModel
    {
        public string InputDevicename { get; set; }
        public string InputDeviceRouting { get; set; }
        public string Icon { get; set; }
        public Visibility visiblearrow { get; set; }
        public Visibility notvisiblearrow { get; set; }

        public Windows.UI.Xaml.Media.SolidColorBrush selectedColor { get; set; }

        public Visibility DeviceVisible { get; set; }

        //public string SourceAValue { get; set; }
        //public string SourceBValue { get; set; }

        public MixerViewModel(string InputDeviceName, string Icon, Visibility visiblearrow, Visibility notvisiblearrow, SolidColorBrush selectedColor, string InputDeviceRouting = "PC Game: 70% - PC Chat: 30%")
        {
            this.InputDevicename = InputDeviceName;
            this.InputDeviceRouting = InputDeviceRouting;
            this.Icon = Icon;
            this.visiblearrow = visiblearrow;
            this.notvisiblearrow = notvisiblearrow;
            this.selectedColor = selectedColor;
            //this.SourceAValue = SourceAValue;
            //this.SourceBValue = SourceBValue;
        }
    }
    public class MixerMonitor : ObservableCollection<MixerViewModel>
    {
        public MixerMonitor()
        {
            Add(new MixerViewModel("PC Game", "/Assets/USB.png", Visibility.Visible, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(32, 32, 32, 1)), "Source A-70%"));

        }

    }

    public class AddedMixer : ObservableCollection<MixerViewModel>
    {
        public AddedMixer()
        {
            Add(new MixerViewModel("PC Game", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " "));
            Add(new MixerViewModel("USB Audio", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " "));
            Add(new MixerViewModel("AUX", "/Assets/_AUX.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " "));
            Add(new MixerViewModel("Blutooth Device", "/Assets/Bluetooth_ICON.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " "));
            //Add(new RoutingViewModel("Astro A50", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            //Add(new RoutingViewModel("Astro A30", "/Assets/Headset.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
        }
    }


    /////////////////////////
    ///
    public class MixerMonitorNew : ObservableCollection<MixerViewModel>
    {
        public MixerMonitorNew()
        {
            Add(new MixerViewModel("PC Chat", "/Assets/USB.png", Visibility.Visible, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(32, 32, 32, 1)), "Source B-30%"));

        }

    }

    public class AddedMixerNew : ObservableCollection<MixerViewModel>
    {
        public AddedMixerNew()
        {
            Add(new MixerViewModel("PC Chat", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " "));
            Add(new MixerViewModel("USB Audio", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " "));
            Add(new MixerViewModel("AUX", "/Assets/_AUX.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " "));
            Add(new MixerViewModel("Blutooth Device", "/Assets/Bluetooth_ICON.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " "));
            Add(new MixerViewModel("None", "/Assets/CloseFrame.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), " "));

            //Add(new RoutingViewModel("Astro A50", "/Assets/USB.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
            //Add(new RoutingViewModel("Astro A30", "/Assets/Headset.png", Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(24, 32, 32, 1)), "PC Game: 70% - PC Chat: 30%"));
        }
    }

}
   
