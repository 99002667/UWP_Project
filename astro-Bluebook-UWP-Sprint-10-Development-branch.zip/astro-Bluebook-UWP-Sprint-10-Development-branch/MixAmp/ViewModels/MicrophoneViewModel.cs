﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Toolkit.Uwp.UI.Extensions;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;

namespace MixAmp.ViewModels
{
    public class MicrophoneViewModel
    {
        public string InputDevicename { get; set; }

        public string InputDeviceSidetone { get; set; }

        public Visibility Selection { get; set; }

        public Mouse showHand { get; set; }

        public string Icon { get; set; }

        public Visibility FortyEightV_Visibility { get; set; }

        public Windows.UI.Xaml.Media.SolidColorBrush TextColor { get; set; }

        public MicrophoneViewModel(string InputDeviceName,Visibility FortyEightV_Visibility,
            SolidColorBrush TextColor,string Icon,  string InputDeviceSidetone = "Sidetone: 50% - Noise Gate: 50%")
        {
            this.InputDevicename = InputDeviceName;
            this.InputDeviceSidetone = InputDeviceSidetone;
            this.FortyEightV_Visibility = FortyEightV_Visibility;
            this.TextColor = TextColor;
            this.Icon = Icon;
        }
    }

    public class MicrophoneInputSources : ObservableCollection<MicrophoneViewModel>
    {
        public MicrophoneInputSources()
        {
            Add(new MicrophoneViewModel("1/4”", Visibility.Visible, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), "/Assets/_AUX.png",  "Sidetone: 50% - Noise Gate: 50%"));
            Add(new MicrophoneViewModel("XLR", Visibility.Visible, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), "/Assets/_AUX.png",  "Sidetone: 50% - Noise Gate: 50%"));
            Add(new MicrophoneViewModel("PC Chat", Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), "/Assets/USB.png", "Sidetone: 50% - Noise Gate: 50%"));
            Add(new MicrophoneViewModel("Headset", Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), "/Assets/_AUX.png","Sidetone: 50% - Noise Gate: 50%"));
            Add(new MicrophoneViewModel("Astro A40", Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), "/Assets/USB.png",  "Sidetone: 50% - Noise Gate: 50%"));
            Add(new MicrophoneViewModel("Astro A50", Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), "/Assets/Headset.png",  "Sidetone: 50% - Noise Gate: 50%"));
            
        }

    }
}
