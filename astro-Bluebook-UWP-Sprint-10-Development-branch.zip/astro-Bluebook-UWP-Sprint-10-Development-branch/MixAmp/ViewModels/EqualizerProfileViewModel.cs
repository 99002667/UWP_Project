﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace MixAmp.ViewModels
{
    public class EqualizerProfileViewModel
    {
        public string Name { get; set; }
        public ImageSource Icon { get; set; }
        public double IconWidth { get; set; }
        public double IconHeight { get; set; }
        public string Status { get; set; }
        public Visibility FortyEightV_Visibility { get; set; }
        public bool Is_Xbox { get; set; }
        public Visibility Video_Status_Visibility { get; set; }
        public Thickness IconMargin { get; set; }


        public EqualizerProfileViewModel(string Name, ImageSource Icon, double IconWidth, double IconHeight, string Status, Visibility FortyEightV_Visibility, bool Is_XBox, Visibility Video_Status_Visibility, Thickness IconMargin)
        {
            this.Name = Name;
            this.Icon = Icon;
            this.IconWidth = IconWidth;
            this.IconHeight = IconHeight;
            this.Status = Status;
            this.FortyEightV_Visibility = FortyEightV_Visibility;
            this.Is_Xbox = Is_XBox;
            this.Video_Status_Visibility = Video_Status_Visibility;
            this.IconMargin = IconMargin;
        }
    }

    public class EqualizerProfiles : ObservableCollection<EqualizerProfileViewModel>
    {
        public EqualizerProfiles()
        {
            Add(new EqualizerProfileViewModel("Game Mic", GetProfileIcon("Game Mic"), 32, 32, "Astro Pro", Visibility.Collapsed, false, Visibility.Collapsed, new Thickness(0, 15, 0, 0)));
            Add(new EqualizerProfileViewModel("Stream Mix", GetProfileIcon("Stream Mix"), 32, 32, "Astro Pro", Visibility.Collapsed, false, Visibility.Collapsed, new Thickness(0, 15, 0, 0)));
            Add(new EqualizerProfileViewModel("Stream Mic", GetProfileIcon("Stream Mic"), 32, 32, "Astro Pro", Visibility.Collapsed, false, Visibility.Collapsed, new Thickness(0, 15, 0, 0)));
            Add(new EqualizerProfileViewModel("AUX", GetProfileIcon("AUX"), 32, 32, "Astro Music", Visibility.Collapsed, false, Visibility.Collapsed, new Thickness(0, 15, 0, 0)));
            Add(new EqualizerProfileViewModel("Stream", GetProfileIcon("Stream"), 32, 32, "Astro Music", Visibility.Collapsed, false, Visibility.Collapsed, new Thickness(0, 15, 0, 0)));
            Add(new EqualizerProfileViewModel("Headset", GetProfileIcon("Headset"), 32, 32, "Astro Pro", Visibility.Collapsed, false, Visibility.Collapsed, new Thickness(0, 15, 0, 0)));
            Add(new EqualizerProfileViewModel("Astro A40", GetProfileIcon("Astro A40"), 32, 32, "Astro Pro", Visibility.Collapsed, false, Visibility.Collapsed, new Thickness(0, 15, 0, 0)));
            Add(new EqualizerProfileViewModel("Astro A50", GetProfileIcon("Astro A50"), 32, 32, "Astro Pro", Visibility.Collapsed, false, Visibility.Collapsed, new Thickness(0, 15, 0, 0)));
        }

        private ImageSource GetProfileIcon(string profileName)
        {
            Image image = new Image();

            if (profileName == "Xbox")
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Profile.png"));
            }
            else if (profileName.Equals("Game Mic"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/USB.png"));
                image.Width = 24;
                image.Height = 24;
            }
            else if (profileName.Equals("Stream Mix"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/USB.png"));
                image.Width = 24;
                image.Height = 24;
            }
            else if (profileName.Equals("Stream Mic"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/USB.png"));
                image.Width = 24;
                image.Height = 24;
            }
            else if (profileName.Equals("AUX"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                image.Width = 24;
                image.Height = 24;
            }
            else if (profileName.Equals("Stream"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                image.Width = 24;
                image.Height = 24;
            }
            else if (profileName.Equals("Headset"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                image.Width = 24;
                image.Height = 24;
            }
            else if (profileName.Equals("Astro A40"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                image.Width = 24;
                image.Height = 24;
            }
            else if (profileName.Equals("Astro A50"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/_AUX.png"));
                image.Width = 24;
                image.Height = 24;
            }
            return image.Source;
        }
    }
}
