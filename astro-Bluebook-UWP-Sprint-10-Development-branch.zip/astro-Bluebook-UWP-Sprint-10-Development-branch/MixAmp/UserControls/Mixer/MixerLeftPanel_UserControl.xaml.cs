﻿using MixAmp.ViewModels;
using MixAmp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.UserControls.Mixer
{
    public sealed partial class MixerLeftPanel_UserControl : UserControl
    {
       
        public MixerLeftPanel_UserControl()
        {
            this.InitializeComponent();

            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
           var size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            scrlist.Height = size.Height - 480;
          listPanel.Height = size.Height - 200;
           MixerList.ItemsSource = new MixerMonitor();
            AddedList.ItemsSource = new AddedMixer();
            MixerList1.ItemsSource = new MixerMonitorNew();
            AddedList1.ItemsSource = new AddedMixerNew();
            //SourceA.DataContext = App.Mixercls[0].SourceA;
            //SourceB.DataContext = App.Mixercls[0].SourceB; 
            //this.DataContext = this;
            //TestSoundList.ItemsSource = new TestSounds();
        }
        //private void RoutingList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{

        //}

       

        private void Slider_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            string value = String.Format(e.NewValue.ToString());
            sliderValue.Text = value + "%";
            if (e.NewValue > 0)
            {
                rect1.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect1.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 2.5)
            {
                rect2.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect2.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 5)
            {
                rect3.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect3.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 7.5)
            {
                rect4.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect4.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 10)
            {
                rect5.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect5.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 12.5)
            {
                rect6.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect6.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 15)
            {
                rect7.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect7.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 17.5)
            {
                rect8.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect8.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 20)
            {
                rect9.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect9.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 22.5)
            {
                rect10.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect10.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 25)
            {
                rect11.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect11.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 27.5)
            {
                rect12.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect12.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 30)
            {
                rect13.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect13.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 32.5)
            {
                rect14.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect14.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 35)
            {
                rect15.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect15.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 37.5)
            {
                rect16.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect16.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 40)
            {
                rect17.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect17.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 42.5)
            {
                rect18.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect18.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 45)
            {
                rect19.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect19.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 47.5)
            {
                rect20.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect20.Fill = new SolidColorBrush(Colors.Gray);
            }


            if (e.NewValue > 50)
            {
                rect21.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect21.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 52.5)
            {
                rect22.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect22.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 55)
            {
                rect23.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect23.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 57.5)
            {
                rect24.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect24.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 60)
            {
                rect25.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect25.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 62.5)
            {
                rect26.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect26.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 65)
            {
                rect27.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect27.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 67.5)
            {
                rect28.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect28.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 70)
            {
                rect29.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect29.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 72.5)
            {
                rect30.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect30.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 75)
            {
                rect31.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect31.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 77.5)
            {
                rect32.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect32.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 80)
            {
                rect33.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect33.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 82.5)
            {
                rect34.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect34.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue > 85)
            {
                rect35.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect35.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 87.5)
            {
                rect36.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect36.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 90)
            {
                rect37.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect37.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 92.5)
            {
                rect38.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect38.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue >= 95)
            {
                rect39.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect39.Fill = new SolidColorBrush(Colors.Gray);
            }
            if (e.NewValue == 100)
            {
                rect40.Fill = new SolidColorBrush(Colors.White);
            }
            else
            {
                rect40.Fill = new SolidColorBrush(Colors.Gray);
            }

        }

        //private void Button_Click(object sender, RoutedEventArgs e)
        //{

        //    if (AddedList.Visibility != Visibility.Visible)
        //    {

        //        AddedList.Visibility = Visibility.Visible;
        //        upArrow.Visibility = Visibility.Collapsed;
        //        downArrow.Visibility = Visibility.Visible;
        //    }
        //    else
        //    {
        //        AddedList.Visibility = Visibility.Collapsed;
        //        upArrow.Visibility = Visibility.Visible;
        //        downArrow.Visibility = Visibility.Collapsed;
        //    }
        //}

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (AddedList.Visibility != Visibility.Visible)
            {

                AddedList.Visibility = Visibility.Visible;
                var lists = MixerList.ItemsSource as ObservableCollection<MixerViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {

                    item.notvisiblearrow = Visibility.Visible;
                    item.visiblearrow = Visibility.Collapsed;
                }

                MixerList.ItemsSource = null;
                MixerList.ItemsSource = lists;
            }

            else
            {
                AddedList.Visibility = Visibility.Collapsed;
                var lists = MixerList.ItemsSource as ObservableCollection<MixerViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {
                    item.notvisiblearrow = Visibility.Collapsed;
                    item.visiblearrow = Visibility.Visible;
                }
                MixerList.ItemsSource = null;
                MixerList.ItemsSource = lists;


            }
        }
        private void AddedList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var selecteditem = ((Windows.UI.Xaml.Controls.Primitives.Selector)sender).SelectedValue;

            var lists = MixerList.ItemsSource as ObservableCollection<MixerViewModel>;
            // Your UI update code goes here!
            foreach (var items in lists)
            {
                items.Icon = ((MixAmp.ViewModels.MixerViewModel)selecteditem).Icon;
                items.InputDevicename = ((MixAmp.ViewModels.MixerViewModel)selecteditem).InputDevicename;
                items.notvisiblearrow = Visibility.Visible;
                items.visiblearrow = Visibility.Collapsed;
            }
            MixerList.ItemsSource = null;
            MixerList.ItemsSource = lists;


        }
      

        private void MixerList1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void AddedList1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selecteditem = ((Windows.UI.Xaml.Controls.Primitives.Selector)sender).SelectedValue;

            var lists = MixerList1.ItemsSource as ObservableCollection<MixerViewModel>;
            // Your UI update code goes here!
            foreach (var items in lists)
            {
                items.Icon = ((MixAmp.ViewModels.MixerViewModel)selecteditem).Icon;
                items.InputDevicename = ((MixAmp.ViewModels.MixerViewModel)selecteditem).InputDevicename;
                items.notvisiblearrow = Visibility.Visible;
                items.visiblearrow = Visibility.Collapsed;
            }
            MixerList1.ItemsSource = null;
            MixerList1.ItemsSource = lists;

        }




        private void selectArrow2_Click(object sender, RoutedEventArgs e)
        {
            if (AddedList1.Visibility != Visibility.Visible)
            {

                AddedList1.Visibility = Visibility.Visible;
                var lists = MixerList1.ItemsSource as ObservableCollection<MixerViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {

                    item.notvisiblearrow = Visibility.Visible;
                    item.visiblearrow = Visibility.Collapsed;
                }

                MixerList1.ItemsSource = null;
                MixerList1.ItemsSource = lists;
            }

            else
            {
                AddedList1.Visibility = Visibility.Collapsed;
                var lists = MixerList1.ItemsSource as ObservableCollection<MixerViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {
                    item.notvisiblearrow = Visibility.Collapsed;
                    item.visiblearrow = Visibility.Visible;
                }
                MixerList1.ItemsSource = null;
                MixerList1.ItemsSource = lists;


            }
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                Frame parentFrame = Window.Current.Content as Frame;
                parentFrame.Navigate(typeof(TabHeader));
            }
            catch (Exception ex)
            {


            }
        }

        private void AddedList_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }


        //private void Arrow_Down_Click(object sender, RoutedEventArgs e)
        //{
        //    Button Arrow_Down = (Button)sender;
        //    RelativePanel ArrowPanel = (RelativePanel)Arrow_Down.Parent;
        //    Button Arrow_Up = (Button)ArrowPanel.FindName("Arrow_Up");
        //    Arrow_Down.Visibility = Visibility.Collapsed;
        //    Arrow_Up.Visibility = Visibility.Visible;
        //    if (TestSoundList.Visibility == Visibility.Collapsed)
        //    {
        //        TestSoundList.Visibility = Visibility.Visible;
        //    }
        //}

        //private void Arrow_Up_Click(object sender, RoutedEventArgs e)
        //{
        //    Button Arrow_Up = (Button)sender;
        //    RelativePanel ArrowPanel = (RelativePanel)Arrow_Up.Parent;
        //    Button Arrow_Down = (Button)ArrowPanel.FindName("Arrow_Down");
        //    Arrow_Up.Visibility = Visibility.Collapsed;
        //    Arrow_Down.Visibility = Visibility.Visible;
        //    if (TestSoundList.Visibility == Visibility.Visible)
        //    {
        //        TestSoundList.Visibility = Visibility.Collapsed;
        //    }
        //}

        //private void TestSoundList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    ListView TestSoundList = (ListView)sender;
        //    foreach (var item in TestSoundList.Items)
        //    {
        //        ListViewItem ListViewItem = TestSoundList.ContainerFromItem(item) as ListViewItem;
        //        TestSoundViewModel testSoundViewModel = (TestSoundViewModel)item;
        //        if (ListViewItem.IsSelected)
        //        {
        //            TestSound_Type.Text = testSoundViewModel.Name;
        //        }
        //    }
        //}
    }
}
