﻿using MixAmp.Views;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Shapes;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.UserControls
{
    public sealed partial class SourceUserControl : UserControl
    {
        string _Value = "0 %";
        public SourceUserControl()
        {
            this.InitializeComponent();
            Load();
            txtValue.Text = _Value;
        }

        private void Load()
        {

            //txt1.Text = "Abhishek";
            //txt2.Text = "Yadav";
        }

        private void Slider4_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {


            //string value = String.Format(e.NewValue.ToString());
            int value = Convert.ToInt32(e.NewValue.ToString());

            int newValue = 1;
            _Value = value + " %";
            txtValue.Text = _Value;
            if (value > 0 && !string.IsNullOrEmpty(ison.Text))
            {
                routingplaybutton.IsChecked = true;
            }
            else
                routingplaybutton.IsChecked = false;

            if (value > 0)
            {
                speaker.Visibility = Visibility.Visible;
                quiet.Visibility = Visibility.Visible;
                Loud.Visibility = Visibility.Visible;
                Mute.Visibility = Visibility.Collapsed;
            }
            else
            {
                speaker.Visibility = Visibility.Collapsed;
                quiet.Visibility = Visibility.Collapsed;
                Loud.Visibility = Visibility.Collapsed;
                Mute.Visibility = Visibility.Visible;
            }

            newValue = (Convert.ToInt32(value) / 2) + 3;
            for (int i = 0; i < newValue; i++)
            {

                foreach (UIElement element in stkRect.Children)
                {
                    if (element is Rectangle)
                    {
                        string[] str = ((Rectangle)element).Name.Split('t');
                        int strID = Convert.ToInt32(str[1]);
                        if (strID <= i)
                        {
                            ((Rectangle)element).Fill = new SolidColorBrush(Colors.Wheat);
                        }
                        else
                        {
                            ((Rectangle)element).Fill = new SolidColorBrush(Colors.Gray);
                        }
                    }

                }
            }

        }

        private void btntop_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(ison.Text))
            {
                var selectedinput = txt1;
                Frame parentFrame = Window.Current.Content as Frame;
                parentFrame.Navigate(typeof(TabHeader), selectedinput);
            }
            else
            {
                var selectedinput = ison;
                Frame parentFrame = Window.Current.Content as Frame;
                parentFrame.Navigate(typeof(TabHeader), selectedinput);
            }
        }

        private void routingplaybutton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(ison.Text))
            {
                routingplaybutton.IsChecked = false;
            }
            else
                routingplaybutton.IsChecked = true;
        }
    }
}
