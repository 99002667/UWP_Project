﻿using MixAmp.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.UserControls
{
    public sealed partial class MainSettingsMenu : UserControl
    {
        public MainSettingsMenu()
        {
            this.InitializeComponent();
            this.DataContext = this;
            MainSettingsList.ItemsSource = new MainSettings();
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            Button Close_Button = (Button)sender;
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            StackPanel SettingsStackPanel = (StackPanel)SettingsRelativePanel.Parent;
            FlyoutPresenter SettingsFlyoutPresenter = (FlyoutPresenter)SettingsStackPanel.Parent;
            Popup SettingsPopup = (Popup)SettingsFlyoutPresenter.Parent;
            
            if(SettingsPopup.IsOpen)
            {
                SettingsPopup.IsOpen = false;
            }
        }

        private void Arrow_Right_Click(object sender, RoutedEventArgs e)
        {
            Button Arrow_Right = sender as Button;
            MainSettingsViewModel MainSettingsViewModel = Arrow_Right.DataContext as MainSettingsViewModel;
            if(MainSettingsViewModel.Name.Equals("Device Settings"))
            {
                this.ShowDeviceSettingsMenu();

            }
            else if(MainSettingsViewModel.Name.Equals("App Settings"))
            {
                this.ShowAppSettingsMenu();
            }
        }


        private void ShowDeviceSettingsMenu()
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            UIElementCollection UIElements = SettingsRelativePanel.Children;
            foreach(var UIElement in UIElements)
            {
                if(UIElement is DeviceSettingsMenu)
                {
                    DeviceSettingsMenu DeviceSettingsMenu = (DeviceSettingsMenu)UIElement;
                    DeviceSettingsMenu.Visibility = Visibility.Visible;
                }
                else if(UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = (MainSettingsMenu)UIElement;
                    MainSettingsMenu.Visibility = Visibility.Collapsed;
                }
            }
        }

        private void ShowAppSettingsMenu()
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            UIElementCollection UIElements = SettingsRelativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is AppSettingsMenu)
                {
                    AppSettingsMenu AppSettingsMenu = (AppSettingsMenu)UIElement;
                    AppSettingsMenu.Visibility = Visibility.Visible;
                }
                else if (UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = (MainSettingsMenu)UIElement;
                    MainSettingsMenu.Visibility = Visibility.Collapsed;
                }
            }
        }
    }
}
