﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using MixAmp.ViewModels;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.UserControls
{
    public sealed partial class TestSound : UserControl
    {
        public TestSound()
        {
            this.InitializeComponent();
            this.DataContext = this;
            TestSoundList.ItemsSource = new TestSounds();
        }

        private void Arrow_Down_Click(object sender, RoutedEventArgs e)
        {
            Button Arrow_Down = (Button)sender;
            RelativePanel ArrowPanel = (RelativePanel)Arrow_Down.Parent;
            Button Arrow_Up = (Button)ArrowPanel.FindName("Arrow_Up");
            Arrow_Down.Visibility = Visibility.Collapsed;
            Arrow_Up.Visibility = Visibility.Visible;
            if (TestSoundList.Visibility == Visibility.Collapsed)
            {
                TestSoundList.Visibility = Visibility.Visible;
            }
        }

        private void Arrow_Up_Click(object sender, RoutedEventArgs e)
        {
            Button Arrow_Up = (Button)sender;
            RelativePanel ArrowPanel = (RelativePanel)Arrow_Up.Parent;
            Button Arrow_Down = (Button)ArrowPanel.FindName("Arrow_Down");
            Arrow_Up.Visibility = Visibility.Collapsed;
            Arrow_Down.Visibility = Visibility.Visible;
            if (TestSoundList.Visibility == Visibility.Visible)
            {
                TestSoundList.Visibility = Visibility.Collapsed;
            }
        }

        private void TestSoundList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListView TestSoundList = (ListView)sender;
            foreach (var item in TestSoundList.Items)
            {
                ListViewItem ListViewItem = TestSoundList.ContainerFromItem(item) as ListViewItem;
                TestSoundViewModel testSoundViewModel = (TestSoundViewModel)item;
                if (ListViewItem.IsSelected)
                {
                    TestSound_Type.Text = testSoundViewModel.Name;
                }
            }
        }
    }
}
