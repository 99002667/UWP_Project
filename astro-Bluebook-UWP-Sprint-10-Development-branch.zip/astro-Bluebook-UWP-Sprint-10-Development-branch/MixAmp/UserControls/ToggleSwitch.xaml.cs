﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.UserControls
{
    public sealed partial class ToggleSwitch : UserControl
    {
        Thickness LeftSide = new Thickness(-39, 0, 0, 0);
        Thickness RightSide = new Thickness(0, 0, -39, 0);
        SolidColorBrush Off = new SolidColorBrush(Color.FromArgb(1,160, 160, 160));
        SolidColorBrush On = new SolidColorBrush(Color.FromArgb(1,255, 54, 0));
        private bool Toggled = false;

        public ToggleSwitch()
        {
            InitializeComponent();
            //Back.Fill = Off;
            //Back.Stroke = new SolidColorBrush(Color.FromArgb(1, 160, 160, 160)); 
            Toggled = false;
            Dot.Margin = LeftSide;
        }

        public bool Toggled1 { get => Toggled; set => Toggled = value; }

        private void Dot_MouseLeftButtonDown(object sender, PointerRoutedEventArgs e)
        {
            if (!Toggled)
            {
                //Back.Stroke = new SolidColorBrush(Color.FromArgb(0, 255, 54, 0)); 
                //Back.Fill = On;
                Toggled = true;
                Dot.Margin = RightSide;

            }
            else
            {
                //Back.Stroke = new SolidColorBrush(Color.FromArgb(1, 160, 160, 160)); 
                //Back.Fill = Off;
                Toggled = false;
                Dot.Margin = LeftSide;

            }
        }

        private void Back_MouseLeftButtonDown(object sender, PointerRoutedEventArgs e)
        {
            if (!Toggled)
            {
                //Back.Fill = new SolidColorBrush(Color.FromArgb(1, 255, 54, 0)); 
                //Back.Stroke = new SolidColorBrush(Color.FromArgb(0, 255, 54, 0));
                Toggled = true;
                Dot.Margin = RightSide;

            }
            else
            {
                //Back.Stroke = new SolidColorBrush(Color.FromArgb(1, 160, 160, 160)); 
                //Back.Fill = Off;
                Toggled = false;
                Dot.Margin = LeftSide;

            }

        }
      
    }
}
