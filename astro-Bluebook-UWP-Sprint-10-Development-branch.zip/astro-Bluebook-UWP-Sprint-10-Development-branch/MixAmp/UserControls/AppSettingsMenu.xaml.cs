﻿using MixAmp.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.UserControls
{
    public sealed partial class AppSettingsMenu : UserControl
    {
        public AppSettingsMenu()
        {
            this.InitializeComponent();
            AppSettingsList.ItemsSource = new AppSettings();
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            StackPanel SettingsStackPanel = (StackPanel)SettingsRelativePanel.Parent;
            FlyoutPresenter SettingsFlyoutPresenter = (FlyoutPresenter)SettingsStackPanel.Parent;
            Popup SettingsPopup = (Popup)SettingsFlyoutPresenter.Parent;

            if (SettingsPopup.IsOpen)
            {
                SettingsPopup.IsOpen = false;
            }
        }

        private void ToggleSwitch_Toggled(object sender, RoutedEventArgs e)
        {
            Windows.UI.Xaml.Controls.ToggleSwitch ToggleSwitch = sender as Windows.UI.Xaml.Controls.ToggleSwitch;
            RelativePanel ToggleSwitchParent = (RelativePanel)ToggleSwitch.Parent;
            Grid Grid = (Grid)ToggleSwitchParent.Parent;
            TextBlock Status = (TextBlock)Grid.FindName("Status");
            AppSettingsViewModel AppSettingsViewModel = Grid.DataContext as AppSettingsViewModel;
            if (ToggleSwitch.IsOn)
            {
                AppSettingsViewModel.Status = "On";

            }
            else if (!ToggleSwitch.IsOn)
            {
                AppSettingsViewModel.Status = "Off";
            }
            Status.Text = AppSettingsViewModel.Status;
        }

        private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        {
            RelativePanel CurrentMenuParent = this.Parent as RelativePanel;
            UIElementCollection UIElements = CurrentMenuParent.Children;

            foreach (var UIElement in UIElements)
            {
                if (UIElement is AppSettingsMenu)
                {
                    if (this.Visibility == Visibility.Visible)
                    {
                        this.Visibility = Visibility.Collapsed;
                    }
                }
                else if (UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = UIElement as MainSettingsMenu;
                    if (MainSettingsMenu.Visibility == Visibility.Collapsed)
                    {
                        MainSettingsMenu.Visibility = Visibility.Visible;
                    }
                }
            }
        }
    }
}
