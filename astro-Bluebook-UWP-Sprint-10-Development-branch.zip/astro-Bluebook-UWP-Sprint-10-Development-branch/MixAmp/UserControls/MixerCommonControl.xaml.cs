﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Shapes;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.UserControls
{
    public sealed partial class SourceCommonControl : UserControl
    {
        string _Value = "0 %";
        public SourceCommonControl()
        {
            this.InitializeComponent();
            txtValue.Text = _Value;
        }

        private void Slider4_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            string value = String.Format(e.NewValue.ToString());
            _Value = value + " %";
            txtValue.Text = _Value;
            int newValue = (Convert.ToInt32(value)/2)+2;
            for (int i = 0; i < newValue; i++)
            {

                foreach (UIElement element in stkRect.Children)
                {
                    if (element is Rectangle)
                    {
                        string[] str = ((Rectangle)element).Name.Split('t');
                        int strID = Convert.ToInt32(str[1]);
                        if (strID <=i)
                        {
                            ((Rectangle)element).Fill = new SolidColorBrush(Colors.Wheat);
                        }
                        else
                        {
                            ((Rectangle)element).Fill = new SolidColorBrush(Colors.Gray);
                        }
                    }

                }               
            }
            
        }
    }
}
