﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MicrophonePCChatScreen : Page
    {
        public MicrophonePCChatScreen()
        {
            this.InitializeComponent();
            TabHeaderView.SelectedIndex = 4;
        }

        private void Settings(object sender, RoutedEventArgs e)
        {
            selectedDevice.Text = txtDevice.Text;
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            if (settings_flyout.IsOpen)
            {
                settings_flyout.Hide();
            }
        }

        private void Navigate_Home(object sender, RoutedEventArgs e)
        {
            Frame parentFrame = Window.Current.Content as Frame;
            parentFrame.Navigate(typeof(MainPage));
        }
    }
}
