﻿using MixAmp.UserControls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class TabHeader : Page
    {

        SolidColorBrush textcolor = new SolidColorBrush(Color.FromArgb(1, 255, 255, 255));
        public TabHeader()
        {
            this.InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Settings(object sender, RoutedEventArgs e)
        {
            selectedDevice.Text = txtDevice.Text;
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            if (settings_flyout.IsOpen)
            {
                settings_flyout.Hide();
            }
        }
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            bool navigationdone = false;
            string input = string.Empty;
            if (e.Parameter != null)
            {
                var text = ((Windows.UI.Xaml.FrameworkElement)e.Parameter).Name;
               // var controls = (Controls)e.Parameter;
                if (e.Parameter.GetType() == typeof(TextBlock))
                {
                    input = ((Windows.UI.Xaml.Controls.TextBlock)e.Parameter).Text;
                }
                //input = ((Windows.UI.Xaml.Controls.TextBlock)e.Parameter).Text;

                if (text == "xlrText" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 4;
                    navigationdone = true;
                }
                if (text == "pcText" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 4;
                    navigationdone = true;
                }
                if (text == "inputdevicename" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                    routingtab.Margin = new Thickness(0, 0, 12, 0);
                    MixAmpRoutingScreen mix  = new MixAmpRoutingScreen();
                    mix.Margin = new Thickness(20, 0, 0, 0);
                    routingtab.Content = mix;
                    navigationdone = true;
                }
                if (text == "ProfileList" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                    object items = ((Windows.UI.Xaml.Controls.Primitives.Selector)e.Parameter).SelectedItem;
                    routingtab.Margin = new Thickness(0, 0, 12, 0);
                    routingtab.Content = new MixAmpRoutingScreen(items);
                    
                    navigationdone = true;
                }
                if (input == "Selected" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 3;
                    //routingtab.Content = new StreamMix(input);
                    navigationdone = true;
                }
                else if (input != "Selected" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                    routingtab.Content = new StreamMix(input);
                    navigationdone = true;
                }



            }
            else
            {
                TabHeaderView.SelectedIndex = 1;
            }
            //Debug.WriteLine("Navigated");
        }



        private void Navigate_Home(object sender, RoutedEventArgs e)
        {
            Frame parentFrame = Window.Current.Content as Frame;
            parentFrame.Navigate(typeof(MainPage));
        }
    }
}
