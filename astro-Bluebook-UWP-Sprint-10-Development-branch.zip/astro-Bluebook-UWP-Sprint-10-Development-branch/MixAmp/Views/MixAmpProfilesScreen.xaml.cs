﻿using MixAmp.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text.RegularExpressions;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.Popups;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MixAmpProfilesScreen : Page
    {
        static int NewProfileCount = 0;
        static int DuplicateProfileCount = 1;
        static ProfileViewModel OriginalProfileViewModel;
        public MixAmpProfilesScreen()
        {
            this.InitializeComponent();
            ProfileList.ItemsSource = new Profiles();
            this.DataContext = this;
            Size ScreenSize = this.GetScreenResolution();
            double ScreenHeight = this.GetScreenHeight(ScreenSize);
            double ScreenWidth = this.GetScreenWidth(ScreenSize);
            this.SetMaximumListHeight(ScreenHeight);
            //bool templateApplied = this.ApplyTemplate();
        }

        private Size GetScreenResolution()
        {
            var bounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            Size size = new Size(bounds.Width * scaleFactor, bounds.Height * scaleFactor);
            return size;
        }

        private double GetScreenHeight(Size size)
        {
            return size.Height;
        }

        private double GetScreenWidth(Size size)
        {
            return size.Width;
        }

        private void SetMaximumListHeight(double screenHeight)
        {
            if (screenHeight >= 640 && screenHeight < 768)
            {
                double ListHeight = (screenHeight * 0.4);
                ProfileList.MaxHeight = ListHeight;
            }
            else if (screenHeight >= 768 && screenHeight < 1080)
            {
                double ListHeight = (screenHeight * 0.5);
                ProfileList.MaxHeight = ListHeight;
            }
            else if (screenHeight >= 1080)
            {
                double ListHeight = (screenHeight * 0.55);
                ProfileList.MaxHeight = ListHeight;
            }
        }      

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //this.InitializeComponent();
            Frame parentFrame = Window.Current.Content as Frame;
            parentFrame.Navigate(typeof(MainPage));
        }

        private void ProfileList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (flag == false)
            {
                ListView ListView = (ListView)sender as ListView;

                foreach (var item in ListView.Items)
                {
                    var ListViewItem = (ListViewItem)ListView.ContainerFromItem(item) as ListViewItem;
                    var ItemViewGrid = (Grid)ListViewItem.ContentTemplateRoot as Grid;
                    var radioButton = ItemViewGrid.FindName("Radio_Profile") as RadioButton;
                    var sideBar = ItemViewGrid.FindName("SideBorder") as Border;
                    var profilestatus = ItemViewGrid.FindName("Profile_Status") as TextBlock;
                    ProfileViewModel profileViewModel = (ProfileViewModel)item;
                    if (ListViewItem.IsSelected)
                    {
                        profilestatus.Text = "Active Profile";
                        profilestatus.Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 54, 0));
                        profileViewModel.Is_Selected = true;
                        profileViewModel.Status = "Active Profile";
                        radioButton.IsChecked = true;
                        sideBar.Visibility = Visibility.Visible;
                        profilestatus.FontWeight = Windows.UI.Text.FontWeights.SemiBold;
                    }
                    else
                    {
                        profilestatus.Text = "Inactive Profile";
                        profilestatus.Foreground = new SolidColorBrush(Colors.Gray);
                        profileViewModel.Is_Selected = false;
                        profileViewModel.Status = "Inactive Profile";
                        radioButton.IsChecked = false;
                        sideBar.Visibility = Visibility.Collapsed;
                        profilestatus.FontWeight = Windows.UI.Text.FontWeights.Normal;
                    }

                }
            }

        }

        private void Radio_Profile_Click(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = e.OriginalSource as RadioButton;
            if (radioButton != null)
            {
                ProfileViewModel profileViewModel = radioButton.DataContext as ProfileViewModel;
                ProfileList.SelectedItem = profileViewModel;
            }
        }

        private void Add_Profile_Click(object sender, RoutedEventArgs e)
        {
            var ProfileListItems = ProfileList.ItemsSource as Profiles;

            string NewProfileText = "";

            if(NewProfileCount == 0)
            {
                NewProfileText = "New Profile ";
            }
            else if (NewProfileCount > 0)
            {           
                NewProfileText = "New Profile " + (NewProfileCount);
            }
            NewProfileCount++;
            ProfileViewModel NewProfileViewModel = new ProfileViewModel(
                    NewProfileText, "Inactive Profile", false, Visibility.Visible, Visibility.Collapsed,
                    new SolidColorBrush(Colors.Gray),
                    true,
                    false
                );
            ProfileListItems.Add(NewProfileViewModel);
            ProfileList.ItemsSource = ProfileListItems;
            ProfileList.UpdateLayout();
            ProfileList.ScrollIntoView(NewProfileViewModel, ScrollIntoViewAlignment.Leading);
        }

        private void DuplicateProfilePanel_PointerEntered(object sender, PointerRoutedEventArgs e)
        {
            RelativePanel relativePanel = (RelativePanel)sender;
            relativePanel.Background = new SolidColorBrush(Color.FromArgb(255, 32, 32, 32));
            Border sideBorder = (Border)relativePanel.FindName("MenuSideBorder1") as Border;
            sideBorder.Visibility = Visibility.Visible;
        }

        private void DuplicateProfilePanel_PointerExited(object sender, PointerRoutedEventArgs e)
        {
            RelativePanel relativePanel = (RelativePanel)sender;
            relativePanel.Background = new SolidColorBrush(Color.FromArgb(255, 24, 24, 24));
            Border sideBorder = (Border)relativePanel.FindName("MenuSideBorder1") as Border;
            sideBorder.Visibility = Visibility.Collapsed;
        }

        private void DeleteProfilePanel_PointerEntered(object sender, PointerRoutedEventArgs e)
        {
            RelativePanel relativePanel = (RelativePanel)sender;
            relativePanel.Background = new SolidColorBrush(Color.FromArgb(255, 32, 32, 32));
            Border sideBorder = (Border)relativePanel.FindName("MenuSideBorder2") as Border;
            sideBorder.Visibility = Visibility.Visible;
        }

        private void DeleteProfilePanel_PointerExited(object sender, PointerRoutedEventArgs e)
        {
            RelativePanel relativePanel = (RelativePanel)sender;
            relativePanel.Background = new SolidColorBrush(Color.FromArgb(255, 24, 24, 24));
            Border sideBorder = (Border)relativePanel.FindName("MenuSideBorder2") as Border;
            sideBorder.Visibility = Visibility.Collapsed;
        }

        private void Grid_RightTapped(object sender, RightTappedRoutedEventArgs e)
        {
            Grid grid = (Grid)sender;

            MenuFlyoutItem duplicateProfileMenuItem = (MenuFlyoutItem)grid.FindName("DuplicateProfileMenuItem");
            MenuFlyoutItem deleteProfileMenuItem = (MenuFlyoutItem)grid.FindName("DeleteProfileMenuItem");

            ProfileViewModel profileViewModel = grid.DataContext as ProfileViewModel;
            
            if (profileViewModel.Is_New)
            {
                duplicateProfileMenuItem.Visibility = Visibility.Visible;
                if(!profileViewModel.Is_Selected)
                { 
                    deleteProfileMenuItem.Visibility = Visibility.Visible;
                }
                else
                {
                    deleteProfileMenuItem.Visibility = Visibility.Collapsed;
                }
            }
            else if (!profileViewModel.Is_New)
            {
                duplicateProfileMenuItem.Visibility = Visibility.Visible;
                deleteProfileMenuItem.Visibility = Visibility.Collapsed;
            }
            

        }

        private void DuplicateProfileMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MenuFlyoutItem menuFlyoutItem = (MenuFlyoutItem)e.OriginalSource as MenuFlyoutItem;
            ProfileViewModel profileViewModel = menuFlyoutItem.DataContext as ProfileViewModel;

            if (OriginalProfileViewModel != profileViewModel)
            {
                DuplicateProfileCount = 1;
            }

            string DuplicateProfileText = "";
            if (DuplicateProfileCount == 1)
            {
                if (profileViewModel.Is_Duplicate || profileViewModel.Is_New)
                {
                    string duplicateProfileName = profileViewModel.Name; // Xbox 1
                    var splitProfileNameArray = splitDuplicateProfileName(duplicateProfileName);
                    if(!splitProfileNameArray[1].Equals(""))
                    { 
                        DuplicateProfileCount += int.Parse(splitProfileNameArray[1]);
                    }
                    //DuplicateProfileCount++;
                    DuplicateProfileText = splitProfileNameArray[0] + (DuplicateProfileCount);

                }
                else
                {
                    DuplicateProfileText = profileViewModel.Name + " " + (DuplicateProfileCount);
                    OriginalProfileViewModel = profileViewModel;
                }
            }
            else if (DuplicateProfileCount > 1)
            {
                DuplicateProfileText = profileViewModel.Name + " " + (DuplicateProfileCount);
            }
            DuplicateProfileCount++;

            ProfileViewModel DuplicateProfileViewModel = new ProfileViewModel(
                DuplicateProfileText,
                "Inactive Profile",
                false,
                profileViewModel.FortyEightV_Visibility,
                Visibility.Collapsed,
                new SolidColorBrush(Colors.Gray),
                true,
                true
            );

            var ProfileListItems = ProfileList.ItemsSource as Profiles;
            ProfileListItems.Add(DuplicateProfileViewModel);
            ProfileList.ItemsSource = ProfileListItems;
            ProfileList.UpdateLayout();
            ProfileList.ScrollIntoView(DuplicateProfileViewModel, ScrollIntoViewAlignment.Leading);
        }

        private string[] splitDuplicateProfileName(string duplicateProfileName)
        {
            string[] splitProfileNameArray = new string[2];
            var match = Regex.Match(duplicateProfileName, "(\\D+)");
            var splitProfileName = match.Groups[0].Value;
            splitProfileNameArray[0] = splitProfileName;
            match = Regex.Match(duplicateProfileName, "(\\d+)");
            var splitProfileCount = match.Groups[0].Value;
            splitProfileNameArray[1] = splitProfileCount;
            return splitProfileNameArray;
        }

        private void DeleteProfileMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MenuFlyoutItem menuFlyoutItem = (MenuFlyoutItem)e.OriginalSource as MenuFlyoutItem;
            ProfileViewModel profileViewModel = menuFlyoutItem.DataContext as ProfileViewModel;
            //ProfileViewModel DuplicateProfileViewModel = profileViewModel;
            var ProfileListItems = ProfileList.ItemsSource as Profiles;
            int Position = ProfileListItems.IndexOf(profileViewModel);
            ProfileListItems.RemoveAt(Position);
            ProfileList.ItemsSource = ProfileListItems;
        }

        private void Profile_Name_TextBox_FocusDisengaged(Control sender, FocusDisengagedEventArgs args)
        {

        }

        private void Profile_Name_TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            RelativePanel relativePanel = (RelativePanel)textBox.Parent;
            TextBlock textBlock = (TextBlock)relativePanel.FindName("Profile_Name_TextBlock");
            ProfileViewModel profileViewModel = textBox.DataContext as ProfileViewModel;
            if (textBox.Visibility == Visibility.Visible)
            {
                textBlock.Visibility = Visibility.Visible;
                textBox.Visibility = Visibility.Collapsed;
                textBox.Text = profileViewModel.Name;
            }
        }

        private void Grid_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            Grid grid = (Grid)sender;
            TextBlock textBlock = (TextBlock)grid.FindName("Profile_Name_TextBlock");
            TextBox textBox = (TextBox)grid.FindName("Profile_Name_TextBox");

            ProfileViewModel profileViewModel = grid.DataContext as ProfileViewModel;

            if(profileViewModel.Is_New)
            {
                textBlock.Visibility = Visibility.Collapsed;
                textBox.Visibility = Visibility.Visible;
                textBox.Focus(FocusState.Pointer);
                textBox.Select(0, textBox.Text.Length);
            }
        }

        private void Grid_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            Grid grid = (Grid)sender;
            TextBlock textBlock = (TextBlock)grid.FindName("Profile_Name_TextBlock");
            TextBox textBox = (TextBox)grid.FindName("Profile_Name_TextBox");
            ProfileViewModel profileViewModel = grid.DataContext as ProfileViewModel;
            if (e.Key == Windows.System.VirtualKey.Enter)
            {
                profileViewModel.Name = textBox.Text;
                textBlock.Text = profileViewModel.Name;
                textBlock.Visibility = Visibility.Visible;
                textBox.Visibility = Visibility.Collapsed;
            }
            else if (e.Key == Windows.System.VirtualKey.Escape)
            {
                textBlock.Visibility = Visibility.Visible;
                textBox.Visibility = Visibility.Collapsed;
                textBox.Text = profileViewModel.Name;
            }
        }

        private void Arrow_Right_Tapped(object sender, TappedRoutedEventArgs e)
        {
            var itemsdata= ((Windows.UI.Xaml.FrameworkElement)e.OriginalSource).DataContext;
            ProfileList.SelectedItem = itemsdata;
            Frame parentFrame = Window.Current.Content as Frame;
            parentFrame.Navigate(typeof(TabHeader), null,new SuppressNavigationTransitionInfo());
            
        }
        bool flag = false;

        private void Navigation_Routing(object sender, RoutedEventArgs e)
        {
            var itemsdata = ((Windows.UI.Xaml.FrameworkElement)e.OriginalSource).DataContext;
            flag = true;
            ProfileList.SelectedItem = itemsdata;
            flag = false;
            Frame parentFrame = Window.Current.Content as Frame;
            parentFrame.Navigate(typeof(TabHeader), ProfileList, new SuppressNavigationTransitionInfo());
        }
    }
}
