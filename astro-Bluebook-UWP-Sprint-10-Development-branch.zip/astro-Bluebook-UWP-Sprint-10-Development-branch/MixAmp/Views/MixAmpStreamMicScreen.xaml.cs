﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using MixAmp.ViewModels;
using Windows.UI.ViewManagement;
using Windows.Graphics.Display;
using Windows.UI;
using MixAmp.UserControls;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MixAmpStreamMicScreen : Page
    {
        public MixAmpStreamMicScreen()
        {
            this.InitializeComponent();
            this.DataContext = this;
            PresetList.ItemsSource = new Presets();
            Size ScreenSize = this.GetScreenResolution();
            double ScreenHeight = this.GetScreenHeight(ScreenSize);
            double ScreenWidth = this.GetScreenWidth(ScreenSize);
            this.SetMaximumListHeight(ScreenHeight);
        }

        private Size GetScreenResolution()
        {
            var bounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            Size size = new Size(bounds.Width * scaleFactor, bounds.Height * scaleFactor);
            return size;
        }

        private double GetScreenHeight(Size size)
        {
            return size.Height;
        }

        private double GetScreenWidth(Size size)
        {
            return size.Width;
        }

        private void SetMaximumListHeight(double screenHeight)
        {
            if (screenHeight >= 640 && screenHeight < 768)
            {
                double ListHeight = (screenHeight * 0.35);
                PresetList.MaxHeight = ListHeight;
            }
            else if (screenHeight >= 768 && screenHeight < 1080)
            {
                double ListHeight = (screenHeight * 0.4);
                PresetList.MaxHeight = ListHeight;
            }
            else if (screenHeight >= 1080)
            {
                double ListHeight = (screenHeight * 0.45);
                PresetList.MaxHeight = ListHeight;
            }
        }

        private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            this.Visibility = Visibility.Collapsed;
            RelativePanel relativePanel = this.Parent as RelativePanel;
            MixAmpEqualizerScreen mixAmpEqualizerScreen = relativePanel.FindName("MixAmpEqualizerScreen") as MixAmpEqualizerScreen;
            mixAmpEqualizerScreen.Visibility = Visibility.Visible;

        }

        private void Radio_Preset_Click(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = e.OriginalSource as RadioButton;
            if (radioButton != null)
            {
                PresetViewModel presetViewModel = radioButton.DataContext as PresetViewModel;
                PresetList.SelectedItem = presetViewModel;
            }
        }

        private void PresetList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListView ListView = (ListView)sender as ListView;

            foreach (var item in ListView.Items)
            {
                var ListViewItem = (ListViewItem)ListView.ContainerFromItem(item) as ListViewItem;
                var ItemViewGrid = (Grid)ListViewItem.ContentTemplateRoot as Grid;
                var radioButton = ItemViewGrid.FindName("Radio_Preset") as RadioButton;
                var sideBar = ItemViewGrid.FindName("SideBorder") as Border;
                var presetStatus = ItemViewGrid.FindName("Preset_Status") as TextBlock;
                PresetViewModel presetViewModel = (PresetViewModel)item;
                if (ListViewItem.IsSelected)
                {
                    presetStatus.Text = "Active";
                    presetStatus.Foreground = new SolidColorBrush(Color.FromArgb(255, 255, 54, 0));
                    presetViewModel.Is_Selected = true;
                    presetViewModel.Status = "Active";
                    radioButton.IsChecked = true;
                    sideBar.Visibility = Visibility.Visible;
                    presetStatus.FontWeight = Windows.UI.Text.FontWeights.SemiBold;
                }
                else
                {
                    presetStatus.Text = "Inactive";
                    presetStatus.Foreground = new SolidColorBrush(Colors.Gray);
                    presetViewModel.Is_Selected = false;
                    presetViewModel.Status = "Inactive";
                    radioButton.IsChecked = false;
                    sideBar.Visibility = Visibility.Collapsed;
                    presetStatus.FontWeight = Windows.UI.Text.FontWeights.Normal;
                }

            }
        }

        private void Arrow_Right_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            var text = ((MixAmp.ViewModels.PresetViewModel)button.DataContext).Name;
            this.Visibility = Visibility.Collapsed;
            RelativePanel relativePanel = this.Parent as RelativePanel;
            MixAmpPresetsScreen mixAmpPresetsScreen = relativePanel.FindName("MixAmpPresetsScreen") as MixAmpPresetsScreen;
            
            var textname = mixAmpPresetsScreen.FindName("PresetName") as TextBlock;
            var bezierCurve = mixAmpPresetsScreen.FindName("bezierCurve") as BezierCurve;
            if (text == "Astro Gaming")
            {
                //BezierCurve bezierCurve = new BezierCurve();
                var Slider1 = bezierCurve.FindName("MySlider") as Slider;
                Slider1.Value = 36;
                Slider1.IsHitTestVisible = false;
                var Slider2 = bezierCurve.FindName("MySlider2") as Slider;
                Slider2.Value = 95;
                Slider2.IsHitTestVisible = false;
                var Slider3 = bezierCurve.FindName("MySlider3") as Slider;
                Slider3.Value = 30;
                Slider3.IsHitTestVisible = false;
                var Slider4 = bezierCurve.FindName("MySlider4") as Slider;
                Slider4.Value = -68;
                Slider4.IsHitTestVisible = false;
                var Slider5 = bezierCurve.FindName("MySlider5") as Slider;
                Slider5.Value = 62;
                Slider5.IsHitTestVisible = false;
            }
            else if(text == "Astro Music")
            {
                var Slider1 = bezierCurve.FindName("MySlider") as Slider;
                Slider1.Value = 36;
                Slider1.IsHitTestVisible = false;
                var Slider2 = bezierCurve.FindName("MySlider2") as Slider;
                Slider2.Value = 95;
                Slider2.IsHitTestVisible = false;
                var Slider3 = bezierCurve.FindName("MySlider3") as Slider;
                Slider3.Value = -86;
                Slider3.IsHitTestVisible = false;
                var Slider4 = bezierCurve.FindName("MySlider4") as Slider;
                Slider4.Value = 45;
                Slider4.IsHitTestVisible = false;
                var Slider5 = bezierCurve.FindName("MySlider5") as Slider;
                Slider5.Value = -31;
                Slider5.IsHitTestVisible = false;
            }
            else if(text == "Astro Pro")
            {
                var Slider1 = bezierCurve.FindName("MySlider") as Slider;
                Slider1.Value = -15;
                Slider1.IsHitTestVisible = false;
                var Slider2 = bezierCurve.FindName("MySlider2") as Slider;
                Slider2.Value = -75;
                Slider2.IsHitTestVisible = false;
                var Slider3 = bezierCurve.FindName("MySlider3") as Slider;
                Slider3.Value = 68;
                Slider3.IsHitTestVisible = false;
                var Slider4 = bezierCurve.FindName("MySlider4") as Slider;
                Slider4.Value = -42;
                Slider4.IsHitTestVisible = false;
                var Slider5 = bezierCurve.FindName("MySlider5") as Slider;
                Slider5.Value = 30;
                Slider5.IsHitTestVisible = false;
            }
            else
            {
                var Slider1 = bezierCurve.FindName("MySlider") as Slider;
                Slider1.Value = 0;
                Slider1.IsHitTestVisible = true;
                var Slider2 = bezierCurve.FindName("MySlider2") as Slider;
                Slider2.Value = 0;
                Slider2.IsHitTestVisible = true;
                var Slider3 = bezierCurve.FindName("MySlider3") as Slider;
                Slider3.Value = 0;
                Slider3.IsHitTestVisible = true;
                var Slider4 = bezierCurve.FindName("MySlider4") as Slider;
                Slider4.Value = 0;
                Slider4.IsHitTestVisible = true;
                var Slider5 = bezierCurve.FindName("MySlider5") as Slider;
                Slider5.Value = 0;
                Slider5.IsHitTestVisible = true;
            }
           
            textname.Text = text;
            mixAmpPresetsScreen.Visibility = Visibility.Visible;

        }
    }
}
