﻿using MixAmp.UserControls;
using MixAmp.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Runtime;
using System.Collections;
using System.Collections.ObjectModel;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.ViewManagement;
using Windows.Graphics.Display;
using Windows.UI;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MixAmpRoutingScreen : Page
    {
        Size size;
        public MixAmpRoutingScreen()
        {
            this.InitializeComponent();

            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            AddedList.Height = size.Height - 540;
           // ScrUsercontrol.Height = size.Height - 200;
            //ScrUsercontrol.Width = size.Width - 300;
            profileSelected.Text = "Xbox";
            profilestatus.Text = "Active Profile";
            volt.Visibility = Visibility.Visible;
            profilestatus.Foreground = new SolidColorBrush(Colors.OrangeRed);
            //usercontrolstack.Width = size.Width - 150;
            //usercontrolstack.Height = size.Height - 100;
            RoutingList.ItemsSource = new RoutingMonitor();
            AddedList.ItemsSource = new AddedRouting();
            Load();
            this.DataContext = this;
        }

        public MixAmpRoutingScreen(object profileViewModel)
        {
            this.InitializeComponent();
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            AddedList.Height = size.Height - 540;
           // ScrUsercontrol.Height = size.Height - 200;
            ScrUsercontrol.Width = size.Width - 300;
            profileSelected.Text = ((MixAmp.ViewModels.ProfileViewModel)profileViewModel).Name;
            profilestatus.Text = ((MixAmp.ViewModels.ProfileViewModel)profileViewModel).Status;
            if (profilestatus.Text == "Active Profile")
                profilestatus.Foreground = new SolidColorBrush(Colors.OrangeRed);
            else
                profilestatus.Foreground = new SolidColorBrush(Colors.Gray);

            volt.Visibility = ((MixAmp.ViewModels.ProfileViewModel)profileViewModel).FortyEightV_Visibility;
            var monitor = leftpanel.FindName("monitor") as TextBlock;
            //monitor.Margin = new Thickness(-440, 0, 0, 0);
            topsection.Margin = new Thickness(20, 0, 0, 0);
            //leftpanel.Margin = new Thickness(0, 30, 0, 0);
            ScrUsercontrol.Margin = new Thickness(0, 0, 0, 0);
            RoutingList.ItemsSource = new RoutingMonitor();
            AddedList.ItemsSource = new AddedRouting();
            Load();
            this.DataContext = this;
        }

        private void Load()
        {
            StackPanel usercontrol = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 80, 10, 10),
                HorizontalAlignment = HorizontalAlignment.Left,
                Width = size.Width - 150,
                //Height = size.Height - 100
            };
            ScrUsercontrol.Content = usercontrol;
            SourceUserControl uc;
            string selectedinput = string.Empty;
            var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
            foreach (var item in lists)
            {
                selectedinput = item.InputDevicename;
            }
            Dictionary<string, string> inputdevice = new Dictionary<string, string>();
            inputdevice.Add("Headset", "Host USB-A");
            inputdevice.Add("Stream Mix", "Stream USB-C");
            inputdevice.Add("Stream Mic", "Stream USB-C");
            inputdevice.Add("Game Mic", "Game USB-C");
            inputdevice.Add("AUX", "AUX 1/8");
            inputdevice.Add("Stream", "Stream 1/8”");
            inputdevice.Add("HeadSet", "Headset 1/8”");
            inputdevice.Add("Astro A50", "RF");
            inputdevice.Add("Astro A30", "Bluetooth");
            foreach (var device in inputdevice)
            {
                uc = new SourceUserControl();
                if (selectedinput == device.Key)
                {
                    this.InitializeComponent();
                }
                var text = uc.FindName("txt1") as TextBlock;
                var text1 = uc.FindName("txt2") as TextBlock;
                var playbutton = uc.FindName("ison") as TextBlock;
                var selectedbutton = uc.FindName("btntop") as Button;
                var selectedImage = uc.FindName("selectedcontrol") as Image;
                text.Text = device.Key;
                text1.Text = device.Value;
                if (selectedinput == device.Key)
                {
                    selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Mixer.png"));
                    playbutton.Text = "Selected";
                }
                else
                    selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Vector.png"));

                usercontrol.Children.Add(uc);

            }

        }

        private void RoutingList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (AddedList.Visibility != Visibility.Visible)
            {

                AddedList.Visibility = Visibility.Visible;
                var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {

                    item.notvisiblearrow = Visibility.Visible;
                    item.visiblearrow = Visibility.Collapsed;
                }
                // RoutingList.Height = size.Height - 480;
                RoutingList.ItemsSource = null;
                RoutingList.ItemsSource = lists;
            }

            else
            {
                AddedList.Visibility = Visibility.Collapsed;
                var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
                // Your UI update code goes here!
                foreach (var item in lists)
                {
                    item.notvisiblearrow = Visibility.Collapsed;
                    item.visiblearrow = Visibility.Visible;
                }
                // RoutingList.Height = 200;
                RoutingList.ItemsSource = null;
                RoutingList.ItemsSource = lists;
            }
        }

        private void AddedList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var selecteditem = ((Windows.UI.Xaml.Controls.Primitives.Selector)sender).SelectedValue;

            var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
            // Your UI update code goes here!
            foreach (var items in lists)
            {
                items.Icon = ((MixAmp.ViewModels.RoutingViewModel)selecteditem).Icon;
                items.InputDevicename = ((MixAmp.ViewModels.RoutingViewModel)selecteditem).InputDevicename;
                items.notvisiblearrow = Visibility.Visible;
                items.visiblearrow = Visibility.Collapsed;
            }
            RoutingList.ItemsSource = null;
            RoutingList.ItemsSource = lists;
            Load();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {

                Frame parentFrame = Window.Current.Content as Frame;
                parentFrame.Navigate(typeof(TabHeader));
            }
            catch (Exception ex)
            {


            }
        }
    }
}
