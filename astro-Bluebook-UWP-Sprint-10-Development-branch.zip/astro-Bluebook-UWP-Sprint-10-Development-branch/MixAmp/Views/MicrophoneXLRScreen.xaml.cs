﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MicrophoneXLRScreen : Page
    {
        public MicrophoneXLRScreen()
        {
            this.InitializeComponent();
            TabHeaderView.SelectedIndex = 4;
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            if (settings_flyout.IsOpen)
            {
                settings_flyout.Hide();
            }
        }

        private void ToggleSwitch1_Toggled(object sender, RoutedEventArgs e)
        {

        }

        private void XLScreen(object sender, RoutedEventArgs e)
        {

        }

        private void MyDevices(object sender, RoutedEventArgs e)
        {

        }

        private void xHome_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rd = (RadioButton)sender;
            string name = rd.Tag.ToString();
            //xHome.BorderBrush = new SolidColorBrush(Colors.Yellow);
        }

        private void Settings(object sender, RoutedEventArgs e)
        {
            selectedDevice.Text = txtDevice.Text;
        }

        private void Navigate_Home(object sender, RoutedEventArgs e)
        {
            Frame parentFrame = Window.Current.Content as Frame;
            parentFrame.Navigate(typeof(MainPage));
        }

        private void TabHeaderView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
