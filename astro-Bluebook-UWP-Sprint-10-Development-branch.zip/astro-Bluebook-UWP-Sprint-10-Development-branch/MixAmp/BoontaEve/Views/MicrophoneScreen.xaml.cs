﻿using MixAmp.Common.UserControls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.System;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;


// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.BoontaEve.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MicrophoneScreen : Page
    {
        public MicrophoneScreen()
        {
            this.InitializeComponent();
            txtpopup.IsEnabled = true;
            txtpopup.Focus(FocusState.Programmatic);
            var Stack = StackPanel_Microphone.FindName("Microphoneleft") as MicrophoneCommonLeftPanel_UserControl;
            ScrollViewer Scroll = Stack.FindName("Scroll") as ScrollViewer;
           
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            var size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            Scroll.Height = (size.Height / 2) - 200;


        }

        private void Arrow_Click(object sender, RoutedEventArgs e)
        {
            // btnflyout.Visibility = Visibility.Visible;
           
            txtpopup.Focus(FocusState.Programmatic);
            //txtpopup.Visibility = Visibility.Collapsed;
        }

        //private void Grid_OnKeyDown(object sender, KeyRoutedEventArgs e)
        //{
        //    var str = e.Key.ToString();
        //    if (char.IsDigit(str[0]))
        //    {
        //        //is digit
        //    }
        //    // is letter
        //}

        //private void Arrow_AccessKeyInvoked(UIElement sender, AccessKeyInvokedEventArgs args)
        //{

        //}

        //private void Page_CharacterReceived(UIElement sender, CharacterReceivedRoutedEventArgs args)
        //{
        //    txtshortcutValue.Text = "A";
        //}

        //private void Page_ProcessKeyboardAccelerators(UIElement sender, ProcessKeyboardAcceleratorEventArgs args)
        //{
        //    txtshortcutValue.Text = "B";
        //}

        //private void Arrow_AccessKeyDisplayDismissed(UIElement sender, AccessKeyDisplayDismissedEventArgs args)
        //{
        //    txtshortcutValue.Text = "C";
        //}

        //private void Arrow_AccessKeyDisplayRequested(UIElement sender, AccessKeyDisplayRequestedEventArgs args)
        //{
        //    txtshortcutValue.Text = "D";
        //}

        //private void Arrow_AccessKeyInvoked(UIElement sender, AccessKeyInvokedEventArgs args)
        //{
        //    txtshortcutValue.Text = "E";
        //}

        //private void Arrow_DataContextChanged(FrameworkElement sender, DataContextChangedEventArgs args)
        //{
        //    txtshortcutValue.Text = "F";
        //}

        //private void Arrow_Tapped(object sender, TappedRoutedEventArgs e)
        //{
        //    txtshortcutValue.Text = "G";
        //}

        private void Arrow_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            try
            {
                if (e.Key == VirtualKey.Control)
                {

                }
            }
            catch (Exception ex)
            {


            }
        }

        private void Arrow_KeyUp(object sender, KeyRoutedEventArgs e)
        {
            //if (!string.IsNullOrEmpty(e.Key.ToString()))
            //{
            //    char[] az = Enumerable.Range('a', 'z' - 'a' + 1).Select(i => (Char)i).ToArray();
            //    foreach (var item in az)
            //    {
            //        if (item.ToString().ToUpper() == e.Key.ToString().ToUpper())
            //        {
            //            txtshortcutValue.Text = e.Key.ToString().ToUpper();
            //        }
            //    }
            //}
        }

        private void txtpopup_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (txtpopup.Text.Trim() != "")
                {
                    char[] str = Enumerable.Range('a', 'z' - 'a' + 1).Select(i => (Char)i).ToArray();
                    foreach (var item in str)
                    {
                        if (item.ToString().ToUpper() == txtpopup.Text.ToUpper())
                        {
                            txtshortcutValue.Text = txtpopup.Text.ToUpper();
                        }
                    }
                    txtpopup.Text = "";
                    settings_flyout.Hide();
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
