﻿using MixAmp.Common.Views;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using Microsoft.AppCenter;
using Microsoft.AppCenter.Analytics;
using Microsoft.AppCenter.Crashes;
using MixAmp.Common.UserControls.Setting;
using MixAmp.BoontaEve.ViewModels;
using MixAmp.Common.ViewModels;
using MixAmp.BoontaEve.UserControls;
using System.Data;
using DataAccessLibrary;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.BoontaEve.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class TabHeader : Page
    {
        public TabHeader()
        {
            try
            {
                this.InitializeComponent();
                Load();
                AppCenter.Start("df4cf793-71ba-4be4-a7b8-10df5904dbd0",
                       typeof(Analytics), typeof(Crashes));
                TabHeaderView.TabIndex = 0;
                // TabHeaderView.
                RoutingIcon.Opacity = 1;
                TabHeaderView.SelectedIndex = 1;
                MixerIcon.Opacity = 0.5;
                MicrophoneIcon.Opacity = 0.5;
                EQIcon.Opacity = 0.5;
                ModuleIcon.Opacity = 0.5;
            }
            catch (Exception ex)
            {
                ErrorAttachmentLog.AttachmentWithText(ex.Message, ex.StackTrace.ToString());
                throw;
            }

        }
        //private void Load()
        //{
        //    var footercontrol = TabHeaderView.FindName("FooterControl") as UserControl;
        //    var text = footercontrol.FindName("txtDevice") as TextBlock;
        //    string query1 = "SELECT* from tblBoontaEve_DeviceSettings";
        //    DataSet ds1 = DataAccess.GetData(query1);
        //    var tb1 = ds1.Tables[0];
        //    text.Text = Convert.ToString(tb1.Rows[0]["deviceName"]);
        //    //text.Text = "Alec's MixAmp Pro TR";
        //}
        private void Load()
        {
            var footercontrol = TabHeaderView.FindName("FooterControl") as UserControl;
            var text = footercontrol.FindName("txtDevice") as TextBlock;
            text.Text = DeviceSpecificDataViewModel.GetBoontaEveDeviceName();
            //text.Text = "Alec's MixAmp Pro TR";	
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Settings(object sender, RoutedEventArgs e)
        {
            // selectedDevice.Text = txtDevice.Text;
            Button SettingsButton = (Button)sender;
            Flyout SettingsFlyout = (Flyout)SettingsButton.Flyout;
            StackPanel SettingsStackPanel = (StackPanel)SettingsFlyout.Content;
            UIElementCollection UIElements = SettingsStackPanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is RelativePanel)
                {
                    RelativePanel RelativePanel = (RelativePanel)UIElement;
                    this.SetDeviceName(RelativePanel);
                }
            }
        }

        private void SetDeviceName(RelativePanel RelativePanel)
        {
            UIElementCollection UIElements = RelativePanel.Children;
            var basescreen = TabHeaderView.FindName("FooterControl") as UserControl;
            var txtDevice = basescreen.FindName("txtDevice") as TextBlock;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = (MainSettingsMenu)UIElement;
                    ListView MainSettingsList = (ListView)MainSettingsMenu.FindName("MainSettingsList");
                    TextBlock DeviceNameTextBlock = (TextBlock)MainSettingsMenu.FindName("SelectedDevice");
                    //string DeviceName = "Mixamp Pro TR";
                    string DeviceName = DeviceSpecificDataViewModel.GetBoontaEveDeviceName();
                    DeviceNameTextBlock.Text = DeviceName;
                    MainSettingsList.ItemsSource = new BoontaEveMainSettings();
                    DeviceNameTextBlock.Text = DeviceName;
                }
                else if (UIElement is DeviceSettingsMenu)
                {
                    DeviceSettingsMenu DeviceSettingsMenu = (DeviceSettingsMenu)UIElement;
                    ListView DeviceSettingsList = (ListView)DeviceSettingsMenu.FindName("DeviceSettingsList");
                    TextBlock DeviceNameText = (TextBlock)DeviceSettingsMenu.FindName("DeviceNameText");
                    string DeviceName = DeviceSpecificDataViewModel.GetBoontaEveDeviceName();
                    DeviceNameText.Text = DeviceName;
                    DeviceSettingsList.ItemsSource = new BoontaEveDeviceSettings();
                    //string DeviceName = "Mixamp Pro TR";
                    //DeviceNameText.Text = DeviceName;
                }
                else if (UIElement is AppSettingsMenu)
                {
                    AppSettingsMenu AppSettingsMenu = (AppSettingsMenu)UIElement;
                    ListView AppSettingsList = (ListView)AppSettingsMenu.FindName("AppSettingsList");
                    TextBlock DeviceNameTextBlock = (TextBlock)AppSettingsMenu.FindName("AppSettingsText");

                    string DeviceName = "Application";
                    AppSettingsList.ItemsSource = new AppSettings();
                    DeviceNameTextBlock.Text = DeviceName;
                }
                else if (UIElement is BoontaEveDeviceSettingsMenu)
                {
                    BoontaEveDeviceSettingsMenu BoontaEveDeviceSettingsMenu = (BoontaEveDeviceSettingsMenu)UIElement;
                    //string DeviceName = "Mixamp Pro TR";
                    string DeviceName = DeviceSpecificDataViewModel.GetBoontaEveDeviceName();
                    TextBlock DeviceNameText = (TextBlock)BoontaEveDeviceSettingsMenu.FindName("DeviceNameText");
                    DeviceNameText.Text = DeviceName;
                }
            }
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            //if (settings_flyout.IsOpen)
            //{
            //    settings_flyout.Hide();
            //}
        }
        private void settings_flyout_Closed(object sender, object e)
        {
            var footercontrol = TabHeaderView.FindName("FooterControl") as UserControl;
            var footerText = footercontrol.FindName("txtDevice") as TextBlock;
            string BoontaEveName = DeviceSpecificDataViewModel.GetBoontaEveDeviceName();
            footerText.Text = BoontaEveName;

            Flyout flyout = (sender) as Flyout;
            var SettingsStackPanel = flyout.Content as StackPanel;
            UIElementCollection UIElements = SettingsStackPanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is RelativePanel)
                {
                    RelativePanel RelativePanel = (RelativePanel)UIElement;
                    this.RefreshSettingsUI(RelativePanel);
                }
            }
        }
        private void RefreshSettingsUI(RelativePanel relativePanel)
        {
            UIElementCollection UIElements = relativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is MainSettingsMenu)
                {
                    UIElement.Visibility = Visibility.Visible;
                }
                else
                {
                    UIElement.Visibility = Visibility.Collapsed;
                }
            }
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            bool navigationdone = false;
            string input = string.Empty;
            if (e.Parameter != null)
            {
                var text = ((Windows.UI.Xaml.FrameworkElement)e.Parameter).Name;
                // var controls = (Controls)e.Parameter;
                if (e.Parameter.GetType() == typeof(TextBlock))
                {
                    input = ((Windows.UI.Xaml.Controls.TextBlock)e.Parameter).Text;
                }
                //input = ((Windows.UI.Xaml.Controls.TextBlock)e.Parameter).Text;

                if (text == "xlrText" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 4;
                    navigationdone = true;
                }
                if (text == "pcText" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 4;
                    navigationdone = true;
                }
                if (text == "inputdevicename" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                    routingtab.Margin = new Thickness(0, 0, 12, 0);
                    // MixAmpRoutingScreen mix = new MixAmpRoutingScreen();
                    //mix.Margin = new Thickness(20, 0, 0, 0);
                    //routingtab.Content = mix;
                    navigationdone = true;
                }
                if (text == "ProfileList" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                    object items = ((Windows.UI.Xaml.Controls.Primitives.Selector)e.Parameter).SelectedItem;
                    routingtab.Margin = new Thickness(0, 0, 12, 0);
                    // routingtab.Content = new MixAmpRoutingScreen(items);

                    navigationdone = true;
                }
                if (input == "Selected" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 3;
                    //routingtab.Content = new StreamMix(input);
                    navigationdone = true;
                }
                else if (input != "Selected" && navigationdone == false)
                {
                    TabHeaderView.SelectedIndex = 2;
                    // routingtab.Content = new StreamMix(input);
                    navigationdone = true;
                }
            }
            else
            {
                TabHeaderView.SelectedIndex = 1;
            }
            //Debug.WriteLine("Navigated");
        }

        private void TabHeaderView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var basescreen = TabHeaderView.FindName("EqualizerBaseScreen") as EqualizerBaseScreen;
            var equalizerscreen = basescreen.FindName("EqualizerScreen") as EqualizerScreen;
            var image = equalizerscreen.FindName("BoontaEveImage") as Image;
            //image.Source = new BitmapImage(new Uri("ms-appx:///BoontaEve/Assets/Boonta Eve, Equalizer.png"));
            image.Visibility = Visibility.Visible;
            PivotItem pivot = (PivotItem)(sender as Pivot).SelectedItem;
            Pivot pivotMain = (sender as Pivot);
            switch (pivot.Name)
            {
                case "routingtab":
                    RoutingIcon.Opacity = 1;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 0.5;
                    ModuleIcon.Opacity = 0.5;
                    break;
                case "MixerItem":
                    RoutingIcon.Opacity = 0.5;
                    MixerIcon.Opacity = 1;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 0.5;
                    ModuleIcon.Opacity = 0.5;
                    break;
                case "MicrophoneItem":
                    RoutingIcon.Opacity = 0.5;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 1;
                    EQIcon.Opacity = 0.5;
                    ModuleIcon.Opacity = 0.5;
                    break;
                case "EQItem":
                    RoutingIcon.Opacity = 0.5;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 1;
                    ModuleIcon.Opacity = 0.5;
                    break;
                case "DaisyChain":
                    RoutingIcon.Opacity = 0.5;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 0.5;
                    ModuleIcon.Opacity = 1;
                    break;
                case "":
                    Frame parentFrame = Window.Current.Content as Frame;
                    parentFrame.Navigate(typeof(MainPage));
                    break;
                default:
                    RoutingIcon.Opacity = 1;
                    TabHeaderView.SelectedIndex = 0;
                    MixerIcon.Opacity = 0.5;
                    MicrophoneIcon.Opacity = 0.5;
                    EQIcon.Opacity = 0.5;
                    ModuleIcon.Opacity = 0.5;

                    break;
            }
        }

    }
}
