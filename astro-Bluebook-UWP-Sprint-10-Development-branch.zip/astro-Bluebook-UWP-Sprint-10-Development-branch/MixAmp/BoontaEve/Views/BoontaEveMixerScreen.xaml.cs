﻿using MixAmp.BoontaEve.ViewModels;
using MixAmp.BoontaEve.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.BoontaEve.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BoontaEveMixerScreen : Page
    {
        Size size;
        public BoontaEveMixerScreen()
        {
            this.InitializeComponent();
            this.DataContext = new MixAmpMixerViewModel();
            var visibleBounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            size = new Size(visibleBounds.Width * scaleFactor, visibleBounds.Height * scaleFactor);
            SetMaximumListHeight(size.Height);
            MixerLeftPanel.DataContext = new MixerViewModel();
        }
        private void SetMaximumListHeight(double screenHeight)
        {
            if (screenHeight >= 640 && screenHeight < 768)
            {
                scrollGlobe.Height = 700;
            }
            else if (screenHeight >= 768 && screenHeight < 1080)
            {
                scrollGlobe.Height = 800;
            }
            else if (screenHeight >= 1080)
            {
                scrollGlobe.Height = 1000;
            }
        }

        private void Gridright_Loaded(object sender, RoutedEventArgs e)
        {
            var view = DisplayInformation.GetForCurrentView();
            var scale = view.ResolutionScale == ResolutionScale.Invalid ? 1 : view.RawPixelsPerViewPixel;
            var resolution = new Size(view.ScreenWidthInRawPixels, view.ScreenHeightInRawPixels);
            var screenheight = resolution.Height;

            if (scale != 2)
            {
                screenheight = resolution.Height - (resolution.Height * (scale - 1));
            }
            else
            {
                screenheight = resolution.Height - (resolution.Height * (1.75 - 1));
            }

            if (screenheight < 1000 && screenheight > 850)
            {
                var success = scrollGlobe.ChangeView(null, null, 0.9f);
            }
            else if (screenheight < 850 && screenheight > 700)
            {
                var success = scrollGlobe.ChangeView(null, null, 0.8f);
            }
            else if (screenheight < 700 && screenheight > 450)
            {
                var success = scrollGlobe.ChangeView(null, null, 0.63f);
            }
            else if (screenheight < 450)
            {
                var success = scrollGlobe.ChangeView(null, null, 0.6f);
            }
        }
    }
}

