﻿using MixAmp.Common.UserControls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace MixAmp.BoontaEve.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BoontaEveRoutingScreen : Page
    {
        Size size;
        public BoontaEveRoutingScreen()
        {
            this.InitializeComponent();
            Load();
        }


        private void Load()
        {

            StackPanel usercontrol = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(160, 50, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Top,        
            };
            ScrUsercontrol.Content = usercontrol;
            SourceUserControl uc;
            string selectedinput = string.Empty;
            //var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
            //foreach (var item in lists)
            //{
            //    selectedinput = item.InputDevicename;
            //}
            Dictionary<string, string> inputdevice = new Dictionary<string, string>();
            inputdevice.Add("Headset", "AUX");
            //inputdevice.Add("Stream Mix", "Stream USB-C");
            //inputdevice.Add("Stream Mic", "Stream USB-C");
            //inputdevice.Add("Game Mic", "Game USB-C");
            //inputdevice.Add("AUX", "AUX 1/8");
            inputdevice.Add("Stream", "USB");
            inputdevice.Add("Chain", "Chain");
            inputdevice.Add("Speaker", "Bluetooth");
            foreach (var device in inputdevice)
            {
                uc = new SourceUserControl();
                //if (selectedinput == device.Key)
                //{
                //    this.InitializeComponent();
                //}
                var text = uc.FindName("txt1") as TextBlock;
                var text1 = uc.FindName("txt2") as TextBlock;
                var playbutton = uc.FindName("ison") as TextBlock;
                var selectedbutton = uc.FindName("btntop") as Button;
                var selectedImage = uc.FindName("selectedcontrol") as Image;
                var routingplaybutton = uc.FindName("routingplaybutton") as RadioButton;
                text.Text = device.Key;
                text1.Text = device.Value;
                playbutton.Text = "Selected";
                if (text.Text == "Headset")
                {
                    selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Mixer.png"));
                }
                else
                    selectedImage.Source = new BitmapImage(new Uri("ms-appx:///Assets/Vector.png"));
                usercontrol.Children.Add(uc);

            }


        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            var view = DisplayInformation.GetForCurrentView();
            var scale = view.ResolutionScale == ResolutionScale.Invalid ? 1 : view.RawPixelsPerViewPixel;
            var resolution = new Size(view.ScreenWidthInRawPixels, view.ScreenHeightInRawPixels);
            var screenheight = resolution.Height;

            if (scale != 2)
            {
                screenheight = resolution.Height - (resolution.Height * (scale - 1));
            }
            else
            {
                screenheight = resolution.Height - (resolution.Height * (1.75 - 1));
            }

            if (screenheight < 1000 && screenheight > 850)
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.95f);
            }
            else if (screenheight < 850 && screenheight > 700)
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.9f);
            }
            else if (screenheight < 700 && screenheight > 450)
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.8f);
            }
            else if (screenheight < 450)
            {
                var success = ScrUsercontrol.ChangeView(null, null, 0.7f);
            }
        }
    }
}
