﻿using DataAccessLibrary;
using Microsoft.Data.Sqlite;
using MixAmp.Common.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml;

namespace MixAmp.BoontaEve.ViewModels
{
   public class BoontaEveDaisyChainCommonViewModel:INotifiBaseCls
    {

        public string _Name;
        public string _Status;
        public bool _Is_Selected;
        public Visibility FortyEightV_Visibility { get; set; }
        public Windows.UI.Xaml.Media.SolidColorBrush TextColor { get; set; }
        public Visibility SideBorderVisibility { get; set; }
        public bool Is_New;
        public bool Is_Duplicate;

        public BoontaEveDaisyChainCommonViewModel()
        {

        }
       
        public DataSet GetChainRecord()
        {
            DataSet ds = new DataSet();
            string query = "SELECT* from tblDaisyChain";
            ds= DataAccess.GetData(query);
            return ds;
        }
        public DataSet GetUserRecord()
        {
            DataSet ds = new DataSet();
            string query = "SELECT* from tblDaisyChainUser";
            ds = DataAccess.GetData(query);
            return ds;
        }
        public DataSet GetUserRecord(int id)
        {
            DataSet ds = new DataSet();
            string query = "SELECT* from tblDaisyChainUser where daisyChainId='" + id + "'";

            ds = DataAccess.GetData(query);
            return ds;
        }
        public void UpdateChainRecord(string name, int id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
          // updateCommand.CommandText = "UPDATE tblDaisyChain SET name='"+ name + "' WHERE @daisyChainId='"+ id + "'";
            updateCommand.CommandText = "update tblDaisyChain set name = :info where daisyChainId=:id";
            updateCommand.Parameters.AddWithValue("info", name);
            updateCommand.Parameters.AddWithValue("id", id);            
            DataAccess.UpdateRecord(updateCommand);
        }
        public void UpdateChainRecord(string name,string description, int id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            // updateCommand.CommandText = "UPDATE tblDaisyChain SET name='"+ name + "' WHERE @daisyChainId='"+ id + "'";
            updateCommand.CommandText = "update tblDaisyChain set name = :info,description=:Dec where daisyChainId=:id";
            updateCommand.Parameters.AddWithValue("info", name);
            updateCommand.Parameters.AddWithValue("Dec", description);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public void UpdateChainRecord(bool isConnected, int id)
        {
            SqliteCommand updateCommand = new SqliteCommand();           
            updateCommand.CommandText = "update tblDaisyChain set isConnected=:connected where daisyChainId=:id";          
            updateCommand.Parameters.AddWithValue("connected", isConnected);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public void UpdateChainRecord(string name, bool isLocked, int id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblDaisyChain set name=:info, isLocked=:locked where daisyChainId=:id";
            updateCommand.Parameters.AddWithValue("info", name);
            updateCommand.Parameters.AddWithValue("locked", isLocked);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public void UpdateChainRecord(string name,int userLimit, bool Is_New, int id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblDaisyChain set name=:info, userLimit=:limit,Is_New=:Is_New where daisyChainId=:id";
            updateCommand.Parameters.AddWithValue("info", name);
            updateCommand.Parameters.AddWithValue("limit", userLimit);
            updateCommand.Parameters.AddWithValue("Is_New", Is_New);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public void UpdateChainRecord(string name, int userLimit,int itemPosition, bool Is_New,bool isChainBlock, int id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblDaisyChain set name=:info, userLimit=:limit,itemPosition=:Position, Is_New=:Is_New ,isChainBlock=:block where daisyChainId=:id";
            updateCommand.Parameters.AddWithValue("info", name);
            updateCommand.Parameters.AddWithValue("limit", userLimit);
            updateCommand.Parameters.AddWithValue("Position", itemPosition);
            updateCommand.Parameters.AddWithValue("Is_New", Is_New);
            updateCommand.Parameters.AddWithValue("block", isChainBlock);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public void UpdateChainRecord(string name, string description, int userLimit, int itemPosition, bool Is_New, bool isChainBlock, bool isLocked, bool isConnected, int availableUserCount, int id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblDaisyChain set name=:info,description=:description, userLimit=:limit,itemPosition=:Position, Is_New=:Is_New ,isChainBlock=:block,isLocked=:isLocked,isConnected=:connected,availableUserCount=:availableCount where daisyChainId=:id";
            updateCommand.Parameters.AddWithValue("info", name);
            updateCommand.Parameters.AddWithValue("description", description);
            updateCommand.Parameters.AddWithValue("limit", userLimit);
            updateCommand.Parameters.AddWithValue("Position", itemPosition);
            updateCommand.Parameters.AddWithValue("Is_New", Is_New);
            updateCommand.Parameters.AddWithValue("block", isChainBlock);
            updateCommand.Parameters.AddWithValue("isLocked", isLocked);
            updateCommand.Parameters.AddWithValue("connected", isConnected);
            updateCommand.Parameters.AddWithValue("availableCount", availableUserCount);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }

        public void UpdateUserRecord(string name, bool isHost, bool Isleave, int id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblDaisyChainUser set name=:username, isHost=:Host,isMember=:Isleave where daisyChainuserId=:id";
            updateCommand.Parameters.AddWithValue("username", name);
            updateCommand.Parameters.AddWithValue("Host", isHost);
            updateCommand.Parameters.AddWithValue("Isleave", Isleave);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public void UpdateUserRecord(bool isHost, int daisyChainId, string daisyChainName, int id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblDaisyChainUser set isHost=:Host,daisyChainId=:daisyChainId,daisyChainName=:daisyChainName where daisyChainuserId=:id";
            //updateCommand.Parameters.AddWithValue("username", name);
            updateCommand.Parameters.AddWithValue("Host", isHost);
            updateCommand.Parameters.AddWithValue("daisyChainId", daisyChainId);
            updateCommand.Parameters.AddWithValue("daisyChainName", daisyChainName);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public void UpdateUserRecord(string name, string status, bool isHost, bool Isleave, int id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblDaisyChainUser set name=:username,description=:status, isHost=:Host,isMember=:Isleave where daisyChainuserId=:id";
            updateCommand.Parameters.AddWithValue("username", name);
            updateCommand.Parameters.AddWithValue("status", status);
            updateCommand.Parameters.AddWithValue("Host", isHost);
            updateCommand.Parameters.AddWithValue("Isleave", Isleave);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }
        public void UpdateUserRecord(string name, bool isBlock, string status, int Volume, bool isHost, bool isMember, bool Isleave, bool isMute, bool Is_New, int Chainid, int id)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "update tblDaisyChainUser set name=:username,isBlock=:isBlock, description=:status,Volume=:Volume, isHost=:Host,isMember=:isMember,Isleave=:Isleave,isMute=:isMute,Is_New=:Is_New,daisyChainId=:Chainid where daisyChainuserId=:id";
            updateCommand.Parameters.AddWithValue("username", name);
            updateCommand.Parameters.AddWithValue("isBlock", isBlock);
            updateCommand.Parameters.AddWithValue("status", status);
            updateCommand.Parameters.AddWithValue("Volume", Volume);
            updateCommand.Parameters.AddWithValue("Host", isHost);

            updateCommand.Parameters.AddWithValue("Isleave", Isleave);
            updateCommand.Parameters.AddWithValue("isMember", isMember);
            updateCommand.Parameters.AddWithValue("isMute", isMute);
            updateCommand.Parameters.AddWithValue("Is_New", Is_New);
            updateCommand.Parameters.AddWithValue("Chainid", Chainid);
            updateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(updateCommand);
        }

    }
    /// <summary>
    /// Static methods for create the tables in sqlite db
    /// </summary>
    public static class DaisyChainStaticCls
    {
        public static void CreateDaisyChainTable()
        {
            String[] tableCommand = new String[6];
            tableCommand[0] = "CREATE TABLE IF NOT " +
                 "EXISTS tblDaisyChain (daisyChainId INTEGER PRIMARY KEY, " +
                 "name NVARCHAR(200) NULL, " +
                 "description NVARCHAR(200) NULL, " +
                 "isConnected BOOLEAN NULL, " +
                 "isLocked BOOLEAN NULL, " +
                 "itemPosition INTEGER NULL, " +
                 "userLimit INTEGER NULL, " +
                 "availableUserCount INTEGER NULL, " +
                 "isChainBlock BOOLEAN NULL, "+
                 "Is_New BOOLEAN NULL)";

            tableCommand[1] = "CREATE TABLE IF NOT " +
                 "EXISTS tblDaisyChainUser (daisyChainuserId INTEGER PRIMARY KEY, " +
                 "name NVARCHAR(200) NULL, " +
                 "itemPosition INTEGER NULL, " +
                 "isBlock BOOLEAN NULL, " +
                 "description NVARCHAR(200) NULL, " +
                 "isHost BOOLEAN NULL, " +
                 "daisyChainName NVARCHAR(200) NULL, " +
                 "daisyChainId INTEGER NULL, " +
                 "isMember BOOLEAN NULL, " +
                 "Volume INTEGER NULL, " +
                 "isMute BOOLEAN NULL, " +
                 "IsLeave BOOLEAN NULL, " +
                "Is_New BOOLEAN NULL)";

            //tableCommand[2] = "CREATE TABLE IF NOT " +
            //       "EXISTS tblCarina (deviceId NVARCHAR(200) PRIMARY KEY, " +
            //       "deviceName NVARCHAR(200) NULL, " +
            //       "firmwareUpdate NVARCHAR(200) NULL, " +
            //       "isPhantomPowerOn BOOLEAN NULL)";

            //tableCommand[3] = "CREATE TABLE IF NOT " +
            //               "EXISTS tblCarbonite (deviceId NVARCHAR(200) PRIMARY KEY, " +
            //                "deviceName NVARCHAR(200) NULL, " +
            //                "firmwareUpdate NVARCHAR(200) NULL, " +
            //                "sleepMode NVARCHAR(200) NULL," +
            //                "tones NVARCHAR(200) NULL)";

            //tableCommand[4] = "CREATE TABLE IF NOT " +
            //               "EXISTS tblBoontaEve (brightnessValue NVARCHAR(200) PRIMARY KEY, " +
            //                "deviceId NVARCHAR(200) NULL, " +
            //                "deviceName NVARCHAR(200) NULL, " +
            //                "firmwareUpdate NVARCHAR(200) NULL," +
            //                "isAllowmangementEnabled BOOLEAN NULL, " +
            //                "isAutomaticReconnectEnabled BOOLEAN NULL, " +
            //                "isBluetoothEnabled BOOLEAN NULL, " +
            //                "isChainGameSoundEnabled BOOLEAN NULL, " +
            //                "isWifiChainEnabled BOOLEAN NULL)";

            tableCommand[2] = "CREATE TABLE IF NOT " +
                 "EXISTS tblCarina_DeviceSettings (deviceId NVARCHAR(200) PRIMARY KEY, " +
                 "deviceName NVARCHAR(200) NULL, " +
                 "firmwareUpdate NVARCHAR(200) NULL, " +
                 "isPhantomPowerOn BOOLEAN NULL)";

            tableCommand[3] = "CREATE TABLE IF NOT " +
                 "EXISTS tblCarbonite_DeviceSettings (deviceId NVARCHAR(200) PRIMARY KEY, " +
                 "deviceName NVARCHAR(200) NULL, " +
                 "firmwareUpdate NVARCHAR(200) NULL, " +
                 "sleepMode NVARCHAR(200) NULL, " +
                 "tones NVARCHAR(200) NULL)";

            tableCommand[4] = "CREATE TABLE IF NOT " +
                 "EXISTS tblBoontaEve_DeviceSettings (deviceId NVARCHAR(200) PRIMARY KEY, " +
                 "deviceName NVARCHAR(200) NULL, " +
                 "firmwareUpdate NVARCHAR(200) NULL, " +
                 "brightnessValue NVARCHAR(200) NULL, " +
                 "isAllowmanagementEnabled BOOLEAN NULL, " +
                 "isAutomaticReconnectEnabled BOOLEAN NULL, " +
                 "isBluetoothEnabled BOOLEAN NULL, " +
                 "isChainGameSoundEnabled BOOLEAN NULL, " +
                 "isWifiChainEnabled BOOLEAN NULL)";

            tableCommand[5] = "CREATE TABLE IF NOT " +
                            "EXISTS tblProfile (profileName NVARCHAR(200) PRIMARY KEY, " +
                            "profileStatus NVARCHAR(200) NULL, " +
                            "isSelected BOOLEAN NULL, " +
                            "fourtyEightVisibility BOOLEAN NULL, " +
                            "SideBarVisibility BOOLEAN NULL, " +
                            "textColor NVARCHAR(200) NULL, " +
                            "isNew BOOLEAN NULL, " +
                            "isDuplicate BOOLEAN NULL)";
            DataAccess.InitializeDatabase(tableCommand);
        }

        public static void SaveChainDetails(int chainID, string name, string Description, bool isConnected, bool isLocked, int itemPosition, int userLimit, int availableUserCount, bool isChainBlock, bool Is_New)
        {
            SqliteCommand insertCommand = new SqliteCommand();
            insertCommand.CommandText = "INSERT INTO tblDaisyChain VALUES (@daisyChainId, @name, @description, @isConnected, @isLocked, @itemPosition, @userLimit, @availableUserCount,@isChainBlock,@Is_New)";
            insertCommand.Parameters.AddWithValue("@daisyChainId", chainID);
            insertCommand.Parameters.AddWithValue("@name", name);
            insertCommand.Parameters.AddWithValue("@description", Description);
            insertCommand.Parameters.AddWithValue("@isConnected", isConnected);
            insertCommand.Parameters.AddWithValue("@isLocked", isLocked);
            insertCommand.Parameters.AddWithValue("@itemPosition", itemPosition);
            insertCommand.Parameters.AddWithValue("@userLimit", userLimit);
            insertCommand.Parameters.AddWithValue("@availableUserCount", availableUserCount);
            insertCommand.Parameters.AddWithValue("@isChainBlock", isChainBlock);
            insertCommand.Parameters.AddWithValue("@Is_New", Is_New);
            DataAccess.InsertData(insertCommand);
        }
        public static void SaveUserDetails(int daisyChainuserId, string name, int itemPosition, bool isBlock, string description, bool isHost, string daisyChainName, int daisyChainId, bool isMember, int Volume, bool isMute, bool Is_New, bool IsLeave)
        {
            SqliteCommand insertCommand = new SqliteCommand();
            insertCommand.CommandText = "INSERT INTO tblDaisyChainUser VALUES (@daisyChainuserId, @name, @itemPosition, @isBlock, @description, @isHost, @daisyChainName, @daisyChainId,@isMember,@Volume,@isMute,@Is_New,@IsLeave)";
            insertCommand.Parameters.AddWithValue("@daisyChainuserId", daisyChainuserId);
            insertCommand.Parameters.AddWithValue("@name", name);
            insertCommand.Parameters.AddWithValue("@itemPosition", itemPosition);
            insertCommand.Parameters.AddWithValue("@isBlock", isBlock);
            insertCommand.Parameters.AddWithValue("@description", description);
            insertCommand.Parameters.AddWithValue("@isHost", isHost);
            insertCommand.Parameters.AddWithValue("@daisyChainName", daisyChainName);
            insertCommand.Parameters.AddWithValue("@daisyChainId", daisyChainId);
            insertCommand.Parameters.AddWithValue("@isMember", isMember);
            insertCommand.Parameters.AddWithValue("@Volume", Volume);
            insertCommand.Parameters.AddWithValue("@isMute", isMute);
            insertCommand.Parameters.AddWithValue("@Is_New", Is_New);
            insertCommand.Parameters.AddWithValue("@IsLeave", IsLeave);
            DataAccess.InsertData(insertCommand);
        }
        public static void DeleteRecord(string tableName, int ID)
        {
            SqliteCommand updateCommand = new SqliteCommand();
            updateCommand.CommandText = "delete from  '" + tableName + "'  where daisyChainId=:id";
            updateCommand.Parameters.AddWithValue("id", ID);
            DataAccess.DeleteRecord(updateCommand);
        }

    }
}
