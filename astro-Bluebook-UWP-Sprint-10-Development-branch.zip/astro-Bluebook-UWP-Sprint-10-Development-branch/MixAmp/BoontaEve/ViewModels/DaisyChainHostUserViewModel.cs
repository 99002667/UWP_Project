﻿using MixAmp.Common.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;

namespace MixAmp.BoontaEve.ViewModels
{
    public class DaisyChainHostUserViewModel : INotifiBaseCls
    {
        public int ID_;
        public string Name_;
        public int ChainID_;
        public string ChainName { get; set; }
        public string Status_;
        public bool Is_Selected_;
        public Visibility FortyEightV_Visibility { get; set; }
        public Windows.UI.Xaml.Media.SolidColorBrush TextColor { get; set; }
        public Visibility SideBorderVisibility { get; set; }
        public bool IsBlocked_;
        public bool IsMute_;
        public bool IsHost_;
        public bool Isleave_;
        public bool isMember_;
        public bool Is_New_;
        public bool Is_Duplicate_;
        public int Volume_;
        public Visibility MuteVisible { get; set; }
        public Visibility ArrowOptionVisible { get; set; }
        public bool IsUpdate_ = false;
        BoontaEveDaisyChainCommonViewModel DaisyChainCommonModel = new BoontaEveDaisyChainCommonViewModel();
        public int ID
        {
            get { return ID_; }
            set
            {
                ID_ = value;

                // OnPropertyChanged(ID);
            }
        }
        public int ChainID
        {
            get { return ChainID_; }
            set
            {
                ChainID_ = value;

                // OnPropertyChanged(ID);
            }
        }
        public string Name
        {
            get { return Name_; }
            set
            {
                Name_ = value;

                OnPropertyChanged(Name);
            }
        }
        public int Volume
        {
            get { return Volume_; }
            set
            {
                Volume_ = value;

                // OnPropertyChanged(ID);
            }
        }
        public string Status
        {
            get { return Status_; }
            set
            {
                if (Status_ != value)
                {
                    Status_ = value;
                    // DaisyChainCommonModel.UpdateUserRecord(Name_, Status_, IsHost_, Isleave_, ID);
                    OnPropertyChanged(Status);
                }
            }
        }
        public bool Is_Selected
        {
            get { return Is_Selected_; }
            set
            {
                // Is_Selected_ = Is_Selected_ == value ? Is_Selected_ : value;
                if (Is_Selected_ != value)
                {
                    Is_Selected_ = value;
                }
            }
        }
        public bool IsBlocked
        {
            get { return IsBlocked_; }
            set
            {
                // IsBlocked_ = IsBlocked_ == value ? IsBlocked_ : value;
                if (IsBlocked_ != value)
                {
                    IsBlocked_ = value;
                }
            }
        }
        public bool IsMute
        {
            get { return IsMute_; }
            set
            {
                // IsMute_ = IsMute_ == value ? IsMute_ : value;

                if (IsMute_ != value)
                {
                    IsMute_ = value;
                }
            }
        }
        public bool IsHost
        {
            get { return IsHost_; }
            set
            {

                // IsHost_ = IsHost_ == value ? IsHost_ : value;
                if (IsHost_ != null && IsHost_ != value)
                {
                    IsHost_ = value;
                    // DaisyChainCommonModel.UpdateUserRecord(Name_, Status_, IsHost_, Isleave_, ID);
                }
            }
        }
        public bool Isleave
        {
            get { return Isleave_; }
            set
            {

                if (Isleave_ != null && Isleave_ != value)
                {
                    Isleave_ = value;
                }

            }
        }
        public bool isMember
        {
            get { return isMember_; }
            set
            {

                if (isMember_ != null && isMember_ != value)
                {
                    isMember_ = value;
                }

            }
        }
        public bool Is_New
        {
            get { return Is_New_; }
            set
            {
                // Is_New_ = Is_New_ == value ? Is_New_ : value;
                if (Is_New_ != value)
                {
                    Is_New_ = value;
                }
            }
        }
        public bool Is_Duplicate
        {
            get { return Is_Duplicate_; }
            set
            {
                if (Is_Duplicate_ != value)
                {
                    Is_Duplicate_ = value;
                }
                //Is_Duplicate_ = Is_Duplicate_ == value ? Is_Duplicate_ : value;

            }
        }
        public bool IsUpdate
        {
            get { return IsUpdate_; }
            set
            {
                if (IsUpdate_ != value)
                {
                    // DaisyChainCommonModel.UpdateUserRecord(Name_, Status_, IsHost_, Isleave_, ID);
                    DaisyChainCommonModel.UpdateUserRecord(Name_, IsBlocked_, Status_, Volume_, IsHost_, isMember_, Isleave_, IsMute_, Is_New_, ChainID_, ID);
                }
                //Is_Duplicate_ = Is_Duplicate_ == value ? Is_Duplicate_ : value;
            }
        }

        public DaisyChainHostUserViewModel(string Name, string Status, bool IsBlocked, bool IsMute, bool IsHost, bool Isleave, bool Is_Selected, Visibility FortyEightV_Visibility, Visibility SideBorderVisibility, SolidColorBrush TextColor, bool Is_New, bool Is_Duplicate, Visibility MuteVisible, bool IsUpdate, int ChainID, string ChainName, Visibility ArrowOptionVisible, int Volume, bool isMember)
        {
            this.Name = Name;
            this.Status = Status;
            this.Is_Selected = Is_Selected;
            this.FortyEightV_Visibility = FortyEightV_Visibility;
            this.SideBorderVisibility = SideBorderVisibility;
            this.TextColor = TextColor;
            this.Is_New = Is_New;
            this.Is_Duplicate = Is_Duplicate;
            this.IsBlocked = IsBlocked;
            this.IsMute = IsMute;
            this.IsHost = IsHost;
            this.Isleave = Isleave;
            this.MuteVisible = MuteVisible;
            this.IsUpdate = IsUpdate;
            this.ChainID = ChainID;
            this.ChainName = ChainName;
            this.ArrowOptionVisible = ArrowOptionVisible;
            this.Volume = Volume;
            this.isMember = isMember;
        }
        public DaisyChainHostUserViewModel()
        { }

        public class TeamUsers : ObservableCollection<DaisyChainHostUserViewModel>
        {
            public TeamUsers()
            {
                BoontaEveDaisyChainCommonViewModel vm = new BoontaEveDaisyChainCommonViewModel();
                DataSet ds = new DataSet();
                ds = vm.GetUserRecord();
                DataTable dt = new DataTable();
                dt = ds.Tables[0];
                var aa = dt.Rows[0]["name"].ToString();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DaisyChainHostUserViewModel userModel = new DaisyChainHostUserViewModel();
                    userModel.ID = Convert.ToInt32(dt.Rows[i]["daisyChainuserId"]);
                    userModel.Name = dt.Rows[i]["name"].ToString();
                    userModel.Status = dt.Rows[i]["description"].ToString();
                    userModel.Isleave = Convert.ToBoolean(dt.Rows[i]["IsLeave"]);
                    userModel.isMember = Convert.ToBoolean(dt.Rows[i]["isMember"]);
                    userModel.IsHost = Convert.ToBoolean(dt.Rows[i]["isHost"]);
                    userModel.Is_Selected = (userModel.IsHost == true) ? true : false;
                    userModel.FortyEightV_Visibility = Visibility.Collapsed;
                    userModel.SideBorderVisibility = Visibility.Collapsed;
                    userModel.TextColor = new SolidColorBrush(Color.FromArgb(255, 255, 54, 0));
                    userModel.Is_New = Convert.ToBoolean(dt.Rows[i]["Is_New"]);
                    userModel.Is_Duplicate = false;
                    userModel.IsBlocked = Convert.ToBoolean(dt.Rows[i]["isBlock"]);
                    // userModel.itemPosition = Convert.ToInt32(dt.Rows[i]["itemPosition"]);
                    userModel.IsMute = Convert.ToBoolean(dt.Rows[i]["isMute"]);
                    userModel.MuteVisible = Visibility.Visible;
                    userModel.IsUpdate = false;
                    userModel.ChainID = Convert.ToInt32(dt.Rows[i]["daisyChainId"]);
                    userModel.ChainName = dt.Rows[i]["daisyChainName"].ToString();
                    userModel.ArrowOptionVisible = Visibility.Visible;
                    userModel.Volume = Convert.ToInt32(dt.Rows[i]["Volume"]);
                    Add(userModel);
                }


                //Add(new ProfileViewModel("Xbox", "Active Profile", true, true, new SolidColorBrush(Colors.FromArgb(255,255,4,255))));
                //Add(new DaisyChainHostUserViewModel("User 1 (You)", "Host - Team Red", false, false, true, false, true, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false,Visibility.Visible));
                //Add(new DaisyChainHostUserViewModel("User 2", "Team Red", false, false, false, false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible));
                //Add(new DaisyChainHostUserViewModel("User 3", "Team Red", false, false, false, false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible));
                //Add(new DaisyChainHostUserViewModel("User 4", "Team Red", false, false, false, false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible));
                //Add(new DaisyChainHostUserViewModel("User 5", "Team Red", false, false, false, false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible));
            }
        }
        public class Users : ObservableCollection<DaisyChainHostUserViewModel>
        {
            public Users()
            {
                //Add(new DaisyChainHostUserViewModel("User 1 (You)", "Team Blue", false, false, false, false, true, Visibility.Visible, Visibility.Visible, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible),false);
                //Add(new DaisyChainHostUserViewModel("User 2 ", "Host - Team Blue", false, false, true, false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible), false);
                //Add(new DaisyChainHostUserViewModel("User 3", "Team Blue", false, false, true, false, false, Visibility.Visible, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible), false);
                //Add(new DaisyChainHostUserViewModel("User 4", "Team Blue", false, false, true, false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible), false);
                //Add(new DaisyChainHostUserViewModel("User 5", "Team Blue", false, false, true, false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible), false);
            }
        }
        public class NewChain : ObservableCollection<DaisyChainHostUserViewModel>
        {
            public NewChain()
            {
                ////Add(new ProfileViewModel("Xbox", "Active Profile", true, true, new SolidColorBrush(Colors.FromArgb(255,255,4,255))));
                //Add(new DaisyChainHostUserViewModel("User 1", "Host - Team Blue", false, false, true, false, true, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible));
                //Add(new DaisyChainHostUserViewModel("User 2", "Team Blue", false, false, false, false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible));
                //Add(new DaisyChainHostUserViewModel("User 3", "Team Blue", false, false, false, false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible));
                //Add(new DaisyChainHostUserViewModel("User 4", "Team Blue", false, false, false, false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, Visibility.Visible));
            }
        }

    }
}
