﻿using DataAccessLibrary;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.ObjectModel;
using System.Data;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace MixAmp.BoontaEve.ViewModels
{
    public class BoontaEveDeviceSettingsViewModel
    {
        public string Name { get; set; }
        public ImageSource Icon { get; set; }
        public double IconWidth { get; set; }
        public double IconHeight { get; set; }
        public string Actual_Settings_Name { get; set; }
        public Thickness IconMargin { get; set; }
        public Thickness Settings_Name_Margin { get; set; }
        public Thickness Arrow_Right_Margin { get; set; }
        public Visibility Status_Visibility { get; set; }
        public int LED_Brightness_Value { get; set; }
        public Visibility LED_Brightness_Visibility { get; set; }
        public Visibility Arrow_Right_Visibility { get; set; }
        public Visibility Toggle_Button_Visibility { get; set; }
        public Visibility Dot_Visibility { get; set; }
        public Visibility Bluetooth_Toggle_Instruction_Visibility { get; set; }
        public bool Bluetooth_Toggle_Is_On { get; set; }


        public BoontaEveDeviceSettingsViewModel(string Name,
            string Actual_Settings_Name,
            ImageSource Icon,
            double IconWidth,
            double IconHeight,
            Thickness IconMargin,
            Thickness Settings_Name_Margin,
            Thickness Arrow_Right_Margin,
            Visibility Status_Visibility,
            Visibility LED_Brightness_Visibility,
            int LED_Brightness_Value,
            Visibility Arrow_Right_Visibility,
            Visibility Toggle_Button_Visibility,
            Visibility Dot_Visibility,
            Visibility Bluetooth_Toggle_Instruction_Visibility,
            bool Bluetooth_Toggle_Is_On)
        {
            this.Name = Name;
            this.Actual_Settings_Name = Actual_Settings_Name;
            this.Icon = Icon;
            this.IconWidth = IconWidth;
            this.IconHeight = IconHeight;
            this.IconMargin = IconMargin;
            this.Settings_Name_Margin = Settings_Name_Margin;
            this.Arrow_Right_Margin = Arrow_Right_Margin;
            this.Status_Visibility = Status_Visibility;
            this.LED_Brightness_Visibility = LED_Brightness_Visibility;
            this.LED_Brightness_Value = LED_Brightness_Value;
            this.Arrow_Right_Visibility = Arrow_Right_Visibility;
            this.Toggle_Button_Visibility = Toggle_Button_Visibility;
            this.Dot_Visibility = Dot_Visibility;
            this.Bluetooth_Toggle_Instruction_Visibility = Bluetooth_Toggle_Instruction_Visibility;
            this.Bluetooth_Toggle_Is_On = Bluetooth_Toggle_Is_On;
        }
    }

    public class BoontaEveDeviceSettings : ObservableCollection<BoontaEveDeviceSettingsViewModel>
    {
        public BoontaEveDeviceSettings()
        {

            Add(new BoontaEveDeviceSettingsViewModel("Name", GetDeviceName(), GetSettingsIcon("Name"), 32, 32, new Thickness(0, 10, 0, 0), new Thickness(0, 0, 0, 0), new Thickness(-20, 20, 0, 0), Visibility.Visible, Visibility.Collapsed, 0, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, Visibility.Collapsed, false));
            Add(new BoontaEveDeviceSettingsViewModel("Firmware Update", "6.3 Update Available", GetSettingsIcon("FirmwareUpdate"), 32, 32, new Thickness(0, 17, 0, 0), new Thickness(0, 10, 0, 0), new Thickness(-20, 20, 0, 0), Visibility.Visible, Visibility.Collapsed, 0, Visibility.Visible, Visibility.Collapsed, Visibility.Visible, Visibility.Collapsed, false));
            Add(new BoontaEveDeviceSettingsViewModel("Daisy Chain", "", GetSettingsIcon("DaisyChain"), 32, 32, new Thickness(0, 20, 0, 0), new Thickness(0, 15, 0, 0), new Thickness(-20, 20, 0, 0), Visibility.Collapsed, Visibility.Collapsed, 0, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, Visibility.Collapsed, false));
            //Add(new BoontaEveDeviceSettingsViewModel("Sleep Mode", "15 Minutes", GetSettingsIcon("SleepMode"), 25, 25, new Thickness(5, 15, 0, 0), new Thickness(0, 0, 0, 0), Visibility.Visible, Visibility.Collapsed,0, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, Visibility.Collapsed));	
            Add(new BoontaEveDeviceSettingsViewModel("Bluetooth", "Off", GetSettingsIcon("Bluetooth"), 32, 32, new Thickness(10, 20, 0, 0), new Thickness(0, 5, 0, 0), new Thickness(-25, 20, 0, 0), Visibility.Visible, Visibility.Collapsed, 0, Visibility.Collapsed, Visibility.Visible, Visibility.Collapsed, Visibility.Visible, GetBluetoothStatus()));
            Add(new BoontaEveDeviceSettingsViewModel("LED Brightness", "0%", GetSettingsIcon("LEDBrightness"), 15, 15, new Thickness(10, 25, 0, 0), new Thickness(0, 10, 0, 0), new Thickness(-20, 20, 0, 0), Visibility.Visible, Visibility.Visible, GetSliderValue(), Visibility.Collapsed, Visibility.Collapsed, Visibility.Collapsed, Visibility.Collapsed, false));
            Add(new BoontaEveDeviceSettingsViewModel("Take The Tour", "", GetSettingsIcon("TakeTheTour"), 32, 32, new Thickness(5, 15, 0, 0), new Thickness(0, 10, 0, 0), new Thickness(-20, 20, 0, 0), Visibility.Collapsed, Visibility.Collapsed, 0, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, Visibility.Collapsed, false));
            Add(new BoontaEveDeviceSettingsViewModel("Reset Device", "", GetSettingsIcon("ResetDevice"), 32, 32, new Thickness(5, 15, 0, 0), new Thickness(0, 10, 0, 0), new Thickness(-20, 20, 0, 0), Visibility.Collapsed, Visibility.Collapsed, 0, Visibility.Visible, Visibility.Collapsed, Visibility.Collapsed, Visibility.Collapsed, false));
        }
        private string GetDeviceName()
        {
            string query = "SELECT* from tblBoontaEve_DeviceSettings";
            DataSet ds = DataAccess.GetData(query);
            var tb = ds.Tables[0];
            return Convert.ToString(tb.Rows[0]["deviceName"]);
        }
        private int GetSliderValue()
        {
            string query = "SELECT* from tblBoontaEve_DeviceSettings";
            DataSet dataSet = DataAccess.GetData(query);
            var table = dataSet.Tables[0];
            return Convert.ToInt32(table.Rows[0]["brightnessValue"]);
        }
        private bool GetBluetoothStatus()
        {
            string query = "SELECT* from tblBoontaEve_DeviceSettings";
            DataSet dataSet = DataAccess.GetData(query);
            var table = dataSet.Tables[0];
            return Convert.ToBoolean(table.Rows[0]["isBluetoothEnabled"]);
        }
        private ImageSource GetSettingsIcon(string SettingsName)
        {
            Image image = new Image();
            if (SettingsName.Equals("Name"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Profile.png"));
            }
            else if (SettingsName.Equals("FirmwareUpdate"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Firmware_Settings.png"));
            }
            else if (SettingsName.Equals("DaisyChain"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Daisy_Chain.png"));
            }
            else if (SettingsName.Equals("SleepMode"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Sleep_Mode.png"));
            }
            else if (SettingsName.Equals("Bluetooth"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Bluetooth_ICON.png"));
            }
            else if (SettingsName.Equals("LEDBrightness"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/LED_Brightness.png"));
            }
            else if (SettingsName.Equals("TakeTheTour"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Tour.png"));
            }
            else if (SettingsName.Equals("ResetDevice"))
            {
                image.Source = new BitmapImage(new Uri("ms-appx:///Assets/Reset_Device.png"));
            }
            return image.Source;
        }
    }
    public static class BoontaEveDeviceSpecificDataViewModel
    {
        public static void InitializeDeviceSpecificSettings()
        {
            DataSet ds = new DataSet();
            string queryCarina = "SELECT* from tblBoontaEve_DeviceSettings";
            ds = DataAccess.GetData(queryCarina);
            var tbCarina = ds.Tables[0];
            var rowCarina = tbCarina.Rows.Count;
            var columnsCarina = tbCarina.Columns.Count;
            if (rowCarina == 0)
            {
                SqliteCommand insertCommand = new SqliteCommand();
                insertCommand.CommandText = " INSERT INTO tblBoontaEve_DeviceSettings VALUES(@brightnessValue, @deviceId, @deviceName, @firmwareUpdate, @isAllowmanagementEnabled, @isAutomaticReconnectEnabled, @isBluetoothEnabled, @isChainGameSoundEnabled, @isWifiChainEnabled)";
                insertCommand.Parameters.AddWithValue("@brightnessValue", "0");
                insertCommand.Parameters.AddWithValue("@deviceId", "1");
                insertCommand.Parameters.AddWithValue("@deviceName", "Alec's Mixamp Pro Tr");
                insertCommand.Parameters.AddWithValue("@firmwareUpdate", "Latest Update");
                insertCommand.Parameters.AddWithValue("@isAllowmanagementEnabled", false);
                insertCommand.Parameters.AddWithValue("@isAutomaticReconnectEnabled", false);
                insertCommand.Parameters.AddWithValue("@isBluetoothEnabled", false);
                insertCommand.Parameters.AddWithValue("@isChainGameSoundEnabled", false);
                insertCommand.Parameters.AddWithValue("@isWifiChainEnabled", false);
                DataAccess.InsertData(insertCommand);
            }

        }
        public static void UpdateName(string NewName, string id)
        {
            SqliteCommand UpdateCommand = new SqliteCommand();
            UpdateCommand.CommandText = "update tblBoontaEve_DeviceSettings set deviceName = :info where deviceId = :id";
            UpdateCommand.Parameters.AddWithValue("info", NewName);
            UpdateCommand.Parameters.AddWithValue("id", id);
            DataAccess.UpdateRecord(UpdateCommand);
        }
    }
}
