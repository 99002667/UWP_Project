﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MixAmp.BoontaEve.ViewModels
{
    public class MixAmpMixerViewModel : MixAmp.Common.ViewModels.INotifiBaseCls
    {
        public MixerViewModel MixerViewModel { get; set; }
        public MixAmpMixerViewModel()
        {
            MixerViewModel = new MixerViewModel();
        }

    }
}
