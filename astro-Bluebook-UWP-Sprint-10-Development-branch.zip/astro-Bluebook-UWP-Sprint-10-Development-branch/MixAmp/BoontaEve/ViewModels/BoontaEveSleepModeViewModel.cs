﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MixAmp.BoontaEve.ViewModels
{
   public class BoontaEveSleepModeViewModel
    {
        public string SleepTimer { get; set; }
        public bool IsSelected { get; set; }

        public BoontaEveSleepModeViewModel(string SleepTimer, bool IsSelected)
        {
            this.SleepTimer = SleepTimer;
            this.IsSelected = IsSelected;
        }
    }

    public class BoontaEveSleepModes : ObservableCollection<BoontaEveSleepModeViewModel>
    {
        public BoontaEveSleepModes()
        {
            Add(new BoontaEveSleepModeViewModel("15 Minutes", true));
            Add(new BoontaEveSleepModeViewModel("30 Minutes", false));
            Add(new BoontaEveSleepModeViewModel("60 Minutes", false));
            Add(new BoontaEveSleepModeViewModel("Disabled", false));
        }
    }
}
