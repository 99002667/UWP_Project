﻿using DataAccessLibrary;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MixAmp.BoontaEve.ViewModels
{
    public class BoontaEveDaisyChainViewModel
    {
        public string Name { get; set; }
        public string Settings_Status { get; set; }
        public bool Toggle_Is_on { get; set; }
        public BoontaEveDaisyChainViewModel(string Name, string Settings_Status, bool Toggle_Is_on)
        {
            this.Name = Name;
            this.Settings_Status = Settings_Status;
            this.Toggle_Is_on = Toggle_Is_on;
        }
    }

    public class BoontaEveDaisyChainSettings : ObservableCollection<BoontaEveDaisyChainViewModel>
    {
        public BoontaEveDaisyChainSettings()
        {
            Add(new BoontaEveDaisyChainViewModel("Enable WiFi Chain", "Capture all ambient noise", GetToggleStatus("isWifiChainEnabled")));
            Add(new BoontaEveDaisyChainViewModel("Chain Game Sound", "Feed audio to shared devices on system", GetToggleStatus("isChainGameSoundEnabled")));
            Add(new BoontaEveDaisyChainViewModel("Automatic Reconnect", "Reconnect to last known available chain", GetToggleStatus("isAutomaticReconnectEnabled")));
            Add(new BoontaEveDaisyChainViewModel("Allow Management", "Allow admin to manage device", GetToggleStatus("isAllowmanagementEnabled")));
        }
        private bool GetToggleStatus(string input)
        {
            string query = "SELECT* from tblBoontaEve_DeviceSettings";
            DataSet dataSet = DataAccess.GetData(query);
            var table = dataSet.Tables[0];
            if (input == "isWifiChainEnabled")
            {
                return Convert.ToBoolean(table.Rows[0]["isWifiChainEnabled"]);
            }
            else if (input == "isChainGameSoundEnabled")
            {
                return Convert.ToBoolean(table.Rows[0]["isChainGameSoundEnabled"]);
            }
            else if (input == "isAutomaticReconnectEnabled")
            {
                return Convert.ToBoolean(table.Rows[0]["isAutomaticReconnectEnabled"]);
            }
            else if (input == "isAllowmanagementEnabled")
            {
                return Convert.ToBoolean(table.Rows[0]["isAllowmanagementEnabled"]);
            }
            return false;
        }
    }


}
