﻿using MixAmp.Common.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Foundation.Diagnostics;
using Windows.UI;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Media;

namespace MixAmp.BoontaEve.ViewModels
{
    public class BoontaEveDaisyChainBaseScreenLeftPanelVM:INotifiBaseCls
    {
        public int ID_;
        public string Name_;
        public string Status_;
        public bool Is_Selected_;
        public Visibility FortyEightV_Visibility { get; set; }
        public Windows.UI.Xaml.Media.SolidColorBrush TextColor { get; set; }
        public Visibility SideBorderVisibility { get; set; }
        public bool Is_New_;
        public bool Is_Duplicate_;
        public bool Is_Deleted_;
        public bool isLocked_;
        public int itemPosition_;
        public int userLimit_;
        public int availableUserCount_;
        public bool isChainBlock_;
        public bool isConnected_;
        public bool IsUpdate_ = false;
        BoontaEveDaisyChainCommonViewModel DaisyChainCommonModel = new BoontaEveDaisyChainCommonViewModel();
        public int ID
        {
            get { return ID_; }
            set
            {
                ID_ = value;

                // OnPropertyChanged(ID);
            }
        }
        public string Name
        {
            get { return Name_; }
            set
            {
                Name_ = value;

                OnPropertyChanged(Name);
            }
        }
        public string Status
        {
            get { return Status_; }
            set
            {
                if (Status_ != value)
                {
                    Status_ = value;
                    // DaisyChainCommonModel.UpdateUserRecord(Name_, Status_, IsHost_, Isleave_, ID);
                    OnPropertyChanged(Status);
                }
            }
        }
        public bool Is_Selected
        {
            get { return Is_Selected_; }
            set
            {
                // Is_Selected_ = Is_Selected_ == value ? Is_Selected_ : value;
                if (Is_Selected_ != value)
                {
                    Is_Selected_ = value;
                }
            }
        }
        public bool Is_New
        {
            get { return Is_New_; }
            set
            {
                // Is_New_ = Is_New_ == value ? Is_New_ : value;
                if (Is_New_ != value)
                {
                    Is_New_ = value;
                }
            }
        }
        public bool Is_Duplicate
        {
            get { return Is_Duplicate_; }
            set
            {
                if (Is_Duplicate_ != value)
                {
                    Is_Duplicate_ = value;
                }
                //Is_Duplicate_ = Is_Duplicate_ == value ? Is_Duplicate_ : value;

            }
        }
        public bool Is_Deleted
        {
            get { return Is_Deleted_; }
            set
            {
                if (Is_Deleted_ != value)
                {
                    Is_Deleted_ = value;
                }
                //Is_Duplicate_ = Is_Duplicate_ == value ? Is_Duplicate_ : value;

            }
        }
        public bool isLocked
        {
            get { return isLocked_; }
            set
            {
                if (isLocked_ != value)
                {
                    isLocked_ = value;
                }
                //Is_Duplicate_ = Is_Duplicate_ == value ? Is_Duplicate_ : value;

            }
        }
        public int itemPosition
        {
            get { return itemPosition_; }
            set
            {
                if (itemPosition_ != value)
                {
                    itemPosition_ = value;
                    OnPropertyChanged(itemPosition.ToString());
                }
                //Is_Duplicate_ = Is_Duplicate_ == value ? Is_Duplicate_ : value;

            }
        }
        public int userLimit
        {
            get { return userLimit_; }
            set
            {
                if (userLimit_ != value)
                {
                    userLimit_ = value;
                    OnPropertyChanged(userLimit.ToString());
                }
                //Is_Duplicate_ = Is_Duplicate_ == value ? Is_Duplicate_ : value;

            }
        }
        public int availableUserCount
        {
            get { return availableUserCount_; }
            set
            {
                if (availableUserCount_ != value)
                {
                    availableUserCount_ = value;
                    OnPropertyChanged(availableUserCount.ToString());
                }
                //Is_Duplicate_ = Is_Duplicate_ == value ? Is_Duplicate_ : value;

            }
        }

        public bool isChainBlock
        {
            get { return isChainBlock_; }
            set
            {
                if (isChainBlock_ != value)
                {
                    isChainBlock_ = value;
                }
                //Is_Duplicate_ = Is_Duplicate_ == value ? Is_Duplicate_ : value;

            }
        }
        public bool isConnected
        {
            get { return isConnected_; }
            set
            {
                if (isConnected_ != value)
                {
                    isConnected_ = value;
                }
                //Is_Duplicate_ = Is_Duplicate_ == value ? Is_Duplicate_ : value;

            }
        }
        public bool IsUpdate
        {
            get { return IsUpdate_; }
            set
            {
                if (IsUpdate_ != value)
                {
                    DaisyChainCommonModel.UpdateChainRecord(Name_,Status_, userLimit_, itemPosition_, Is_New_, isChainBlock_, isLocked_, Is_Selected, availableUserCount_, ID_);
                }               
            }
        }

        public BoontaEveDaisyChainBaseScreenLeftPanelVM(string Name, string Status, bool Is_Selected, bool Is_Deleted, Visibility FortyEightV_Visibility, Visibility SideBorderVisibility, SolidColorBrush TextColor, bool Is_New, bool Is_Duplicate, bool isLocked, int itemPosition, int userLimit, int availableUserCount, bool isChainBlock,bool isConnected, bool IsUpdate)
        {
            this.Name = Name;
            this.Status = Status;
            this.Is_Selected = Is_Selected;
            this.FortyEightV_Visibility = FortyEightV_Visibility;
            this.SideBorderVisibility = SideBorderVisibility;
            this.TextColor = TextColor;
            this.Is_New = Is_New;
            this.Is_Duplicate = Is_Duplicate;
            this.Is_Deleted = Is_Deleted;
            this.isLocked = isLocked;
            this.itemPosition = itemPosition;
            this.userLimit = userLimit;
            this.availableUserCount = availableUserCount;
            this.isChainBlock = isChainBlock;
            this.isConnected = isConnected;
            this.IsUpdate = IsUpdate;
        }
        public BoontaEveDaisyChainBaseScreenLeftPanelVM()
        {
        }
        public class Chain : ObservableCollection<BoontaEveDaisyChainBaseScreenLeftPanelVM>
        {
            public Chain()
            {
                BoontaEveDaisyChainCommonViewModel vm = new BoontaEveDaisyChainCommonViewModel();
                DataSet ds = new DataSet();
                ds = vm.GetChainRecord();
                DataTable dt = new DataTable();
                dt = ds.Tables[0];
                var aa = dt.Rows[0]["name"].ToString();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    BoontaEveDaisyChainBaseScreenLeftPanelVM chainModel=new BoontaEveDaisyChainBaseScreenLeftPanelVM();
                    chainModel.ID= Convert.ToInt32(dt.Rows[i]["daisyChainId"]);
                    chainModel.Name = dt.Rows[i]["name"].ToString();
                    chainModel.Status = dt.Rows[i]["description"].ToString();
                    chainModel.Is_Selected = Convert.ToBoolean(dt.Rows[i]["isConnected"]);
                    chainModel.Is_Deleted = false;
                    chainModel.FortyEightV_Visibility =(i==0) ? Visibility.Visible: Visibility.Collapsed;
                    chainModel.SideBorderVisibility = (i == 0) ? Visibility.Visible : Visibility.Collapsed;
                    if (i==0)
                    {
                        chainModel.TextColor = new SolidColorBrush(Color.FromArgb(255, 255, 54, 0));
                    }
                    else
                    {
                        chainModel.TextColor = new SolidColorBrush(Colors.Gray);
                    }
                    chainModel.Is_New = Convert.ToBoolean(dt.Rows[i]["Is_New"]);
                    chainModel.Is_Duplicate = false;
                    chainModel.isLocked = Convert.ToBoolean(dt.Rows[i]["isLocked"]); 
                    chainModel.itemPosition = Convert.ToInt32(dt.Rows[i]["itemPosition"]);
                    chainModel.userLimit = Convert.ToInt32(dt.Rows[i]["userLimit"]);
                    chainModel.availableUserCount = Convert.ToInt32(dt.Rows[i]["userLimit"]); 
                    chainModel.isChainBlock = Convert.ToBoolean(dt.Rows[i]["isChainBlock"]);
                    chainModel.IsUpdate = false;
                    Add(chainModel);
                }
               
                //Add(new ProfileViewModel("Xbox", "Active Profile", true, true, new SolidColorBrush(Colors.FromArgb(255,255,4,255))));
                //Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("Team Red", "Connected - 5 Users", true,false, Visibility.Visible, Visibility.Visible, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false));
                //Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("Team Blue", "Not Connected - 5 Users", false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Colors.Gray), false, false));
                //Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("Chain 3", "Locked - 4 Users", false, false, Visibility.Visible, Visibility.Collapsed, new SolidColorBrush(Colors.Gray), false, false));
                //Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("Chain 4", "Blocked -3 Users", false, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Colors.Gray), false, false));
            }
        }

        //public class Users : ObservableCollection<BoontaEveDaisyChainBaseScreenLeftPanelVM>
        //{
        //    public Users()
        //    {
        //        Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("User 1 (You)", "Team Blue", true, Visibility.Visible, Visibility.Visible, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false));
        //        Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("User 2 ", "Host - Team Blue", true, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false));
        //        Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("User 3", "Team Blue", true, Visibility.Visible, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false));
        //        Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("User 4", "Team Blue", true, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false));
        //        Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("User 5", "Team Blue", true, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false));

        //    }
        //}

        public class NonhostChangeSetting : ObservableCollection<BoontaEveDaisyChainBaseScreenLeftPanelVM>
        {
            public NonhostChangeSetting()
            {
                //Add(new ProfileViewModel("Xbox", "Active Profile", true, true, new SolidColorBrush(Colors.FromArgb(255,255,4,255))));
       

                Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("Name", "Team Blue", true, false, Visibility.Visible, Visibility.Visible, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)),false, false, false,0,1,1,false,false,false));
                Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("User Limit", "5 User", true, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, false, 0, 1, 1, false, false, false));
                Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("Lock Room", "Open", true, false, Visibility.Visible, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false, false, 0, 1, 1, false, false, false));

            }
        }
        public class HostChangeSetting : ObservableCollection<BoontaEveDaisyChainBaseScreenLeftPanelVM>
        {
            public HostChangeSetting()
            {
                //Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("Name", "Team Blue", true, false, Visibility.Visible, Visibility.Visible, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false));
                //Add(new BoontaEveDaisyChainBaseScreenLeftPanelVM("User Limit", "5 User", true, false, Visibility.Collapsed, Visibility.Collapsed, new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false));

            }
        }
    }
}