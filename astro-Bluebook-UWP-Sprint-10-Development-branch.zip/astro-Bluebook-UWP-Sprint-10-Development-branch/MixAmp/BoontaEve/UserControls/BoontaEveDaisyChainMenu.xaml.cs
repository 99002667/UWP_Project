﻿using MixAmp.BoontaEve.ViewModels;
using MixAmp.Common.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.BoontaEve.UserControls
{
    public sealed partial class BoontaEveDaisyChainMenu : UserControl
    {
        public BoontaEveDaisyChainMenu()
        {
            this.InitializeComponent();
            this.BoontaEveDaisyChainList.ItemsSource = new BoontaEveDaisyChainSettings();
        }

        private void Daisy_Chain_Toggled(object sender, RoutedEventArgs e)
        {
            ToggleSwitch toggleSwitch = e.OriginalSource as ToggleSwitch;
            if (toggleSwitch != null)
            {
                BoontaEveDaisyChainViewModel boontaEveDaisyChainViewModel = toggleSwitch.DataContext as BoontaEveDaisyChainViewModel;
                BoontaEveDaisyChainList.SelectedItem = boontaEveDaisyChainViewModel;
            }
        }

        private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        {
            RelativePanel CurrentMenuParent = this.Parent as RelativePanel;
            UIElementCollection UIElements = CurrentMenuParent.Children;

            foreach (var UIElement in UIElements)
            {
                if (UIElement is BoontaEveDaisyChainMenu)
                {
                    if (this.Visibility == Visibility.Visible)
                    {
                        this.Visibility = Visibility.Collapsed;
                    }
                }
                else if (UIElement is BoontaEveDeviceSettingsMenu)
                {
                    BoontaEveDeviceSettingsMenu BoontaEveDeviceSettingsMenu = UIElement as BoontaEveDeviceSettingsMenu;
                    if (BoontaEveDeviceSettingsMenu.Visibility == Visibility.Collapsed)
                    {
                        BoontaEveDeviceSettingsMenu.Visibility = Visibility.Visible;
                    }
                }
            }
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            StackPanel SettingsStackPanel = (StackPanel)SettingsRelativePanel.Parent;
            FlyoutPresenter SettingsFlyoutPresenter = (FlyoutPresenter)SettingsStackPanel.Parent;
            Popup SettingsPopup = (Popup)SettingsFlyoutPresenter.Parent;

            if (SettingsPopup.IsOpen)
            {
                SettingsPopup.IsOpen = false;
            }
        }
        private void BoontaEveDaisyChainList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListView listView = BoontaEveDaisyChainList as ListView;
            foreach (var item in listView.Items)
            {
                var ListViewItem = (ListViewItem)listView.ContainerFromItem(item);
                if (ListViewItem != null)
                {
                    var ItemViewGrid = (Grid)ListViewItem.ContentTemplateRoot;
                    var toggle = ItemViewGrid.FindName("Daisy_Chain_Toggle") as ToggleSwitch;
                    var toggleName = ItemViewGrid.FindName("Settings_Name") as TextBlock;
                    string id = "1";
                    if (ListViewItem.IsSelected)
                    {
                        if (toggle.IsOn)
                        {
                            DeviceSpecificDataViewModel.UpdateChainToggleStates(true, id, toggleName.Text);
                        }
                        else if (!toggle.IsOn)
                        {
                            DeviceSpecificDataViewModel.UpdateChainToggleStates(false, id, toggleName.Text);
                        }
                    }
                }
            }
        }
    }
}
