﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using MixAmp.Common.UserControls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using static MixAmp.BoontaEve.ViewModels.BoontaEveDaisyChainBaseScreenLeftPanelVM;
using Windows.UI.Xaml.Media.Imaging;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.Toolkit.Extensions;
using MixAmp.BoontaEve.ViewModels;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.BoontaEve.UserControls.DaisyChain
{
    public sealed partial class BoontaEveChangeSettingForHostUserControl : UserControl
    {
        public BoontaEveChangeSettingForHostUserControl()
        {
            this.InitializeComponent();
            // UserList.ItemsSource = new HostChangeSetting();
            // Load();
        }
        private void Load()
        {

            StackPanel usercontrol = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(160, 120, 10, 10),
                HorizontalAlignment = HorizontalAlignment.Left,
                //Width = size.Width - 150,
                //Height = size.Height - 100
            };
            ScrUsercontrol.Content = usercontrol;
            DaisyChainSourceUserControl uc;
            string selectedinput = string.Empty;
            //var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
            //foreach (var item in lists)
            //{
            //    selectedinput = item.InputDevicename;
            //}
            Dictionary<string, string> inputdevice = new Dictionary<string, string>();
            if (App.teamuser[0].Is_New)
            {
                foreach (var item in App.teamuser.Where(x => x.Is_New == true))
                {
                    inputdevice.Add(item.Name, item.Status);
                }
            }
            else
            {
                var selectedChain = App.ChainList.Where(x => x.Is_Selected == true).FirstOrDefault();
                foreach (var item in App.teamuser.Where(x => x.Isleave == false && x.ChainID == selectedChain.ID))
                {
                    inputdevice.Add(item.Name, item.Status);
                }
            }

            foreach (var device in inputdevice)
            {
                int Volume = App.teamuser.Where(x => x.Name == device.Key).FirstOrDefault().Volume;
                uc = new DaisyChainSourceUserControl();
                //if (selectedinput == device.Key)
                //{
                //    this.InitializeComponent();
                //}
                var text = uc.FindName("txt1") as TextBlock;
                var text1 = uc.FindName("txt2") as TextBlock;
                var playbutton = uc.FindName("ison") as TextBlock;
                var selectedbutton = uc.FindName("btntop") as Button;
                var selectedImage = (uc.FindName("selectedcontrol") as Image);
                var speeker = uc.FindName("btnspeaker") as Button;
                var slidr = uc.FindName("Slider4") as Slider;
                speeker.Width = 55;
                var spk = speeker.FindName("stkspeker") as StackPanel;
                spk.Width = 55;
                var spkimg = spk.FindName("speaker") as Image;
                var muteimg = spk.FindName("Mute") as Image;
                muteimg.Margin = new Thickness(20, 0, 0, 0);
                spkimg.Margin = new Thickness(25, 0, 0, 0);
                spk.HorizontalAlignment = HorizontalAlignment.Center;
                (uc.FindName("routingplaybutton") as RadioButton).Visibility = Visibility.Collapsed; ;
                // routingplaybutton.Visibility = Visibility.Collapsed;
                text.Text = device.Key;
                slidr.Value = Volume;
                var strLengh = device.Value.Length;
                var strText = (strLengh < 9) ? device.Value : device.Value.Truncate(9) + "...";
                text1.Text = strText;
                playbutton.Text = "Selected";
                selectedImage.Source = new BitmapImage(new Uri("ms-appx:///BoontaEve/Assets/Chain.png")); ;

                usercontrol.Children.Add(uc);

            }


        }
        private void leftArrow_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Grid DaisyChainHostUserControl = (Grid)Parent;
                DaisyChainHostUserControl baseUserControl = (DaisyChainHostUserControl)DaisyChainHostUserControl.FindName("DaisyChainHostUserControl");

                if (baseUserControl.Visibility == Visibility.Collapsed)
                {
                    baseUserControl.Visibility = Visibility.Visible;
                    this.Visibility = Visibility.Collapsed;
                }
                DeleteTeamPopup.IsOpen = false;
                LimitPopup.IsOpen = false;

            }
            catch (Exception ex)
            {

            }
        }

        private void btnArrow_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnpwdArrow_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DeleteTeamPopup.IsOpen = false;
                LimitPopup.IsOpen = false;
                // txtPassword.Text = txtPWD.Text;
                if (Message_Bar.Visibility == Visibility.Visible)
                {
                    Message_Bar.Visibility = Visibility.Collapsed;
                }
                string ValidationErrorMessage = "";
                bool IsError = false;
                if (true)
                {
                    ValidationErrorMessage += "Chain password copied \n";
                    IsError = true;
                }
                if (IsError)
                {
                    this.SetMessageBarTimeout(Message_Bar, ValidationErrorMessage);
                }
            }
            catch (Exception ex)
            {

            }
        }
        private MessageBar GetMessageBar()
        {
            RelativePanel LoginBaseScreenRelativePanel = (RelativePanel)Parent;
            Grid LoginBaseScreenRelativePanelParent = (Grid)LoginBaseScreenRelativePanel.Parent;
            MessageBar MessageBar = (MessageBar)LoginBaseScreenRelativePanelParent.FindName("Message_Bar");
            return MessageBar;
        }

        private async void SetMessageBarTimeout(MessageBar MessageBar, string ValidationErrorMessage)
        {
            this.ShowValidationErrorMessage(MessageBar, ValidationErrorMessage);
            await Task.Delay(3000);
            this.HideValidationErrorMessage(MessageBar);
        }
        private void ShowValidationErrorMessage(MessageBar MessageBar, string ValidationErrorMessage)
        {
            if (MessageBar.Visibility == Visibility.Collapsed)
            {
                TextBlock Message_Text_Box = (TextBlock)MessageBar.FindName("Message_Text");
                //Message_Text_Box.VerticalAlignment = (VerticalAlignment)AlignmentY.Center;
                Message_Text_Box.Text = ValidationErrorMessage;
                Message_Text_Box.Margin = new Thickness(15, 10, 0, 0);
                MessageBar.Visibility = Visibility.Visible;
            }
        }

        private void HideValidationErrorMessage(MessageBar MessageBar)
        {
            if (MessageBar.Visibility == Visibility.Visible)
            {
                MessageBar.Visibility = Visibility.Collapsed;
            }
        }

        private void MicLevels_Toggled(object sender, RoutedEventArgs e)
        {
            try
            {
                DeleteTeamPopup.IsOpen = false;
                LimitPopup.IsOpen = false;
                var userlist = App.teamuser.Where(x => x.ChainID == App.selectedChainID).ToList();
                if (MicLevels.IsOn)
                {
                    LockStatus.Visibility = Visibility.Visible;
                    unLockStatus.Visibility = Visibility.Collapsed;
                    grdPWD.Visibility = Visibility.Visible;

                    App.ChainList[0].isLocked_ = true;
                    App.ChainList[0].Status = "Locked - Connected - " + userlist.Count + " Users";
                    App.ChainList[0].IsUpdate = true;
                }
                else
                {
                    LockStatus.Visibility = Visibility.Collapsed;
                    unLockStatus.Visibility = Visibility.Visible;
                    grdPWD.Visibility = Visibility.Collapsed;
                    App.ChainList[0].isLocked_ = false;
                    App.ChainList[0].Status = "Connected -" + userlist.Count + " Users";
                    App.ChainList[0].IsUpdate = true;
                }
                //if (LockStatus.Text == "Locked")
                //{
                //    LockStatus.Text = "UnLocked";
                //}
                //else
                //{
                //    LockStatus.Text = "Locked";
                //}
            }
            catch (Exception ex)
            {

            }
        }

        private void SetName_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!String.IsNullOrEmpty(txtName.Text))
                {
                    DeleteTeamPopup.IsOpen = false;
                    LimitPopup.IsOpen = false;
                    txtTeamName.Text = txtName.Text;
                    SelectedTeamName.Text = txtName.Text;
                    App.ChainList[0].Name = txtName.Text;
                    App.ChainList[0].IsUpdate = true;
                    foreach (var item in App.teamuser.Where(x => x.ChainID == 1))
                    {
                        if (item.Status.Contains("Host"))
                        {
                            item.Status = "Host - " + txtName.Text;
                            item.IsUpdate = true;
                        }
                        else
                        {
                            item.Status = txtName.Text;
                            item.IsUpdate = true;
                        }
                    }
                    Grid DaisyChainHostUserControl = (Grid)Parent;
                    DaisyChainHostUserControl baseUserControl = (DaisyChainHostUserControl)DaisyChainHostUserControl.FindName("DaisyChainHostUserControl");
                    BoontaEveDaisyChainBaseUserControl baseControl = (BoontaEveDaisyChainBaseUserControl)DaisyChainHostUserControl.FindName("DaisyChainBaseScreen");

                    var txtHeader = baseUserControl.FindName("txtTeamHeader") as TextBlock;
                    txtHeader.Text = txtTeamName.Text.ToUpper();
                    var lst = baseUserControl.FindName("TeamUserList") as ListView;
                    var lstBlocked = baseUserControl.FindName("BlockUserList") as ListView;
                    var profilelst = baseControl.FindName("ProfileList") as ListView;
                    profilelst.ItemsSource = null;
                    profilelst.ItemsSource = App.ChainList;
                    if (App.teamuser[0].Is_New)
                    {
                        lst.ItemsSource = null;
                        lst.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.Is_New == true).ToList();
                        lstBlocked.ItemsSource = null;
                        lstBlocked.ItemsSource = App.teamuser.Where(x => x.IsBlocked == true && x.Is_New == true).ToList();
                    }
                    else
                    {
                        lst.ItemsSource = null;
                        lst.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == 1).ToList();
                        lstBlocked.ItemsSource = null;
                        lstBlocked.ItemsSource = App.teamuser.Where(x => x.IsBlocked == true && x.Isleave == false && x.ChainID == 1).ToList();

                    }
                    Load();
                }
                Name_flyout.Hide();
            }
            catch (Exception ex)
            {

            }
        }

        private void btnNameCancel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Name_flyout.Hide();
            }
            catch (Exception ex)
            {

            }
        }

        private void SetLimit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //txtSetlimit.Text = txtLimit.Text + " Users";
                // LimitPopup.IsOpen = false;
                var userlst = App.teamuser.Where(x => x.ChainID == App.selectedChainID).ToList();
                if (IsTextAllowed(txtLimit.Text))
                {
                    if (Convert.ToInt32(txtLimit.Text) <= 30 && Convert.ToInt32(txtLimit.Text) >= userlst.Count)
                    {
                        txtSetlimit.Text = txtLimit.Text + " Users";
                        LimitPopup.IsOpen = false;
                        App.ChainList[0].userLimit = Convert.ToInt32(txtLimit.Text);
                        App.ChainList[0].IsUpdate = true;
                    }
                    if (Convert.ToInt32(txtLimit.Text) < userlst.Count)
                    {
                        if (Message_Bar.Visibility == Visibility.Visible)
                        {
                            Message_Bar.Visibility = Visibility.Collapsed;
                        }
                        string ValidationErrorMessage = "";
                        bool IsError = false;
                        if (true)
                        {
                            ValidationErrorMessage += "User limit Cannot be less than users in chain \n";
                            Message_Bar.HorizontalAlignment = HorizontalAlignment.Center;
                            //Message_Bar.Margin = new Thickness(-100, 4, 0, 0);

                            IsError = true;
                        }
                        if (IsError)
                        {
                            this.SetMessageBarTimeout(Message_Bar, ValidationErrorMessage);
                        }

                    }

                    if (Convert.ToInt32(txtLimit.Text) > 30)
                    {
                        if (Message_Bar.Visibility == Visibility.Visible)
                        {
                            Message_Bar.Visibility = Visibility.Collapsed;
                        }
                        string ValidationErrorMessage = "";
                        bool IsError = false;
                        if (true)
                        {
                            ValidationErrorMessage += "User limit Cannot be greater than 30 \n";
                            Message_Bar.HorizontalAlignment = HorizontalAlignment.Center;
                            //Message_Bar.Margin = new Thickness(-100, 4, 0, 0);

                            IsError = true;
                        }
                        if (IsError)
                        {
                            this.SetMessageBarTimeout(Message_Bar, ValidationErrorMessage);
                        }

                    }
                }
                else
                {

                }


            }
            catch (Exception ex)
            {

            }
        }
        private static readonly Regex _regex = new Regex("[^0-9.-]+"); //regex that matches disallowed text
        private static bool IsTextAllowed(string text)
        {
            return !_regex.IsMatch(text);
        }

        private void btnLimitCancel_Click(object sender, RoutedEventArgs e)
        {
            // Limit_flyout.Hide();
            if (LimitPopup.IsOpen) { LimitPopup.IsOpen = false; }
        }

        //private void chainAdd_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        txtPWD.Text = txtPassword.Text;
        //        Password_flyout.Hide();
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //}

        //private void btnCancel_Click(object sender, RoutedEventArgs e)
        //{
        //    Password_flyout.Hide();
        //}

        private void txtLimit_PreviewKeyDown(object sender, KeyRoutedEventArgs e)
        {

        }

        private void btnLimitArrow_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                txtLimit.Text = "";
                DeleteTeamPopup.IsOpen = false;
                if (!LimitPopup.IsOpen) { LimitPopup.IsOpen = true; }

            }
            catch (Exception ex)
            {

            }
        }

        private void btnDeleteTeam_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var lst = App.ChainList.Where(x => x.ID == App.selectedChainID).ToList();
                lst[0].Is_Deleted = true;
                // lst[0].Is_New = false;

                Grid DaisyChainbaseScreen = (Grid)Parent;
                BoontaEveDaisyChainBaseUserControl HostuserScreen = (BoontaEveDaisyChainBaseUserControl)DaisyChainbaseScreen.FindName("DaisyChainBaseScreen");

                var list = HostuserScreen.FindName("ProfileList") as ListView;
                var ChainCount = HostuserScreen.FindName("ChainCount") as TextBlock;

                bool isNew = App.ChainList[0].Is_New;
                //var newstatus = App.teamuser[2].Status;
                if (isNew)
                {
                    foreach (var item in App.teamuser.Where(x => x.ID == App.loggedInUser).ToList())
                    {
                        if (item.ID == App.loggedInUser)
                        {
                            item.Isleave = false;
                            item.IsHost = false;
                            item.Is_New = false;
                            item.ChainID = 0;
                            item.isMember = false;
                            item.IsUpdate = true;
                        }
                    }
                    var updatedListnew = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false).ToList();
                    // usercount.Text = updatedListnew.Count + " USERS";
                    // var selectedChainnew = App.ChainList.Where(x => x.Name == newstatus).ToList();
                    App.ChainList.Remove(lst[0]);
                    DaisyChainStaticCls.DeleteRecord("tblDaisyChain", Convert.ToInt32(lst[0].ID));
                    //App.ChainList[0].Status = "Connected - " + updatedListnew.Count + " Users";
                    ChainCount.Text = App.ChainList.Count + " CHAINS";
                    list.ItemsSource = null;
                    list.ItemsSource = App.ChainList;
                    //foreach (var item in updatedListnew)
                    //{
                    //    if (item.Name == "User 1 (You)")
                    //    {
                    //        item.Status = "Host - " + App.ChainList[0].Name;
                    //        item.IsHost = true;
                    //    }
                    //    else
                    //    {
                    //        item.Status = App.ChainList[0].Name;
                    //        item.IsHost = false;
                    //    }
                    //}
                    // TeamUserList.ItemsSource = null;
                    // TeamUserList.ItemsSource = updatedListnew;
                }
                else
                {
                    App.ChainList.Remove(lst[0]);
                    DaisyChainStaticCls.DeleteRecord("tblDaisyChain", Convert.ToInt32(lst[0].ID));
                    App.teamuser[0].Isleave = false;
                    App.teamuser[0].IsHost = false;
                    App.teamuser[0].Is_New = false;
                    App.teamuser[0].ChainID = 0;
                    App.teamuser[0].isMember = false;
                    App.teamuser[0].IsUpdate = true;
                    ChainCount.Text = App.ChainList.Count + " CHAINS";
                    list.ItemsSource = null;
                    list.ItemsSource = App.ChainList.Where(x => x.Is_Deleted == false).ToList();
                }
                DeleteTeamPopup.IsOpen = false;
                LimitPopup.IsOpen = false;
                HostuserScreen.Visibility = Visibility.Visible;
                this.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {

            }
        }

        private void btnDeleteTeamCancel_Click(object sender, RoutedEventArgs e)
        {
            DeleteTeamPopup.IsOpen = false;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

            if (!DeleteTeamPopup.IsOpen) { DeleteTeamPopup.IsOpen = true; }
        }

        private void btnNameArrow_Click(object sender, RoutedEventArgs e)
        {
            txtName.Text = "";
            DeleteTeamPopup.IsOpen = false;
            LimitPopup.IsOpen = false;
        }

        private void LimitPopup_Opened(object sender, object e)
        {
            Popup p = (Popup)sender;
            Border sp = (Border)p.Child;
            StackPanel tb = (StackPanel)sp.FindName("StackPanel1");
            TextBox tbs = (TextBox)tb.FindName("txtLimit");
            tbs.Text = string.Empty;
            tbs.Focus(FocusState.Pointer);
        }
        private void txtLimit_BeforeTextChanging(TextBox sender, TextBoxBeforeTextChangingEventArgs args)
        {
            args.Cancel = args.NewText.Any(c => !char.IsDigit(c));
        }
    }
}
