﻿using Microsoft.Toolkit.Extensions;
using MixAmp.BoontaEve.ViewModels;
using MixAmp.Common.UserControls;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Animation;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using static MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.BoontaEve.UserControls.DaisyChain
{
    public sealed partial class DaisyChainHostUserControl : UserControl
    {
        object SelectedItemFromTheList;

        public DaisyChainHostUserControl()
        {
            try
            {
                this.InitializeComponent();
                if (App.teamuser[0].Is_New)
                {
                    TeamUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.Is_New == true && x.ChainID == 1).ToList();
                    var cont = App.teamuser.Where(x => x.IsBlocked == false && x.Is_New == true && x.ChainID == 1).ToList().Count;
                    usercount.Text = cont + " USERS";
                }
                else
                {
                    TeamUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.ChainID == 1).ToList();
                    var cont = App.teamuser.Where(x => x.IsBlocked == false && x.ChainID == 1).ToList().Count;
                    usercount.Text = cont + " USERS";
                }
                this.DataContext = this;
                Size ScreenSize = this.GetScreenResolution();
                double ScreenHeight = this.GetScreenHeight(ScreenSize);
                double ScreenWidth = this.GetScreenWidth(ScreenSize);
                this.SetMaximumListHeight(ScreenHeight);
                BlockUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == true && x.ChainID == 1).ToList();
                setBlockUser(App.selectedChainID);


            }
            catch (Exception ex)
            {

            }
        }
        public void setBlockUser(int chainid)
        {
            try
            {
                if (App.ChainList[0].Is_New)
                {
                    int usercount1 = App.teamuser.Where(x => x.IsBlocked == true && x.Is_New == true && x.ChainID == chainid).ToList().Count;
                    var cnt = App.teamuser.Where(x => x.IsBlocked == false && x.Is_New == true && x.ChainID == chainid).ToList().Count;
                    if (usercount1 > 0)
                    {
                        if (cnt > 1)
                        {
                            blockedusercount.Text = usercount1 + " BLOCKED USERS";
                        }
                        else
                        {
                            blockedusercount.Text = usercount1 + " BLOCKED USER";

                        }
                    }
                    else
                    {
                        blockedusercount.Text = "";
                    }
                    if (cnt > 0)
                    {
                        if (cnt > 1)
                        {
                            usercount.Text = cnt + " USERS";
                        }
                        else
                        {
                            usercount.Text = cnt + " USER";
                        }

                    }
                    else
                    {
                        usercount.Text = "";
                    }

                }
                else
                {
                    int userCount = App.teamuser.Where(x => x.IsBlocked == true && x.ChainID == chainid).ToList().Count;
                    var cnt = App.teamuser.Where(x => x.IsBlocked == false && x.ChainID == chainid).ToList().Count;
                    if (userCount > 0)
                    {
                        if (userCount > 1)
                        {
                            blockedusercount.Text = userCount + " BLOCKED USERS";
                        }
                        else
                        {
                            blockedusercount.Text = userCount + " BLOCKED USER";
                        }

                    }
                    else
                    {
                        blockedusercount.Text = "";
                    }
                    if (cnt > 0)
                    {
                        if (cnt > 1)
                        {
                            usercount.Text = cnt + " USERS";
                        }
                        else
                        {
                            usercount.Text = cnt + " USER";

                        }
                    }
                    else
                    {
                        usercount.Text = "";
                    }
                }


            }
            catch (Exception ex)
            {

            }
        }
        private Size GetScreenResolution()
        {
            var bounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            Size size = new Size(bounds.Width * scaleFactor, bounds.Height * scaleFactor);
            return size;
        }

        private double GetScreenHeight(Size size)
        {
            return size.Height;
        }

        private double GetScreenWidth(Size size)
        {
            return size.Width;
        }

        private void SetMaximumListHeight(double screenHeight)
        {
            if (screenHeight >= 640 && screenHeight < 768)
            {
                double ListHeight = (screenHeight * 0.4);
                TeamUserList.MaxHeight = ListHeight;
            }
            else if (screenHeight >= 768 && screenHeight < 1080)
            {
                double ListHeight = (screenHeight * 0.5);
                TeamUserList.MaxHeight = ListHeight;
            }
            else if (screenHeight >= 1080)
            {
                double ListHeight = (screenHeight * 0.55);
                TeamUserList.MaxHeight = ListHeight;
            }
        }


        private void Navigation_Routing(object sender, RoutedEventArgs e)
        {
            try
            {
                var btn = (Button)sender;
                var selectedUser = ((MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).Name;
                // EnableMenus(btn, selectedUser);
                var mn = btn.FindName("MenuMute") as MenuFlyout;
                var mn1 = btn.FindName("MuteMenuItem") as MenuFlyoutItem;
                var mn2 = btn.FindName("UnMuteMenuItem") as MenuFlyoutItem;
                var blockMenu = btn.FindName("BlockMenuItem") as MenuFlyoutItem;
                var makeHostMenu = btn.FindName("MakehostMenuItem") as MenuFlyoutItem;
                // var ctrl1 = mn1.FindName("ctrlMenutemplet") as ControlTemplate;
                var item = App.teamuser.Where(x => x.Name == selectedUser).ToList();
                var lstuser = App.teamuser.Where(x => x.ChainID == App.selectedChainID).ToList();
                if (item[0].IsMute == true)
                {
                    mn1.Visibility = Visibility.Collapsed;
                    mn2.Visibility = Visibility.Visible;
                }
                if (item[0].IsHost == true)
                {
                    blockMenu.Visibility = Visibility.Collapsed;
                    makeHostMenu.Visibility = Visibility.Collapsed;
                }

                //if (item[0].IsHost == true && lstuser[0].IsHost == true)
                //{
                //    if (item[0].IsMute == true)
                //    {
                //        mn1.Visibility = Visibility.Collapsed;
                //        mn2.Visibility = Visibility.Visible;
                //    }
                //    else
                //    {
                //        mn1.Visibility = Visibility.Visible;
                //        mn2.Visibility = Visibility.Collapsed;

                //    }
                //    if (item[0].IsBlocked == false)
                //    {
                //        blockMenu.Visibility = Visibility.Collapsed;
                //        makeHostMenu.Visibility = Visibility.Collapsed;
                //    }
                //}
                //if (item[0].IsHost == true && lstuser[0].IsHost != true)
                //{
                //    if (item[0].IsMute == true)
                //    {
                //        mn1.Visibility = Visibility.Collapsed;
                //        mn2.Visibility = Visibility.Visible;
                //    }
                //    else
                //    {
                //        mn1.Visibility = Visibility.Visible;
                //        mn2.Visibility = Visibility.Collapsed;

                //    }
                //    if (item[0].IsBlocked == false)
                //    {
                //        blockMenu.Visibility = Visibility.Collapsed;
                //        makeHostMenu.Visibility = Visibility.Collapsed;
                //    }
                //    //blockMenu.Visibility = Visibility.Collapsed;
                //    //makeHostMenu.Visibility = Visibility.Collapsed;
                //    //mn1.Visibility = Visibility.Visible;
                //}
                //if (item[0].IsHost != true && lstuser[0].IsHost == true)
                //{
                //    if (item[0].IsMute == true)
                //    {
                //        mn1.Visibility = Visibility.Collapsed;
                //        mn2.Visibility = Visibility.Visible;
                //    }
                //    else
                //    {
                //        mn1.Visibility = Visibility.Visible;
                //        mn2.Visibility = Visibility.Collapsed;

                //    }
                //    if (item[0].IsBlocked == false)
                //    {
                //        blockMenu.Visibility = Visibility.Collapsed;
                //        makeHostMenu.Visibility = Visibility.Collapsed;
                //    }
                //    //blockMenu.Visibility = Visibility.Visible;
                //    //makeHostMenu.Visibility = Visibility.Visible;
                //    //mn1.Visibility = Visibility.Visible;
                //}
                //if (!item[0].Name.Contains("You") && lstuser[0].IsHost == false)
                //{
                //    if (item[0].IsMute == true)
                //    {
                //        mn1.Visibility = Visibility.Collapsed;
                //        mn2.Visibility = Visibility.Visible;
                //    }
                //    else
                //    {
                //        mn1.Visibility = Visibility.Visible;
                //        mn2.Visibility = Visibility.Collapsed;

                //    }
                //    if (item[0].IsBlocked == false)
                //    {
                //        blockMenu.Visibility = Visibility.Collapsed;
                //        makeHostMenu.Visibility = Visibility.Collapsed;
                //    }
                //    //blockMenu.Visibility = Visibility.Collapsed;
                //    //makeHostMenu.Visibility = Visibility.Collapsed;
                //    //mn1.Visibility = Visibility.Visible;
                //}
                //if (item[0].Name.Contains("You") && lstuser[0].IsHost == false)
                //{
                //    if (item[0].IsMute == true)
                //    {
                //        mn1.Visibility = Visibility.Collapsed;
                //        mn2.Visibility = Visibility.Visible;
                //    }
                //    else
                //    {
                //        mn1.Visibility = Visibility.Visible;
                //        mn2.Visibility = Visibility.Collapsed;

                //    }
                //    if (item[0].IsBlocked == false)
                //    {
                //        blockMenu.Visibility = Visibility.Collapsed;
                //        makeHostMenu.Visibility = Visibility.Collapsed;
                //    }
                //    //blockMenu.Visibility = Visibility.Collapsed;
                //    //makeHostMenu.Visibility = Visibility.Collapsed;
                //    //mn1.Visibility = Visibility.Visible;
                //}
                //if (item[0].Name.Contains("You") && lstuser[0].IsHost == true)
                //{
                //    if (item[0].IsMute == true)
                //    {
                //        mn1.Visibility = Visibility.Collapsed;
                //        mn2.Visibility = Visibility.Visible;
                //    }
                //    else
                //    {
                //        mn1.Visibility = Visibility.Visible;
                //        mn2.Visibility = Visibility.Collapsed;

                //    }
                //    if (item[0].IsBlocked == false)
                //    {
                //        blockMenu.Visibility = Visibility.Collapsed;
                //        makeHostMenu.Visibility = Visibility.Collapsed;
                //    }
                //    //blockMenu.Visibility = Visibility.Collapsed;
                //    //makeHostMenu.Visibility = Visibility.Collapsed;
                //    //mn1.Visibility = Visibility.Visible;
                //}

                // Need to check above commented code 


                //else if (item[0].Name.Contains("You") && item[0].IsHost != true)
                //{
                //    blockMenu.Visibility = Visibility.Visible;
                //    makeHostMenu.Visibility = Visibility.Visible;
                //}
                //else if (!item[0].Name.Contains("You") && item[0].IsHost != true)
                //{
                //    blockMenu.Visibility = Visibility.Visible;
                //    makeHostMenu.Visibility = Visibility.Visible;
                //    mn1.Visibility = Visibility.Visible;
                //}
                //if (item[0].Name.Contains("You") && item[0].IsHost == true)
                //{
                //    blockMenu.Visibility = Visibility.Visible;
                //    makeHostMenu.Visibility = Visibility.Visible;
                //    mn1.Visibility = Visibility.Visible;
                //}

                // var mn3 = mn2.FindName("MuteMenu") as TextBlock;
                var itemSelected1 = ((Windows.UI.Xaml.FrameworkElement)e.OriginalSource).DataContext;

                SelectedItemFromTheList = itemSelected1;
            }
            catch (Exception ex)
            {

            }

        }

        //public void EnableMenus(Button btn, string selectedUser)
        //{
        //    var mn = btn.FindName("MenuMute") as MenuFlyout;
        //    var mn1 = btn.FindName("MuteMenuItem") as MenuFlyoutItem;
        //    var mn2 = btn.FindName("UnMuteMenuItem") as MenuFlyoutItem;
        //    var blockMenu = btn.FindName("BlockMenuItem") as MenuFlyoutItem;
        //    var makeHostMenu = btn.FindName("MakehostMenuItem") as MenuFlyoutItem;
        //    var item = App.teamuser.Where(x => x.Name == selectedUser).ToList();
        //    if (item[0].IsMute == true)
        //    {
        //        mn1.Visibility = Visibility.Collapsed;
        //        mn2.Visibility = Visibility.Visible;
        //    }
        //    if (item[0].IsHost == true)
        //    {
        //        blockMenu.Visibility = Visibility.Collapsed;
        //        makeHostMenu.Visibility = Visibility.Collapsed;
        //    }
        //    //if (App.teamuser[0].IsHost == false)
        //    //{
        //    //    mn1.Visibility = Visibility.Collapsed;
        //    //    mn2.Visibility = Visibility.Collapsed;
        //    //    blockMenu.Visibility = Visibility.Collapsed;
        //    //    makeHostMenu.Visibility = Visibility.Collapsed;
        //    //}
        //    // var mn3 = mn2.FindName("MuteMenu") as TextBlock;

        //}
        private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LeaveChainPopup.IsOpen = false;
                Grid DaisyChainbaseScreen = (Grid)Parent;
                BoontaEveDaisyChainBaseUserControl baseUserControl = (BoontaEveDaisyChainBaseUserControl)DaisyChainbaseScreen.FindName("DaisyChainBaseScreen");
                var lst = baseUserControl.FindName("ProfileList") as ListView;
                // App.ChainList[0].Name = App.teamuser[1].Status;

                lst.ItemsSource = null;
                lst.ItemsSource = App.ChainList;

                if (baseUserControl.Visibility == Visibility.Collapsed)
                {
                    baseUserControl.Visibility = Visibility.Visible;
                    this.Visibility = Visibility.Collapsed;
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void ListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MuteStatus_Click(object sender, RoutedEventArgs e)
        {

        }
        private void ChainStatus_Click(object sender, RoutedEventArgs e)
        {

        }

        private void HostStatus_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnChainSetting_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Grid DaisyChainbaseScreen = (Grid)Parent;
                BoontaEveChangeSettingForHostUserControl ChangeSettingForHostUserControl = (BoontaEveChangeSettingForHostUserControl)DaisyChainbaseScreen.FindName("BoontaEveChangeSettingForHostUserControl");

                if (ChangeSettingForHostUserControl.Visibility == Visibility.Collapsed)
                {
                    ChangeSettingForHostUserControl.Visibility = Visibility.Visible;
                    this.Visibility = Visibility.Collapsed;
                }
                var headerText = ChangeSettingForHostUserControl.FindName("SelectedTeamName") as TextBlock;
                var NameText = ChangeSettingForHostUserControl.FindName("txtTeamName") as TextBlock;
                var LimitText = ChangeSettingForHostUserControl.FindName("txtSetlimit") as TextBlock;
                var unLockStatus = ChangeSettingForHostUserControl.FindName("unLockStatus") as TextBlock;
                var LockStatus = ChangeSettingForHostUserControl.FindName("LockStatus") as TextBlock;
                var grdPWD = ChangeSettingForHostUserControl.FindName("grdPWD") as Grid;
                var btnNameArrow = ChangeSettingForHostUserControl.FindName("btnNameArrow") as Button;
                var btnLimitArrow = ChangeSettingForHostUserControl.FindName("btnLimitArrow") as Button;
                var MicLevels = ChangeSettingForHostUserControl.FindName("MicLevels") as ToggleSwitch;
                var btnDelete = ChangeSettingForHostUserControl.FindName("btnDelete") as Button;

                if (App.teamuser[0].IsHost)
                {
                    btnNameArrow.Visibility = Visibility.Visible;
                    btnLimitArrow.Visibility = Visibility.Visible;
                    MicLevels.Visibility = Visibility.Visible;
                    btnDelete.Visibility = Visibility.Visible;
                    if (App.ChainList[0].isLocked_)
                    {
                        unLockStatus.Visibility = Visibility.Collapsed;
                        LockStatus.Visibility = Visibility.Visible;
                        grdPWD.Visibility = Visibility.Visible;
                        MicLevels.IsOn = true;
                    }
                }
                else
                {
                    btnNameArrow.Visibility = Visibility.Collapsed;
                    btnLimitArrow.Visibility = Visibility.Collapsed;
                    MicLevels.Visibility = Visibility.Collapsed;
                    btnDelete.Visibility = Visibility.Collapsed;
                    grdPWD.Visibility = Visibility.Collapsed;
                }

                if (App.teamuser[0].Is_New)
                {
                    //int count = App.teamuser.Where(x => x.Is_New == true).ToList().Count;

                    //if (count == 1)
                    //{
                    //    LimitText.Text = count + " User";
                    //}
                    //else
                    //{
                    //    LimitText.Text = count + " Users";
                    //}
                    //if (App.teamuser[0].Status.Contains("Host"))
                    //{
                    //    var str = App.teamuser[0].Status.Split("-");
                    //    headerText.Text = str[1].Trim();
                    //    NameText.Text = str[1].Trim();
                    //}
                    //else
                    //{
                    headerText.Text = App.ChainList[0].Name;
                    NameText.Text = App.ChainList[0].Name;
                    // }
                    LimitText.Text = App.ChainList[0].userLimit + " Users";
                    LoadNew(ChangeSettingForHostUserControl);
                }
                else
                {
                    headerText.Text = App.ChainList[0].Name;
                    NameText.Text = App.ChainList[0].Name;
                    var selectedChain = App.ChainList.Where(x => x.Is_Selected == true).FirstOrDefault();
                    //  int count = App.teamuser.Where(x=>x.Isleave==false && x.ChainID== selectedChain.ID).ToList().Count;
                    // LimitText.Text = count + " Users";
                    LimitText.Text = App.ChainList[0].userLimit + " Users";
                    Load(ChangeSettingForHostUserControl);
                }
            }
            catch (Exception ex)
            {

            }
        }
        private void LoadNew(BoontaEveChangeSettingForHostUserControl ChangeSettingForHostUserControl)
        {

            StackPanel usercontrol = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(160, 120, 10, 10),
                HorizontalAlignment = HorizontalAlignment.Left,
                //Width = size.Width - 150,
                //Height = size.Height - 100
            };
            var scrl = ChangeSettingForHostUserControl.FindName("ScrUsercontrol") as ScrollViewer;
            scrl.Content = usercontrol;
            DaisyChainSourceUserControl uc;
            string selectedinput = string.Empty;
            //var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
            //foreach (var item in lists)
            //{
            //    selectedinput = item.InputDevicename;
            //}
            Dictionary<string, string> inputdevice = new Dictionary<string, string>();
            foreach (var item in App.teamuser.Where(x => x.Is_New == true))
            {
                inputdevice.Add(item.Name, item.Status);
            }
            //inputdevice.Add("User1", "Team Red");
            //inputdevice.Add("User2", "Team Red");
            //inputdevice.Add("User3", "Team Red");
            //inputdevice.Add("User4", "Team Red");
            foreach (var device in inputdevice)
            {
                int Volume = App.teamuser.Where(x => x.Name == device.Key).FirstOrDefault().Volume;

                uc = new DaisyChainSourceUserControl();
                //if (selectedinput == device.Key)
                //{
                //    this.InitializeComponent();
                //}
                var text = uc.FindName("txt1") as TextBlock;
                var text1 = uc.FindName("txt2") as TextBlock;
                var playbutton = uc.FindName("ison") as TextBlock;
                var selectedbutton = uc.FindName("btntop") as Button;
                var selectedImage = (uc.FindName("selectedcontrol") as Image);
                var speeker = uc.FindName("btnspeaker") as Button;
                var slidr = uc.FindName("Slider4") as Slider;

                speeker.Width = 55;
                var spk = speeker.FindName("stkspeker") as StackPanel;
                spk.Width = 55;
                var spkimg = spk.FindName("speaker") as Image;
                var muteimg = spk.FindName("Mute") as Image;
                muteimg.Margin = new Thickness(20, 0, 0, 0);
                spkimg.Margin = new Thickness(25, 0, 0, 0);
                spk.HorizontalAlignment = HorizontalAlignment.Center;
                (uc.FindName("routingplaybutton") as RadioButton).Visibility = Visibility.Collapsed; ;
                // routingplaybutton.Visibility = Visibility.Collapsed;
                text.Text = device.Key;
                slidr.Value = Volume;
                var strLengh = device.Value.Length;
                var strText = (strLengh < 9) ? device.Value : device.Value.Truncate(9) + "...";
                text1.Text = strText;
                playbutton.Text = "Selected";
                selectedImage.Source = new BitmapImage(new Uri("ms-appx:///BoontaEve/Assets/Chain.png")); ;

                usercontrol.Children.Add(uc);

            }


        }
        private void Load(BoontaEveChangeSettingForHostUserControl ChangeSettingForHostUserControl)
        {

            StackPanel usercontrol = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(160, 120, 10, 10),
                HorizontalAlignment = HorizontalAlignment.Left,
                //Width = size.Width - 150,
                //Height = size.Height - 100
            };
            var scrl = ChangeSettingForHostUserControl.FindName("ScrUsercontrol") as ScrollViewer;
            scrl.Content = usercontrol;
            DaisyChainSourceUserControl uc;
            string selectedinput = string.Empty;
            //var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
            //foreach (var item in lists)
            //{
            //    selectedinput = item.InputDevicename;
            //}
            Dictionary<string, string> inputdevice = new Dictionary<string, string>();
            var selectedChain = App.ChainList.Where(x => x.Is_Selected == true).FirstOrDefault();
            foreach (var item in App.teamuser.Where(x => x.Isleave == false && x.ChainID == App.selectedChainID))
            {
                inputdevice.Add(item.Name, item.Status);
            }
            //inputdevice.Add("User1", "Team Red");
            //inputdevice.Add("User2", "Team Red");
            //inputdevice.Add("User3", "Team Red");
            //inputdevice.Add("User4", "Team Red");
            foreach (var device in inputdevice)
            {
                int Volume = App.teamuser.Where(x => x.Name == device.Key).FirstOrDefault().Volume;

                uc = new DaisyChainSourceUserControl();
                //if (selectedinput == device.Key)
                //{
                //    this.InitializeComponent();
                //}
                var text = uc.FindName("txt1") as TextBlock;
                var text1 = uc.FindName("txt2") as TextBlock;
                var playbutton = uc.FindName("ison") as TextBlock;
                var selectedbutton = uc.FindName("btntop") as Button;
                var selectedImage = (uc.FindName("selectedcontrol") as Image);
                var speeker = uc.FindName("btnspeaker") as Button;
                var slidr = uc.FindName("Slider4") as Slider;
                speeker.Width = 55;
                var spk = speeker.FindName("stkspeker") as StackPanel;
                spk.Width = 55;
                var spkimg = spk.FindName("speaker") as Image;
                var muteimg = spk.FindName("Mute") as Image;
                muteimg.Margin = new Thickness(20, 0, 0, 0);
                spkimg.Margin = new Thickness(25, 0, 0, 0);
                spk.HorizontalAlignment = HorizontalAlignment.Center;
                (uc.FindName("routingplaybutton") as RadioButton).Visibility = Visibility.Collapsed;
                // routingplaybutton.Visibility = Visibility.Collapsed;
                text.Text = device.Key;
                slidr.Value = Volume;
                var strLengh = device.Value.Length;
                var strText = (strLengh < 9) ? device.Value : device.Value.Truncate(9) + "...";
                text1.Text = strText;
                playbutton.Text = "Selected";
                selectedImage.Source = new BitmapImage(new Uri("ms-appx:///BoontaEve/Assets/Chain.png"));

                usercontrol.Children.Add(uc);

            }


        }
        private void btnLeave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!LeaveChainPopup.IsOpen) { LeaveChainPopup.IsOpen = true; }

            }
            catch (Exception ex)
            {

            }

        }

        private void LeaveChain_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool isNew = App.ChainList.Where(x => x.ID == App.selectedChainID).FirstOrDefault().Is_New;
                Grid DaisyChainbaseScreen = (Grid)Parent;
                BoontaEveDaisyChainBaseUserControl HostuserScreen = (BoontaEveDaisyChainBaseUserControl)DaisyChainbaseScreen.FindName("DaisyChainBaseScreen");

                var list = HostuserScreen.FindName("ProfileList") as ListView;

                var chainCount = HostuserScreen.FindName("ChainCount") as TextBlock;
                var newuser = App.teamuser.Where(x => x.IsBlocked == false && x.ChainID == App.selectedChainID).ToList();
                var newstatus = App.teamuser[2].Status;
                if (isNew)
                {
                    // newuser = App.teamuser.Where(x => x.IsBlocked == false && x.Is_New == true && x.ChainID == App.selectedChainID).ToList();
                    foreach (var item in App.teamuser.Where(x => x.ID == App.loggedInUser).ToList())
                    {
                        if (item.ID == App.loggedInUser)
                        {
                            item.Isleave = false;
                            item.IsHost = false;
                            item.Is_New = false;
                            item.isMember = false;
                            item.IsUpdate = true;
                        }
                    }
                    var updatedListnew = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                    var updatedListnew1 = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == App.ChainList[1].ID).ToList();

                    usercount.Text = updatedListnew1.Count + " USERS";
                    var selectedChainnew = App.ChainList.Where(x => x.ID == App.selectedChainID).ToList();                    
                    DaisyChainStaticCls.DeleteRecord("tblDaisyChain", Convert.ToInt32(selectedChainnew[0].ID));
                    App.ChainList.Remove(selectedChainnew[0]);
                    App.ChainList[0].Status = "Connected - " + updatedListnew1.Count + " Users";
                    chainCount.Text = App.ChainList.Count + " CHAINS";
                    list.ItemsSource = null;
                    list.ItemsSource = App.ChainList;
                    foreach (var item in updatedListnew)
                    {
                        if (item.ID == App.loggedInUser)
                        {
                            item.Status = "Host - " + App.ChainList[0].Name;
                            item.Isleave = true;
                            item.IsHost = false;
                            item.ChainID = 0;
                            item.Status = newstatus;
                            item.IsUpdate = true;
                        }
                        else
                        {
                            item.Status = App.ChainList[0].Name;
                            item.IsHost = false;
                            item.IsUpdate = true;
                        }
                    }
                    TeamUserList.ItemsSource = null;
                    TeamUserList.ItemsSource = updatedListnew;
                    LeaveChainPopup.IsOpen = false;
                }
                else
                {
                    foreach (var item in newuser)
                    {
                        if (item.Name == newuser[1].Name)
                        {
                            item.Status = "Host - " + newstatus;
                            item.IsHost = true;
                            item.IsUpdate = true;
                        }

                        if (item.ID == App.loggedInUser)
                        {
                            item.Isleave = true;
                            item.IsHost = false;
                            item.ChainID = 0;
                            item.isMember = false;
                            item.Status = newstatus;
                            item.IsUpdate = true;
                        }
                    }
                    var updatedList = newuser.Where(x => x.IsBlocked == false && x.Isleave == false).ToList();
                    TeamUserList.ItemsSource = null;
                    TeamUserList.ItemsSource = updatedList;
                    usercount.Text = updatedList.Count + " USERS";
                    var selectedChain = App.ChainList.Where(x => x.ID == App.selectedChainID).ToList();
                    selectedChain[0].Status = "Connected - " + updatedList.Count + " Users";
                    selectedChain[0].IsUpdate = true;
                    if (updatedList.Count == 0)
                    {
                        App.ChainList.Remove(selectedChain[0]);
                    }
                    list.ItemsSource = null;
                    list.ItemsSource = App.ChainList;
                    chainCount.Text = App.ChainList.Count + " CHAINS";
                    LeaveChainPopup.IsOpen = false;
                }
                
                HostuserScreen.Visibility = Visibility.Visible;
                this.Visibility = Visibility.Collapsed;
                

            }
            catch (Exception ex)
            {

            }
        }

        private void ChainCancel_Click(object sender, RoutedEventArgs e)
        {
            if (LeaveChainPopup.IsOpen) { LeaveChainPopup.IsOpen = false; }
        }

        private void MuteMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                var selectedUser = ((MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).Name;
                var selectedUserStatus = ((MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).Status;
                ListView ListView = TeamUserList as ListView;

                foreach (var item in ListView.Items)
                {
                    var ListViewItem = (ListViewItem)ListView.ContainerFromItem(item) as ListViewItem;
                    var itemGrid = (Grid)ListViewItem.ContentTemplateRoot as Grid;
                    var name = itemGrid.FindName("NameTextBlock") as TextBlock;
                    var newuser = App.teamuser.Where(x => x.IsBlocked == true && x.ChainID == App.selectedChainID).ToList();
                    var removedata = newuser.Where(x => x.Name == name.Text).ToList();
                    foreach (var item1 in App.teamuser.Where(x => x.ChainID == App.selectedChainID).ToList())
                    {
                        if (item1.Name == selectedUser)
                        {
                            if (item1.IsMute)
                            {
                                if (selectedUserStatus.Contains("Muted"))
                                {
                                    selectedUserStatus = selectedUserStatus.Replace(" - Muted", "");
                                    item1.IsMute = false;
                                    item1.Status = selectedUserStatus;
                                    item1.IsUpdate = true;
                                }
                                else
                                {
                                    item1.IsMute = false;
                                    item1.Status = selectedUserStatus;
                                    item1.IsUpdate = true;
                                }

                            }
                            else
                            {
                                item1.IsMute = true;
                                item1.Status = selectedUserStatus + " - Muted";
                                item1.IsUpdate = true;
                            }

                        }
                    }
                    if (App.ChainList[0].Is_New)
                    {
                        TeamUserList.ItemsSource = null;
                        TeamUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.Is_New == true && x.ChainID == App.selectedChainID).ToList();
                    }
                    else
                    {
                        TeamUserList.ItemsSource = null;
                        TeamUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                    }
                    break;
                }



            }
            catch (Exception ex)
            {

            }
        }

        private void BlockMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedUser = ((MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).Name;

                ListView ListView = TeamUserList as ListView;

                foreach (var item in ListView.Items)
                {
                    var ListViewItem = (ListViewItem)ListView.ContainerFromItem(item) as ListViewItem;
                    var itemGrid = (Grid)ListViewItem.ContentTemplateRoot as Grid;
                    var name = itemGrid.FindName("NameTextBlock") as TextBlock;
                    var newuser = App.teamuser.Where(x => x.IsBlocked == true && x.ChainID == App.selectedChainID).ToList();
                    var removedata = newuser.Where(x => x.Name == name.Text).ToList();
                    foreach (var item1 in App.teamuser.Where(x => x.ChainID == App.selectedChainID).ToList())
                    {
                        if (item1.Name == selectedUser)
                        {
                            item1.IsBlocked = true;
                            item1.IsUpdate = true;
                        }
                    }
                    if (App.ChainList[0].Is_New)
                    {
                        BlockUserList.ItemsSource = null;
                        BlockUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == true && x.Isleave == false && x.Is_New == true && x.ChainID == App.selectedChainID).ToList();
                        TeamUserList.ItemsSource = null;
                        TeamUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.Is_New == true && x.ChainID == App.selectedChainID).ToList();
                        setBlockUser(App.selectedChainID);
                    }
                    else
                    {
                        BlockUserList.ItemsSource = null;
                        BlockUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == true && x.Isleave == false && x.ChainID == App.selectedChainID).ToList(); ;
                        TeamUserList.ItemsSource = null;
                        TeamUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                        setBlockUser(App.selectedChainID);
                    }

                    break;
                }


            }
            catch (Exception ex)
            {

            }
        }

        private void MakehostMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedUser = ((MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).Name;
                var selectedUserStatus = ((MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).Status;

                ListView ListView = TeamUserList as ListView;
                foreach (var item in ListView.Items)
                {
                    var ListViewItem = (ListViewItem)ListView.ContainerFromItem(item) as ListViewItem;
                    var itemGrid = (Grid)ListViewItem.ContentTemplateRoot as Grid;
                    var name = itemGrid.FindName("NameTextBlock") as TextBlock;
                    var newuser = App.teamuser.Where(x => x.IsBlocked == true && x.ChainID == App.selectedChainID).ToList();
                    var previoushostuser = App.teamuser.Where(x => x.IsHost == true && x.ChainID == App.selectedChainID).Select(y => y.Name.ToString());
                    bool changedhost = false;
                    var removedata = newuser.Where(x => x.Name == name.Text).ToList();
                    foreach (var item1 in App.teamuser)
                    {
                        if (item1.Name == selectedUser)
                        {
                            item1.IsHost = true;
                            item1.IsMute = false;
                            item1.Status = "Host - " + selectedUserStatus;
                            item1.IsUpdate = true;
                        }
                        else
                        {
                            item1.IsHost = false;
                            item1.Status = selectedUserStatus;
                            item1.IsUpdate = true;
                        }
                        //if (item1.Name == previoushostuser.FirstOrDefault().ToString() && changedhost == false)
                        //{
                        //    item1.IsHost = false;
                        //    item1.IsMute = false;
                        //    item1.Status = selectedUserStatus;//CapitalizeFirst(txtTeamHeader.Text);
                        //    changedhost = true;
                        //    //break;	
                        //}
                    }
                    if (App.ChainList[0].Is_New)
                    {
                        TeamUserList.ItemsSource = null;
                        TeamUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.Is_New == true && x.ChainID == App.selectedChainID).ToList();
                    }
                    else
                    {
                        TeamUserList.ItemsSource = null;
                        TeamUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                    }
                    if (Message_Bar.Visibility == Visibility.Visible)
                    {
                        Message_Bar.Visibility = Visibility.Collapsed;
                    }
                    string ValidationErrorMessage = "";
                    bool IsError = false;
                    if (true)
                    {

                        var messagestring = CultureInfo.InvariantCulture.TextInfo.ToTitleCase(txtTeamHeader.Text.ToLower());
                        ValidationErrorMessage += "You made " + selectedUser + " host of " + messagestring;
                        IsError = true;
                    }
                    if (IsError)
                    {
                        this.SetMessageBarTimeout(Message_Bar, ValidationErrorMessage);
                    }
                    break;
                }


            }
            catch (Exception ex)
            {

            }
        }
        public string CapitalizeFirst(string s)
        {
            bool IsNewSentense = true;
            var result = new StringBuilder(s.Length);
            for (int i = 0; i < s.Length; i++)
            {
                if (IsNewSentense && char.IsLetter(s[i]))
                {
                    result.Append(char.ToUpper(s[i]));
                    IsNewSentense = false;
                }
                else
                    result.Append(s[i]);
                if (s[i] == '!' || s[i] == '?' || s[i] == '.')
                {
                    IsNewSentense = true;
                }
            }
            return result.ToString();
        }

        private async void SetMessageBarTimeout(MessageBar MessageBar, string ValidationErrorMessage)
        {
            this.ShowValidationErrorMessage(MessageBar, ValidationErrorMessage);
            await Task.Delay(3000);
            this.HideValidationErrorMessage(MessageBar);
        }
        private void ShowValidationErrorMessage(MessageBar MessageBar, string ValidationErrorMessage)
        {
            if (MessageBar.Visibility == Visibility.Collapsed)
            {
                TextBlock Message_Text_Box = (TextBlock)MessageBar.FindName("Message_Text");
                //Message_Text_Box.VerticalAlignment = (VerticalAlignment)AlignmentY.Center;
                Message_Text_Box.Text = ValidationErrorMessage;
                Message_Text_Box.Margin = new Thickness(5, 10, 0, 0);

                MessageBar.Visibility = Visibility.Visible;
            }
        }
        private void HideValidationErrorMessage(MessageBar MessageBar)
        {
            if (MessageBar.Visibility == Visibility.Visible)
            {
                MessageBar.Visibility = Visibility.Collapsed;
            }
        }
        private void UnblockMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var selectedUser = ((MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).Name;

                ListView ListView = BlockUserList as ListView;
                foreach (var item in ListView.Items)
                {
                    var ListViewItem = (ListViewItem)ListView.ContainerFromItem(item) as ListViewItem;
                    var itemGrid = (Grid)ListViewItem.ContentTemplateRoot as Grid;
                    var name = itemGrid.FindName("NameTextUnBlock") as TextBlock;
                    var newuser = App.teamuser.Where(x => x.IsBlocked == true && x.ChainID == App.selectedChainID).ToList();
                    var removedata = newuser.Where(x => x.Name == name.Text).ToList();
                    foreach (var item1 in App.teamuser)
                    {
                        if (item1.Name == selectedUser)
                        {
                            item1.IsBlocked = false;
                            item1.IsUpdate = true;
                        }
                    }
                    if (App.ChainList[0].Is_New)
                    {
                        BlockUserList.ItemsSource = null;
                        BlockUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == true && x.Isleave == false && x.Is_New == true && x.ChainID == App.selectedChainID).ToList(); ;
                        TeamUserList.ItemsSource = null;
                        TeamUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.Is_New == true && x.ChainID == App.selectedChainID).ToList();
                        setBlockUser(App.selectedChainID);
                    }
                    else
                    {
                        BlockUserList.ItemsSource = null;
                        BlockUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == true && x.Isleave == false && x.ChainID == App.selectedChainID).ToList(); ;
                        TeamUserList.ItemsSource = null;
                        TeamUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                        setBlockUser(App.selectedChainID);
                    }
                    break;
                }

            }
            catch (Exception ex)
            {

            }
        }

        private void btnJoinChain_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Grid DaisyChainbaseScreen = (Grid)Parent;
                BoontaEveDaisyChainBaseUserControl HostuserScreen = (BoontaEveDaisyChainBaseUserControl)DaisyChainbaseScreen.FindName("DaisyChainBaseScreen");
                int usercount = App.teamuser.Where(x => x.ID == App.loggedInUser && x.isMember == true).ToList().Count;
                if (usercount > 0)
                {
                    if (Message_Bar.Visibility == Visibility.Visible)
                    {
                        Message_Bar.Visibility = Visibility.Collapsed;
                    }

                    string ValidationErrorMessage = "";
                    bool IsError = false;
                    if (true)
                    {
                        //ValidationErrorMessage += "Already a member of another chain. "+"\r\n"+ " Please leave the connected chain to" + "\r\n" + " join new chain";
                        ValidationErrorMessage += "Already a member of another chain. Please leave the connected chain to join new chain";

                        IsError = true;
                    }
                    if (IsError)
                    {
                        // Message_Bar.Height = 100;
                        this.SetMessageBarTimeout(Message_Bar, ValidationErrorMessage);
                    }
                    return;
                }

                var userdetail = App.teamuser.Where(x => x.ID == App.loggedInUser).FirstOrDefault();
                userdetail.ChainID = App.selectedChainID;
                userdetail.Isleave = false;
                userdetail.isMember = true;
                userdetail.IsHost = false;
                userdetail.IsUpdate = true;
                //foreach (var item in App.teamuser.Where(x => x.Isleave == true && x.IsBlocked == false && x.ChainID == App.selectedChainID).ToList())
                //{
                //    item.Status = "Host - " + App.teamuser[2].Status;
                //    item.Isleave = false;
                //    item.IsHost = true;
                //    item.IsUpdate = true;

                //}
                //foreach (var item in App.teamuser.Where(x => x.Isleave == false && x.IsBlocked == false && x.ChainID == App.selectedChainID).ToList())
                //{
                //    if (item.Name == "User 2")
                //    {
                //        item.Status = App.teamuser[2].Status;
                //        item.IsHost = false;
                //        item.IsUpdate = true;
                //    }
                //}
                foreach (var item in App.teamuser.Where(x => x.ChainID == App.selectedChainID))
                {
                    item.ArrowOptionVisible = Visibility.Visible;
                }
                var list = HostuserScreen.FindName("ProfileList") as ListView;
                var updatedList = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
               // var selectedChain = App.ChainList.Where(x => x.Name == App.teamuser[2].Status).ToList();
                var selectedChain = App.ChainList.Where(x => x.ID == App.selectedChainID).ToList();
                selectedChain[0].Status = "Connected - " + updatedList.Count + " Users";
                selectedChain[0].IsUpdate = true;
                list.ItemsSource = null;
                list.ItemsSource = App.ChainList;

                var lst = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                TeamUserList.ItemsSource = null;
                TeamUserList.ItemsSource = lst;
                BlockUserList.ItemsSource = null;
                BlockUserList.ItemsSource = App.teamuser.Where(x => x.IsBlocked == true && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                setBlockUser(App.selectedChainID);
                btnLeave.Visibility = Visibility.Visible;
                reltChainsetting.Visibility = Visibility.Visible;
                btnJoinChain.Visibility = Visibility.Collapsed;
                //HostuserScreen.Visibility = Visibility.Visible;
                //this.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {

            }
        }
    }
}
