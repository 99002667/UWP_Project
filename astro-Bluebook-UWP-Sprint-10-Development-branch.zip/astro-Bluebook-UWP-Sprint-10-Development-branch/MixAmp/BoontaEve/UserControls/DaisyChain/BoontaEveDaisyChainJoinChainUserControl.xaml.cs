﻿using MixAmp.BoontaEve.ViewModels;
using MixAmp.Common.UserControls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using static MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.BoontaEve.UserControls.DaisyChain
{
    public sealed partial class BoontaEveDaisyChainJoinChainUserControl : UserControl
    {
        public BoontaEveDaisyChainJoinChainUserControl()
        {         
            try
            {
                this.InitializeComponent();
               
                this.DataContext = this;
                Size ScreenSize = this.GetScreenResolution();
                double ScreenHeight = this.GetScreenHeight(ScreenSize);
                double ScreenWidth = this.GetScreenWidth(ScreenSize);
                this.SetMaximumListHeight(ScreenHeight);               
                TeamUserList.ItemsSource = App.NewChainList;
                TotalUser();
            }
            catch (Exception ex)
            {
            }

        }
        public void TotalUser()
        {
            try
            {
                int usercount = App.NewChainList.Count;
                if (usercount > 0)
                {
                    txtUserCount.Text = usercount + " USERS";
                }
                else
                {
                    txtUserCount.Text = "";
                }
            }
            catch (Exception ex)
            {

            }
        }
        private Size GetScreenResolution()
        {
            var bounds = ApplicationView.GetForCurrentView().VisibleBounds;
            var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
            Size size = new Size(bounds.Width * scaleFactor, bounds.Height * scaleFactor);
            return size;
        }

        private double GetScreenHeight(Size size)
        {
            return size.Height;
        }

        private double GetScreenWidth(Size size)
        {
            return size.Width;
        }

        private void SetMaximumListHeight(double screenHeight)
        {
            if (screenHeight >= 640 && screenHeight < 768)
            {
                double ListHeight = (screenHeight * 0.4);
                TeamUserList.MaxHeight = ListHeight;
            }
            else if (screenHeight >= 768 && screenHeight < 1080)
            {
                double ListHeight = (screenHeight * 0.5);
                TeamUserList.MaxHeight = ListHeight;
            }
            else if (screenHeight >= 1080)
            {
                double ListHeight = (screenHeight * 0.55);
                TeamUserList.MaxHeight = ListHeight;
            }
        }

        private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Grid DaisyChainbaseScreen = (Grid)Parent;
                BoontaEveDaisyChainBaseUserControl baseUserControl = (BoontaEveDaisyChainBaseUserControl)DaisyChainbaseScreen.FindName("DaisyChainBaseScreen");

                if (baseUserControl.Visibility == Visibility.Collapsed)
                {
                    baseUserControl.Visibility = Visibility.Visible;
                    this.Visibility = Visibility.Collapsed;
                }
            }
            catch (Exception ex)
            {

            }
        }

       

        private void btnJoinChain_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                foreach (var item in App.NewChainList)
                {
                    if (item.Name.Contains("You"))
                    {
                        return;
                    }
                }
                var newuser = App.NewChainList;
                int chaincount = (Convert.ToInt32(App.NewChainList.Count) + 1);
                var addnewitem = new DaisyChainHostUserViewModel()
                {
                   
                    Name = "User "+ chaincount + " (You)",
                    Status = App.NewChainList[2].Status,
                    IsBlocked = false, 
                   IsMute = false, 
                   IsHost=false, 
                   Isleave=false, 
                   Is_Selected=false, 
                     FortyEightV_Visibility=Visibility.Collapsed, 
                     SideBorderVisibility=Visibility.Collapsed, 
                     TextColor=new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)),
                     Is_New=false, 
                     Is_Duplicate=false,
                     MuteVisible=Visibility.Collapsed,

                };
                App.NewChainList.Add(addnewitem);
                                                
                TeamUserList.ItemsSource = null;
                TeamUserList.ItemsSource = App.NewChainList;
                TotalUser();
                
                foreach (var item in App.NonHostUsers.Where(x => x.Isleave == true).ToList())
                {
                    item.Isleave = false;
                }

                if (Message_Bar.Visibility == Visibility.Visible)
                {
                    Message_Bar.Visibility = Visibility.Collapsed;
                }
                string ValidationErrorMessage = "";
                bool IsError = false;
                if (true)
                {
                    ValidationErrorMessage += "Join Chain\n";
                    IsError = true;
                }
                if (IsError)
                {
                   // this.SetMessageBarTimeout(Message_Bar, ValidationErrorMessage);
                }

            }
            catch (Exception ex)
            {

            }
        }


        private MessageBar GetMessageBar()
        {
            RelativePanel LoginBaseScreenRelativePanel = (RelativePanel)Parent;
            Grid LoginBaseScreenRelativePanelParent = (Grid)LoginBaseScreenRelativePanel.Parent;
            MessageBar MessageBar = (MessageBar)LoginBaseScreenRelativePanelParent.FindName("Message_Bar");
            return MessageBar;
        }

        private async void SetMessageBarTimeout(MessageBar MessageBar, string ValidationErrorMessage)
        {
            this.ShowValidationErrorMessage(MessageBar, ValidationErrorMessage);
            await Task.Delay(3000);
            this.HideValidationErrorMessage(MessageBar);
        }
        private void ShowValidationErrorMessage(MessageBar MessageBar, string ValidationErrorMessage)
        {
            if (MessageBar.Visibility == Visibility.Collapsed)
            {
                TextBlock Message_Text_Box = (TextBlock)MessageBar.FindName("Message_Text");
                Message_Text_Box.VerticalAlignment = (VerticalAlignment)AlignmentY.Center;
                Message_Text_Box.Text = ValidationErrorMessage;
                MessageBar.Visibility = Visibility.Visible;
            }
        }

        private void HideValidationErrorMessage(MessageBar MessageBar)
        {
            if (MessageBar.Visibility == Visibility.Visible)
            {
                MessageBar.Visibility = Visibility.Collapsed;
            }
        }

    }
}
