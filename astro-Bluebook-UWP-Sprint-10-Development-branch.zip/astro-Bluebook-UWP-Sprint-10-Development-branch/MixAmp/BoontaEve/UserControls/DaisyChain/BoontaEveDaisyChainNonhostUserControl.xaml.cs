﻿using Microsoft.Toolkit.Extensions;
using MixAmp.Common.UserControls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;
using static MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.BoontaEve.UserControls.DaisyChain
{
    public sealed partial class BoontaEveDaisyChainNonhostUserControl : UserControl
    {
        public BoontaEveDaisyChainNonhostUserControl()
        {
            this.InitializeComponent();
            UserList.ItemsSource = App.teamuser.Where(x => x.Isleave == false && x.ChainID==2).ToList(); 
            TotalUser(2);
        }
        public void TotalUser(int chainid)
        {
            try
            {
                int usercount = App.teamuser.Where(x => x.Isleave == false && x.ChainID == chainid).ToList().Count;               
               
                if (usercount > 0)
                {
                    txtUserCountNonHost.Text = usercount + " USERS";
                }
                else
                {
                    txtUserCountNonHost.Text = "";
                }
            }
            catch (Exception ex)
            {

            }
        }
              
        private void ArrowSettings_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Grid DaisyChainNonHostUserControl = (Grid)Parent;
                BoontaEveNonhostChangeSetting NonhostChangeSetting = (BoontaEveNonhostChangeSetting)DaisyChainNonHostUserControl.FindName("BoontaEveNonhostChangeSetting");
                var headerText = NonhostChangeSetting.FindName("SelectedTeamName") as TextBlock;
                var UserList = NonhostChangeSetting.FindName("UserList") as ListView;
                var chain = App.ChainList.Where(x => x.ID == App.selectedChainID).FirstOrDefault();
                headerText.Text= chain.Name; 
                App.NonHostList[0].Status = chain.Name;
                App.NonHostList[1].Status = chain.userLimit+" Users";
                UserList.ItemsSource = null;
                UserList.ItemsSource = App.NonHostList;
                if (NonhostChangeSetting.Visibility == Visibility.Collapsed)
                {
                    NonhostChangeSetting.Visibility = Visibility.Visible;
                    this.Visibility = Visibility.Collapsed;
                    Load(NonhostChangeSetting);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void leftArrow_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LeaveChainPopup.IsOpen = false;
                Grid DaisyChainbaseScreen = (Grid)Parent;
                BoontaEveDaisyChainBaseUserControl baseUserControl = (BoontaEveDaisyChainBaseUserControl)DaisyChainbaseScreen.FindName("DaisyChainBaseScreen");

                if (baseUserControl.Visibility == Visibility.Collapsed)
                {
                    baseUserControl.Visibility = Visibility.Visible;
                    this.Visibility = Visibility.Collapsed;
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MuteMenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                var SelectedUser = ((MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).Name;
                var selectedUserStatus= ((MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).Status;

                ListView ListView = UserList as ListView;
                foreach (var item in ListView.Items)
                {
                    var ListViewItem = (ListViewItem)ListView.ContainerFromItem(item) as ListViewItem;
                    var itemGrid = (Grid)ListViewItem.ContentTemplateRoot as Grid;
                    var name = itemGrid.FindName("txtUserName") as TextBlock;
                   // var newuser = App.NonHostUsers.Where(x => x.IsBlocked == true).ToList();
                   // var removedata = newuser.Where(x => x.Name == name.Text).ToList();
                    foreach (var item1 in App.teamuser.Where(x=>x.ChainID==2).ToList())
                    {
                        if (item1.Name == SelectedUser)
                        {
                            if (item1.IsMute)
                            {
                                if (selectedUserStatus.Contains("Muted"))
                                {
                                    selectedUserStatus = selectedUserStatus.Replace(" - Muted", "");
                                    item1.IsMute = false;
                                    item1.Status = selectedUserStatus;
                                }
                                else
                                {
                                    item1.IsMute = false;
                                    item1.Status = selectedUserStatus;
                                }

                            }
                            else
                            {
                                item1.IsMute = true;
                                item1.Status = selectedUserStatus + " - Muted";
                            }
                        //    if (item1.Name == SelectedUser)
                        //{
                        //    if (item1.IsMute)
                        //    {
                        //        item1.IsMute = false;
                        //        item1.Status = txtTeamHeader.Text;
                        //    }
                        //    else
                        //    {
                        //        item1.IsMute = true;
                        //        item1.Status = txtTeamHeader.Text + " - Muted";
                        //    }

                        }
                    }
                    UserList.ItemsSource = null;
                    UserList.ItemsSource = App.NonHostUsers.Where(x=>x.Isleave == false).ToList();
                    break;
                }


            }
            catch (Exception ex)
            {

            }
        }

        private void LeaveChain_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Grid DaisyChainbaseScreen = (Grid)Parent;
                BoontaEveDaisyChainBaseUserControl HostuserScreen = (BoontaEveDaisyChainBaseUserControl)DaisyChainbaseScreen.FindName("DaisyChainBaseScreen");
                BoontaEveNonhostChangeSetting NonHostUserScreen = (BoontaEveNonhostChangeSetting)DaisyChainbaseScreen.FindName("BoontaEveNonhostChangeSetting");

                var list = HostuserScreen.FindName("ProfileList") as ListView;
                var SettingList= NonHostUserScreen.FindName("UserList") as ListView;
                var newuser = App.teamuser.Where(x => x.ChainID == App.selectedChainID).ToList();
                //var removedata = newuser.Where(x => x.Name != "User 1 (You)").ToList();
                foreach (var item in newuser)
                {
                  if (item.Name == newuser[1].Name)
                    {
                        item.Status = "Host - "+ newuser[2].Status;
                        item.IsHost = true;
                        item.IsUpdate = true;
                    }

                    if (item.Name == newuser[0].Name)
                    {
                        item.Isleave = true;
                        item.IsHost = false;
                        item.IsUpdate = true;
                    }
                }
                var listiem= newuser.Where(x => x.Isleave == false).ToList();
                UserList.ItemsSource = null;
                UserList.ItemsSource = listiem;
                var selectedChain = App.ChainList.Where(x => x.ID == App.selectedChainID).FirstOrDefault();
                foreach (var item in App.ChainList)
                {
                    if (item.Name== selectedChain.Name)
                    {
                        item.Status = "Connected - "+ listiem.Count+" Users";
                       
                    }
                   
                }
                list.ItemsSource = null;
                list.ItemsSource = App.ChainList;
                TotalUser(App.selectedChainID);

                App.NonHostList[1].Status= selectedChain.userLimit+" Users";
                SettingList.ItemsSource = null;
                SettingList.ItemsSource = App.NonHostList;
                Load(NonHostUserScreen);
                LeaveChainPopup.IsOpen = false;

               
                HostuserScreen.Visibility = Visibility.Visible;
                this.Visibility = Visibility.Collapsed;
                
            }
            catch (Exception ex)
            {

            }
        }
        private void Load(BoontaEveNonhostChangeSetting NonHostUserScreen)
        {

            StackPanel usercontrol = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(160, 120, 10, 10),
                HorizontalAlignment = HorizontalAlignment.Left,
                //Width = size.Width - 150,
                //Height = size.Height - 100
            };
            var itemsourc = NonHostUserScreen.FindName("ScrUsercontrol") as ScrollViewer;
            itemsourc.Content = usercontrol;
            DaisyChainSourceUserControl uc;
            string selectedinput = string.Empty;
            //var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
            //foreach (var item in lists)
            //{
            //    selectedinput = item.InputDevicename;
            //}
            Dictionary<string, string> inputdevice = new Dictionary<string, string>();
            foreach (var item in App.teamuser.Where(x=>x.Isleave==false && x.ChainID== App.selectedChainID))
            {
                inputdevice.Add(item.Name, item.ChainName);
            }

            foreach (var device in inputdevice)
            {
                uc = new DaisyChainSourceUserControl();
                //if (selectedinput == device.Key)
                //{
                //    this.InitializeComponent();
                //}
                var text = uc.FindName("txt1") as TextBlock;
                var text1 = uc.FindName("txt2") as TextBlock;
                var playbutton = uc.FindName("ison") as TextBlock;
                var selectedbutton = uc.FindName("btntop") as Button;
                var selectedImage = uc.FindName("selectedcontrol") as Image;
                var speeker = uc.FindName("btnspeaker") as Button;
                speeker.Width = 55;
                var spk = speeker.FindName("stkspeker") as StackPanel;
                spk.Width = 55;
                var spkimg = spk.FindName("speaker") as Image;
                var muteimg = spk.FindName("Mute") as Image;
                muteimg.Margin = new Thickness(20, 0, 0, 0);
                spkimg.Margin = new Thickness(25, 0, 0, 0);
                spk.HorizontalAlignment = HorizontalAlignment.Center;
                (uc.FindName("routingplaybutton") as RadioButton).Visibility = Visibility.Collapsed; ;
                // routingplaybutton.Visibility = Visibility.Collapsed;
                text.Text = device.Key;
                var strLengh = device.Value.Length;
                var strText = (strLengh < 9) ? device.Value : device.Value.Truncate(9) + "...";
                text1.Text = strText;
               // text1.Text = device.Value;
                playbutton.Text = "Selected";

                selectedImage.Source = new BitmapImage(new Uri("ms-appx:///BoontaEve/Assets/Chainnew.png"));
                usercontrol.Children.Add(uc);

            }


        }
        private void ChainCancel_Click(object sender, RoutedEventArgs e)
        {
            if (LeaveChainPopup.IsOpen) { LeaveChainPopup.IsOpen = false; }
        }

        private void btnLeaveChain_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!LeaveChainPopup.IsOpen) { LeaveChainPopup.IsOpen = true; }

            }
            catch (Exception ex)
            {

            }
        }

        private void btnNavigation_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var btn = (Button)sender;
                var mn = btn.FindName("MenuMute") as MenuFlyout;
                var mn1 = btn.FindName("MuteMenuItem") as MenuFlyoutItem;
                var mn2 = btn.FindName("UnMuteMenuItem") as MenuFlyoutItem;
                // var ctrl1 = mn1.FindName("ctrlMenutemplet") as ControlTemplate;
                var selectedUser = ((MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).Name;
                var item = App.NonHostUsers.Where(x => x.Name == selectedUser).ToList();
                if (item[0].IsMute == true)
                {
                    mn1.Visibility = Visibility.Collapsed;
                    mn2.Visibility = Visibility.Visible;
                }

               
            }
            catch (Exception ex)
            {

            }
        }

        private void btnJoinChain_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Grid DaisyChainbaseScreen = (Grid)Parent;
                BoontaEveDaisyChainBaseUserControl HostuserScreen = (BoontaEveDaisyChainBaseUserControl)DaisyChainbaseScreen.FindName("DaisyChainBaseScreen");
                var newuser = App.teamuser.Where(x => x.ChainID == App.selectedChainID).ToList();
                foreach (var item in App.teamuser.Where(x => x.Isleave == true && x.ChainID == App.selectedChainID).ToList())
                {
                    item.Isleave = false;
                    item.IsHost = true;
                    item.IsUpdate = true;

                }
                foreach (var item in App.teamuser.Where(x => x.Isleave == false && x.ChainID == App.selectedChainID).ToList())
                {
                    if (item.Name == newuser[1].Name)
                    {
                        item.Status = newuser[2].Status;
                        item.IsHost = false;
                        item.IsUpdate = true;
                    }
                }
                foreach (var item in App.teamuser.Where(x => x.ChainID == App.selectedChainID))
                {
                    item.ArrowOptionVisible = Visibility.Visible;
                }
                var list = HostuserScreen.FindName("ProfileList") as ListView;
                var updatedList = App.teamuser.Where(x => x.Isleave == false && x.ChainID==App.selectedChainID).ToList();
                var selectedChain = App.ChainList.Where(x => x.ID == App.selectedChainID).ToList();
                selectedChain[0].Status = "Connected - " + updatedList.Count + " Users";
                list.ItemsSource = null;
                list.ItemsSource = App.ChainList;

                var lstDetails = App.teamuser.Where(x => x.Isleave == false && x.ChainID==App.selectedChainID).ToList();
                UserList.ItemsSource = null;
                UserList.ItemsSource = lstDetails;
                TotalUser(App.selectedChainID);

                btnLeaveChain.Visibility = Visibility.Visible;
                reltChainsetting.Visibility = Visibility.Visible;

                btnJoinChain.Visibility = Visibility.Collapsed;
                //HostuserScreen.Visibility = Visibility.Visible;
                //this.Visibility = Visibility.Collapsed;
            }
            catch (Exception ex)
            {

            }
        }
    }
}
