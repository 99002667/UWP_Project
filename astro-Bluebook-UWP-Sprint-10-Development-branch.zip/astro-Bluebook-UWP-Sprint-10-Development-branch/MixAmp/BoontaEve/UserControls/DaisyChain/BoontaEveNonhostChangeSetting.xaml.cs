﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using MixAmp.Common.UserControls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using static MixAmp.BoontaEve.ViewModels.BoontaEveDaisyChainBaseScreenLeftPanelVM;
using Windows.UI.Xaml.Media.Imaging;
using Microsoft.Toolkit.Extensions;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.BoontaEve.UserControls.DaisyChain
{
    public sealed partial class BoontaEveNonhostChangeSetting : UserControl
    {
        public BoontaEveNonhostChangeSetting()
        {
            this.InitializeComponent();
            UserList.ItemsSource = App.NonHostList;
           Load();
        }
        private void Load()
        {

            StackPanel usercontrol = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(160, 120, 10, 10),
                HorizontalAlignment = HorizontalAlignment.Left,
                //Width = size.Width - 150,
                //Height = size.Height - 100
            };
            ScrUsercontrol.Content = usercontrol;
            DaisyChainSourceUserControl uc;
            string selectedinput = string.Empty;
            //var lists = RoutingList.ItemsSource as ObservableCollection<RoutingViewModel>;
            //foreach (var item in lists)
            //{
            //    selectedinput = item.InputDevicename;
            //}
            Dictionary<string, string> inputdevice = new Dictionary<string, string>();
            foreach (var item in App.teamuser.Where(x=>x.ChainID==2).ToList())
            {
              inputdevice.Add(item.Name, item.Status);
            }
            
            foreach (var device in inputdevice)
            {
                uc = new DaisyChainSourceUserControl();
                //if (selectedinput == device.Key)
                //{
                //    this.InitializeComponent();
                //}
                var text = uc.FindName("txt1") as TextBlock;
                var text1 = uc.FindName("txt2") as TextBlock;
                var playbutton = uc.FindName("ison") as TextBlock;
                var selectedbutton = uc.FindName("btntop") as Button;
                var selectedImage = uc.FindName("selectedcontrol") as Image;
                var speeker = uc.FindName("btnspeaker") as Button;
                speeker.Width = 55;
                var spk = speeker.FindName("stkspeker") as StackPanel;
                spk.Width = 55;
                var spkimg = spk.FindName("speaker") as Image;
                var muteimg = spk.FindName("Mute") as Image;
                muteimg.Margin = new Thickness(20, 0, 0, 0);
                spkimg.Margin = new Thickness(25, 0, 0, 0);
                spk.HorizontalAlignment = HorizontalAlignment.Center;
                (uc.FindName("routingplaybutton") as RadioButton).Visibility = Visibility.Collapsed; ;
                // routingplaybutton.Visibility = Visibility.Collapsed;
                text.Text = device.Key;
                var strLengh = device.Value.Length;
                var strText = (strLengh < 9) ? device.Value : device.Value.Truncate(9) + "...";
                text1.Text = strText;
                playbutton.Text = "Selected";

                selectedImage.Source = new BitmapImage(new Uri("ms-appx:///BoontaEve/Assets/Chainnew.png"));
                usercontrol.Children.Add(uc);

            }
            

        }
        private void leftArrow_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Grid DaisyChainNonhostUserControl = (Grid)Parent;
                BoontaEveDaisyChainNonhostUserControl baseUserControl = (BoontaEveDaisyChainNonhostUserControl)DaisyChainNonhostUserControl.FindName("BoontaEveDaisyChainNonhostUserControl");

                if (baseUserControl.Visibility == Visibility.Collapsed)
                {
                    baseUserControl.Visibility = Visibility.Visible;
                    this.Visibility = Visibility.Collapsed;
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
