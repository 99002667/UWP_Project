﻿using MixAmp.BoontaEve.ViewModels;
using MixAmp.Common.UserControls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Graphics.Display;
using Windows.UI;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using static MixAmp.BoontaEve.ViewModels.BoontaEveDaisyChainBaseScreenLeftPanelVM;
using static MixAmp.BoontaEve.ViewModels.DaisyChainHostUserViewModel;


// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.BoontaEve.UserControls.DaisyChain
{
    public sealed partial class BoontaEveDaisyChainBaseUserControl : UserControl
    {
        Grid SelectedParrentgrid;
        string selectedname;
        //static int NewProfileCount = 0;
        static int DuplicateProfileCount = 1;
        static BoontaEveDaisyChainBaseScreenLeftPanelVM OriginalProfileViewModel;
        public BoontaEveDaisyChainBaseUserControl()
        {
            try
            {
                this.InitializeComponent();
                ProfileList.ItemsSource = App.ChainList;
                ChainCount.Text = App.ChainList.Count + " CHAINS";
                this.DataContext = this;
                Size ScreenSize = this.GetScreenResolution();
                double ScreenHeight = this.GetScreenHeight(ScreenSize);
                double ScreenWidth = this.GetScreenWidth(ScreenSize);
                this.SetMaximumListHeight(ScreenHeight);
                App.loggedInUser = App.teamuser[0].ID;
            }
            catch (Exception ex)
            {


            }
        }

        private Size GetScreenResolution()
        {
            try
            {
                var bounds = ApplicationView.GetForCurrentView().VisibleBounds;
                var scaleFactor = DisplayInformation.GetForCurrentView().RawPixelsPerViewPixel;
                Size size = new Size(bounds.Width * scaleFactor, bounds.Height * scaleFactor);
                return size;
            }
            catch (Exception ex)
            {
                return new Size();
            }
        }

        private double GetScreenHeight(Size size)
        {
            return size.Height;
        }

        private double GetScreenWidth(Size size)
        {
            return size.Width;
        }

        private void SetMaximumListHeight(double screenHeight)
        {
            try
            {
                if (screenHeight >= 640 && screenHeight < 768)
                {
                    double ListHeight = (screenHeight * 0.4);
                    ProfileList.MaxHeight = ListHeight;
                }
                else if (screenHeight >= 768 && screenHeight < 1080)
                {
                    double ListHeight = (screenHeight * 0.5);
                    ProfileList.MaxHeight = ListHeight;
                }
                else if (screenHeight >= 1080)
                {
                    double ListHeight = (screenHeight * 0.55);
                    ProfileList.MaxHeight = ListHeight;
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //this.InitializeComponent();
            try
            {
                Frame parentFrame = Window.Current.Content as Frame;
                parentFrame.Navigate(typeof(MainPage));
            }
            catch (Exception ex)
            {

            }
        }
        private void DeleteProfileMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                MenuFlyoutItem menuFlyoutItem = (MenuFlyoutItem)e.OriginalSource as MenuFlyoutItem;
                BoontaEveDaisyChainBaseScreenLeftPanelVM profileViewModel = menuFlyoutItem.DataContext as BoontaEveDaisyChainBaseScreenLeftPanelVM;
                //ProfileViewModel DuplicateProfileViewModel = profileViewModel;
                var ProfileListItems = ProfileList.ItemsSource as Chain;
                int Position = ProfileListItems.IndexOf(profileViewModel);
                ProfileListItems.RemoveAt(Position);
                ProfileList.ItemsSource = ProfileListItems;
            }
            catch (Exception ex)
            {

            }
        }

        private void Profile_Name_TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            try
            {
                TextBox textBox = (TextBox)sender;
                RelativePanel relativePanel = (RelativePanel)textBox.Parent;
                TextBlock textBlock = (TextBlock)relativePanel.FindName("Profile_Name_TextBlock");
                BoontaEveDaisyChainBaseScreenLeftPanelVM profileViewModel = textBox.DataContext as BoontaEveDaisyChainBaseScreenLeftPanelVM;
                if (textBox.Visibility == Visibility.Visible)
                {
                    textBlock.Visibility = Visibility.Visible;
                    textBox.Visibility = Visibility.Collapsed;
                    textBox.Text = profileViewModel.Name;
                }
            }
            catch (Exception ex)
            {

            }
        }


        bool flag = false;

        private void Navigation_Routing(object sender, RoutedEventArgs e)
        {

            Grid DaisyChainbaseScreen = (Grid)Parent;
            SelectedParrentgrid = DaisyChainbaseScreen;
            var selectedName = ((MixAmp.BoontaEve.ViewModels.BoontaEveDaisyChainBaseScreenLeftPanelVM)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).Name;
            selectedname = selectedName;
            App.selectedChainID = ((MixAmp.BoontaEve.ViewModels.BoontaEveDaisyChainBaseScreenLeftPanelVM)((Windows.UI.Xaml.FrameworkElement)sender).DataContext).ID;

            // BoontaEveDaisyChainJoinChainUserControl HostuserJoinChainScreen = (BoontaEveDaisyChainJoinChainUserControl)DaisyChainbaseScreen.FindName("BoontaEveDaisyChainJoinChainUserControl");

            try
            {
                //if (selectedName == App.ChainList[0].Name && App.selectedChainID!=2)
                //{
                //App.ChainList[0].Is_Selected = true;
                //App.ChainList[0].IsUpdate = true;
                var chaindetail = App.ChainList.Where(x => x.ID == App.selectedChainID).ToList();
                if (chaindetail[0].isChainBlock)
                {
                    if (Message_Bar.Visibility == Visibility.Visible)
                    {
                        Message_Bar.Visibility = Visibility.Collapsed;
                    }
                    string ValidationErrorMessage = "";
                    bool IsError = false;
                    if (true)
                    {
                        ValidationErrorMessage += "You are blocked from " + selectedName;
                        IsError = true;
                    }
                    if (IsError)
                    {
                        this.SetMessageBarTimeout(Message_Bar, ValidationErrorMessage);
                    }
                    return;
                }

                if (chaindetail[0].isLocked)
                {
                    if (CheckPwdPopup.IsOpen == false)
                        CheckPwdPopup.IsOpen = true;
                }
                else
                {
                    selectedChainFun(DaisyChainbaseScreen, selectedName);
                }

                //  }
                //else if (selectedName == "Team Blue")
                //{
                //    BoontaEveDaisyChainNonhostUserControl HostuserScreen = (BoontaEveDaisyChainNonhostUserControl)DaisyChainbaseScreen.FindName("BoontaEveDaisyChainNonhostUserControl");
                //    App.ChainList[0].Is_Selected = false;
                //    App.ChainList[1].Is_Selected = true;
                //    App.ChainList[1].IsUpdate = true;

                //    var list = HostuserScreen.FindName("UserList") as ListView;
                //    var txtTotalUserCount = HostuserScreen.FindName("txtUserCountNonHost") as TextBlock;
                //    var txtHeader = HostuserScreen.FindName("txtTeamHeader") as TextBlock;
                //    var btnLeave = HostuserScreen.FindName("btnLeaveChain") as Button;
                //    var btnJoin = HostuserScreen.FindName("btnJoinChain") as Button;
                //    var chainSetting = HostuserScreen.FindName("reltChainsetting") as RelativePanel;
                //    //var chainSettingSubTitle = HostuserScreen.FindName("grdChainSettingSubtitle") as Grid;
                //    txtHeader.Text = selectedName.ToUpper();
                //    var lstDetails = App.teamuser.Where(x => x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                //    list.ItemsSource = lstDetails;
                //    int usercount = lstDetails.Count;
                //    if (usercount > 0)
                //    {
                //        txtTotalUserCount.Text = usercount + " USERS";
                //    }
                //    var isLeavecount = App.teamuser.Where(x => x.Isleave == true && x.ChainID == App.selectedChainID).ToList();
                //    if (isLeavecount.Count > 0)
                //    {
                //        btnLeave.Visibility = Visibility.Collapsed;
                //        chainSetting.Visibility = Visibility.Collapsed;                      
                //        btnJoin.Visibility = Visibility.Visible;
                //        foreach (var item in App.teamuser.Where(x => x.ChainID == App.selectedChainID))
                //        {
                //            item.ArrowOptionVisible = Visibility.Collapsed;
                //        }
                //        var lstDetails1 = App.teamuser.Where(x => x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                //        list.ItemsSource = null;
                //        list.ItemsSource = lstDetails1;
                //    }
                //    else
                //    {
                //        btnLeave.Visibility = Visibility.Visible;
                //        chainSetting.Visibility = Visibility.Visible;                       
                //        btnJoin.Visibility = Visibility.Collapsed;
                //        foreach (var item in App.teamuser.Where(x => x.ChainID == App.selectedChainID))
                //        {
                //            item.ArrowOptionVisible = Visibility.Visible;
                //        }
                //        var lstDetails1 = App.teamuser.Where(x => x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                //        list.ItemsSource = null;
                //        list.ItemsSource = lstDetails1;
                //    }
                //    if (HostuserScreen.Visibility == Visibility.Collapsed)
                //    {
                //        HostuserScreen.Visibility = Visibility.Visible;
                //        this.Visibility = Visibility.Collapsed;
                //    }

                //}

                //else
                //{
                //    var chaindetail = App.ChainList.Where(x => x.Name == selectedName).ToList();
                //    if (chaindetail[0].Status.Contains("Locked"))
                //    {
                //        if (CheckPwdPopup.IsOpen == false)
                //            CheckPwdPopup.IsOpen = true;
                //    }
                //    else
                //    {
                //        if (chaindetail[0].Status.Contains("Blocked"))
                //        {
                //            if (Message_Bar.Visibility == Visibility.Visible)
                //            {
                //                Message_Bar.Visibility = Visibility.Collapsed;
                //            }
                //            string ValidationErrorMessage = "";
                //            bool IsError = false;
                //            if (true)
                //            {
                //                ValidationErrorMessage += "You are blocked from " + selectedName;
                //                IsError = true;
                //            }
                //            if (IsError)
                //            {
                //                this.SetMessageBarTimeout(Message_Bar, ValidationErrorMessage);
                //            }
                //        }
                //        else
                //        {

                //            BoontaEveDaisyChainNonhostUserControl HostuserScreen = (BoontaEveDaisyChainNonhostUserControl)DaisyChainbaseScreen.FindName("BoontaEveDaisyChainNonhostUserControl");
                //            App.ChainList[0].Is_Selected = false;
                //            App.ChainList[1].Is_Selected = true;
                //            App.ChainList[1].IsUpdate = true;

                //            var list = HostuserScreen.FindName("UserList") as ListView;
                //            var txtTotalUserCount = HostuserScreen.FindName("txtUserCountNonHost") as TextBlock;
                //            var txtHeader = HostuserScreen.FindName("txtTeamHeader") as TextBlock;
                //            var btnLeave = HostuserScreen.FindName("btnLeaveChain") as Button;
                //            var btnJoin = HostuserScreen.FindName("btnJoinChain") as Button;
                //            var chainSetting = HostuserScreen.FindName("reltChainsetting") as RelativePanel;
                //            //var chainSettingSubTitle = HostuserScreen.FindName("grdChainSettingSubtitle") as Grid;
                //            txtHeader.Text = selectedName.ToUpper();
                //            var lstDetails = App.teamuser.Where(x => x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                //            list.ItemsSource = lstDetails;
                //            int usercount = lstDetails.Count;
                //            if (usercount > 0)
                //            {
                //                txtTotalUserCount.Text = usercount + " USERS";
                //            }
                //            var isLeavecount = App.teamuser.Where(x => x.Isleave == true && x.ChainID == App.selectedChainID).ToList();
                //            if (isLeavecount.Count > 0)
                //            {
                //                btnLeave.Visibility = Visibility.Collapsed;
                //                chainSetting.Visibility = Visibility.Collapsed;
                //                btnJoin.Visibility = Visibility.Visible;
                //                foreach (var item in App.teamuser.Where(x => x.ChainID == App.selectedChainID))
                //                {
                //                    item.ArrowOptionVisible = Visibility.Collapsed;
                //                }
                //                var lstDetails1 = App.teamuser.Where(x => x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                //                list.ItemsSource = null;
                //                list.ItemsSource = lstDetails1;
                //            }
                //            else
                //            {
                //                btnLeave.Visibility = Visibility.Visible;
                //                chainSetting.Visibility = Visibility.Visible;
                //                btnJoin.Visibility = Visibility.Collapsed;
                //                foreach (var item in App.teamuser.Where(x => x.ChainID == App.selectedChainID))
                //                {
                //                    item.ArrowOptionVisible = Visibility.Visible;
                //                }
                //                var lstDetails1 = App.teamuser.Where(x => x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                //                list.ItemsSource = null;
                //                list.ItemsSource = lstDetails1;
                //            }
                //            if (HostuserScreen.Visibility == Visibility.Collapsed)
                //            {
                //                HostuserScreen.Visibility = Visibility.Visible;
                //                this.Visibility = Visibility.Collapsed;
                //            }


                //            //BoontaEveDaisyChainJoinChainUserControl HostuserScreen = (BoontaEveDaisyChainJoinChainUserControl)DaisyChainbaseScreen.FindName("BoontaEveDaisyChainJoinChainUserControl");

                //            //if (HostuserScreen.Visibility == Visibility.Collapsed)
                //            //{
                //            //    HostuserScreen.Visibility = Visibility.Visible;
                //            //    HostuserScreen.Visibility = Visibility.Visible;
                //            //    this.Visibility = Visibility.Collapsed;
                //            //}
                //            //var list = HostuserScreen.FindName("TeamUserList") as ListView;
                //            //var txtHeader = HostuserScreen.FindName("txtHeaderText") as TextBlock;
                //            //var txtTotalUserCount = HostuserScreen.FindName("txtUserCount") as TextBlock;
                //            //txtHeader.Text = selectedName;
                //            //foreach (var item in App.NewChainList)
                //            //{
                //            //    item.Status = selectedName;
                //            //}
                //            //var lstDetails = App.NewChainList;
                //            //list.ItemsSource = null;
                //            //list.ItemsSource = lstDetails;
                //            //int usercount = lstDetails.Count;
                //            //if (usercount > 0)
                //            //{
                //            //    txtTotalUserCount.Text = usercount + " USERS";
                //            //}
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {

            }
        }

        public void selectedChainFun(Grid DaisyChainbaseScreen, string selectedName)
        {
            try
            {

                DaisyChainHostUserControl HostuserScreen = (DaisyChainHostUserControl)DaisyChainbaseScreen.FindName("DaisyChainHostUserControl");

                if (HostuserScreen.Visibility == Visibility.Collapsed)
                {
                    HostuserScreen.Visibility = Visibility.Visible;
                    this.Visibility = Visibility.Collapsed;
                }
                var txtHeader = HostuserScreen.FindName("txtTeamHeader") as TextBlock;
                var btnLeave = HostuserScreen.FindName("btnLeave") as Button;
                var btnJoin = HostuserScreen.FindName("btnJoinChain") as Button;
                var btnArrowoption = HostuserScreen.FindName("btnrightArrow") as Button;
                var lstusers = HostuserScreen.FindName("TeamUserList") as ListView;
                var lstBlockusers = HostuserScreen.FindName("BlockUserList") as ListView;
                var chainSetting = HostuserScreen.FindName("reltChainsetting") as RelativePanel;
                txtHeader.Text = selectedName.ToUpper();
                foreach (var item in App.teamuser.Where(x => x.ChainID == App.selectedChainID).ToList())
                {
                    if (item.IsHost)
                    {
                        item.Status = "Host - " + selectedName;
                        item.IsUpdate = true;
                    }
                    else
                    {
                        item.Status = selectedName;
                        item.IsUpdate = true;
                    }
                }
                //if (App.ChainList[0].Is_New)
                //{
                //    //App.teamuser[0].Is_New = true;
                //    //App.teamuser[0].IsHost = true;
                //  //  App.teamuser[0].IsUpdate = true;
                //    var newdetails = App.teamuser.Where(x => x.Is_New == true && x.IsBlocked == false).ToList();
                //    lstusers.ItemsSource = null;
                //    lstusers.ItemsSource = newdetails;
                //    // lstBlockusers.ItemsSource = null;
                //    //lstBlockusers.ItemsSource = App.teamuser.Where(x => x.Is_New == true && x.IsBlocked == true && x.Isleave == false).ToList(); ;
                //    displayUserCount(HostuserScreen, App.selectedChainID);
                //    return;

                //}
                //else
                //{
                var lst = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                lstusers.ItemsSource = null;
                lstusers.ItemsSource = lst;
                lstBlockusers.ItemsSource = null;
                lstBlockusers.ItemsSource = App.teamuser.Where(x => x.IsBlocked == true && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                displayUserCount(HostuserScreen, App.selectedChainID);
                //}

                // var isLeavecount = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == true && x.Is_New == false && x.ChainID == App.selectedChainID).ToList();
                var isLeavecount = App.teamuser.Where(x => x.ID == App.loggedInUser && x.ChainID == App.selectedChainID && x.isMember == true && x.Isleave == false).ToList();
                if (isLeavecount.Count == 0)
                {
                    btnLeave.Visibility = Visibility.Collapsed;
                    chainSetting.Visibility = Visibility.Collapsed;
                    btnJoin.Visibility = Visibility.Visible;
                    //btnArrowoption.Visibility = Visibility.Collapsed;
                    foreach (var item in App.teamuser.Where(x => x.ChainID == App.selectedChainID))
                    {
                        item.ArrowOptionVisible = Visibility.Collapsed;
                    }
                    var lst1 = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                    lstusers.ItemsSource = null;
                    lstusers.ItemsSource = lst1;
                    lstBlockusers.ItemsSource = null;
                    lstBlockusers.ItemsSource = App.teamuser.Where(x => x.IsBlocked == true && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                }
                else
                {
                    btnLeave.Visibility = Visibility.Visible;
                    chainSetting.Visibility = Visibility.Visible;
                    btnJoin.Visibility = Visibility.Collapsed;
                    foreach (var item in App.teamuser.Where(x => x.ChainID == App.selectedChainID))
                    {
                        item.ArrowOptionVisible = Visibility.Visible;
                    }
                    // btnArrowoption.Visibility = Visibility.Visible;
                    var lst2 = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();
                    lstusers.ItemsSource = null;
                    lstusers.ItemsSource = lst2;
                    lstBlockusers.ItemsSource = null;
                    lstBlockusers.ItemsSource = App.teamuser.Where(x => x.IsBlocked == true && x.Isleave == false && x.ChainID == App.selectedChainID).ToList();

                }
            }
            catch (Exception ex)
            {

            }
        }

        public void displayUserCount(DaisyChainHostUserControl HostuserScreen, int chainid)
        {
            try
            {
                var txtCount = HostuserScreen.FindName("usercount") as TextBlock;
                var txtBlockCount = HostuserScreen.FindName("blockedusercount") as TextBlock;
                if (App.ChainList[0].Is_New)
                {
                    int usercount1 = App.teamuser.Where(x => x.IsBlocked == true && x.Is_New == true).ToList().Count;
                    var cnt = App.teamuser.Where(x => x.IsBlocked == false && x.Is_New == true).ToList().Count;
                    if (usercount1 > 0)
                    {
                        if (cnt > 1)
                        {
                            txtBlockCount.Text = usercount1 + " BLOCKED USERS";
                        }
                        else
                        {
                            txtBlockCount.Text = usercount1 + " BLOCKED USER";

                        }
                    }
                    else
                    {
                        txtBlockCount.Text = "";
                    }
                    if (cnt > 0)
                    {
                        if (cnt > 1)
                        {
                            txtCount.Text = cnt + " USERS";
                        }
                        else
                        {
                            txtCount.Text = cnt + " USER";
                        }

                    }
                    else
                    {
                        txtCount.Text = "";
                    }

                }
                else
                {
                    int userCount = App.teamuser.Where(x => x.IsBlocked == true && x.Isleave == false && x.ChainID == chainid).ToList().Count;
                    var cnt = App.teamuser.Where(x => x.IsBlocked == false && x.Isleave == false && x.ChainID == chainid).ToList().Count;
                    if (userCount > 0)
                    {
                        if (userCount > 1)
                        {
                            txtBlockCount.Text = userCount + " BLOCKED USERS";
                        }
                        else
                        {
                            txtBlockCount.Text = userCount + " BLOCKED USER";
                        }

                    }
                    else
                    {
                        txtBlockCount.Text = "";
                    }
                    if (cnt > 0)
                    {
                        if (cnt > 1)
                        {
                            txtCount.Text = cnt + " USERS";
                        }
                        else
                        {
                            txtCount.Text = cnt + " USER";

                        }
                    }
                    else
                    {
                        txtCount.Text = "";
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        private void NewChain(object sender, RoutedEventArgs e)
        {
            try
            {
                var user = App.teamuser.Where(x => x.ID == App.loggedInUser).FirstOrDefault();
                foreach (var item in App.ChainList)
                {
                    if (item.Is_New || user.isMember==true)
                    {
                        if (Message_Bar.Visibility == Visibility.Visible)
                        {
                            Message_Bar.Visibility = Visibility.Collapsed;
                        }
                        string ValidationErrorMessage = "";
                        bool IsError = false;
                        if (true)
                        {
                            //ValidationErrorMessage += "Already a member of another chain. " + "\r\n" + " Please leave the connected chain to" + "\r\n" + " join new chain";
                            ValidationErrorMessage += "Already a member of another chain. Please leave the connected chain to join new chain";

                            IsError = true;
                        }
                        if (IsError)
                        {
                            this.SetMessageBarTimeout(Message_Bar, ValidationErrorMessage);
                        }
                        return;
                    }
                }

                createText.Text = string.Empty;
                if (!ChainCreatePopup.IsOpen) { ChainCreatePopup.IsOpen = true; }
            }
            catch (Exception ex)
            {

            }
        }

        //private void AddNewChain(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        BoontaEveDaisyChainCommonViewModel vm = new BoontaEveDaisyChainCommonViewModel();
        //        var ds = vm.GetChainRecord();
        //        var dt = ds.Tables[0];
        //        int newID = 0;
        //        if (Convert.ToInt32(dt.Rows[0]["daisyChainId"]) == 1)
        //        {
        //            newID = dt.Rows.Count + 1;
        //        }
        //        else
        //        {
        //            newID = 1;
        //        }
        //        ds = vm.GetUserRecord();
        //        dt = ds.Tables[0];
        //        var additem = new BoontaEveDaisyChainBaseScreenLeftPanelVM()
        //        {
        //            ID = newID,
        //            Name = createText.Text,
        //            Status = "Connected -Host- 1 User",
        //            Is_Selected = true,
        //            FortyEightV_Visibility = Visibility.Collapsed,
        //            SideBorderVisibility = Visibility.Collapsed,
        //            TextColor = new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)),
        //            Is_New = true,
        //            Is_Duplicate = false,
        //            Is_Deleted = false,
        //            userLimit = 2
        //        };

        //        App.ChainList.Insert(0, additem);
        //        DaisyChainStaticCls.SaveChainDetails(newID, createText.Text, "Connected -Host- 1 User", true, false, 1, 2, 1, false, true);

        //        int userid = 0;
        //        for (int i = 0; i < dt.Rows.Count; i++)
        //        {
        //            if (Convert.ToBoolean(dt.Rows[i]["isHost"]) == true && Convert.ToBoolean(dt.Rows[i]["isMember"]) == true)
        //            {
        //                userid = Convert.ToInt32(dt.Rows[i]["daisyChainuserId"]);
        //            }
        //        }
        //        //vm.UpdateUserRecord(true, newID, createText.Text, userid);
        //        var userdtl = App.teamuser.Where(x => x.ID == App.loggedInUser).FirstOrDefault();
        //        userdtl.ChainID = newID;
        //        userdtl.isMember = true;
        //        userdtl.Isleave = false;
        //        userdtl.IsHost = true;
        //        userdtl.IsUpdate = true;
        //        int count = (App.ChainList.Count) - 1;
        //        App.ChainList[1].Status = "Connected - " + count + " Users";
        //        App.ChainList[1].IsUpdate = true;
        //        ProfileList.ItemsSource = null;
        //        ProfileList.ItemsSource = App.ChainList;
        //        ChainCount.Text = App.ChainList.Count + " CHAINS";
        //        var user2 = App.teamuser.Where(x => x.ID == 2).FirstOrDefault();
        //        user2.IsHost = true;
        //        user2.Status = "Host -"+ user2.Status;
        //        user2.IsUpdate = true;
        //        if (ChainCreatePopup.IsOpen) { ChainCreatePopup.IsOpen = false; }

        //    }
        //    catch (Exception ex)
        //    {
        //        //(createText.Text, "Connected - 1 Users",
        //        //  true, false, Visibility.Collapsed, Visibility.Collapsed,
        //        //  new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false)
        //    }
        //}
        private void AddNewChain(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrWhiteSpace(createText.Text))
            {
                try
                {
                    BoontaEveDaisyChainCommonViewModel vm = new BoontaEveDaisyChainCommonViewModel();
                    var ds = vm.GetChainRecord();
                    var dt = ds.Tables[0];
                    int newID = 0;
                    if (Convert.ToInt32(dt.Rows[0]["daisyChainId"]) == 1)
                    {
                        newID = dt.Rows.Count + 1;
                    }
                    else
                    {
                        newID = 1;
                    }
                    ds = vm.GetUserRecord();
                    dt = ds.Tables[0];
                    var additem = new BoontaEveDaisyChainBaseScreenLeftPanelVM()
                    {
                        ID = newID,
                        Name = createText.Text,
                        Status = "Connected -Host- 1 User",
                        Is_Selected = true,
                        FortyEightV_Visibility = Visibility.Collapsed,
                        SideBorderVisibility = Visibility.Collapsed,
                        TextColor = new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)),
                        Is_New = true,
                        Is_Duplicate = false,
                        Is_Deleted = false,
                        userLimit = 2
                    };
                    App.ChainList.Insert(newID - 1, additem);
                    DaisyChainStaticCls.SaveChainDetails(newID, createText.Text, "Connected -Host- 1 User", true, false, 1, 2, 1, false, true);
                    int userid = 0;
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        if (Convert.ToBoolean(dt.Rows[i]["isHost"]) == true && Convert.ToBoolean(dt.Rows[i]["isMember"]) == true)
                        {
                            userid = Convert.ToInt32(dt.Rows[i]["daisyChainuserId"]);
                        }
                    }
                    //vm.UpdateUserRecord(true, newID, createText.Text, userid);	
                    var userdtl = App.teamuser.Where(x => x.ID == App.loggedInUser).FirstOrDefault();
                    userdtl.ChainID = newID;
                    userdtl.isMember = true;
                    userdtl.Isleave = false;
                    userdtl.IsHost = true;
                    userdtl.IsUpdate = true;
                    int count = (App.ChainList.Count) - 1;
                    App.ChainList[1].Status = "Connected - " + count + " Users";
                    App.ChainList[1].IsUpdate = true;
                    ProfileList.ItemsSource = null;
                    ProfileList.ItemsSource = App.ChainList;
                    ChainCount.Text = App.ChainList.Count + " CHAINS";
                    var user2 = App.teamuser.Where(x => x.ID == 2).FirstOrDefault();
                    user2.IsHost = true;
                    user2.Status = "Host -" + user2.Status;
                    user2.IsUpdate = true;
                    if (ChainCreatePopup.IsOpen) { ChainCreatePopup.IsOpen = false; }
                }
                catch (Exception ex)
                {
                    //(createText.Text, "Connected - 1 Users",	
                    //  true, false, Visibility.Collapsed, Visibility.Collapsed,	
                    //  new SolidColorBrush(Color.FromArgb(255, 255, 54, 0)), false, false)	
                }
            }
        }

        private void ClosePopupClicked(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ChainCreatePopup.IsOpen) { ChainCreatePopup.IsOpen = false; }
            }
            catch (Exception ex)
            {

            }
        }

        private void btnPWDCancel_Click(object sender, RoutedEventArgs e)
        {

            CheckPwdPopup.IsOpen = false;
        }

        private void CheckPWD_Click(object sender, RoutedEventArgs e)
        {
            BoontaEveChangeSettingForHostUserControl HostuserScreen = (BoontaEveChangeSettingForHostUserControl)SelectedParrentgrid.FindName("BoontaEveChangeSettingForHostUserControl");
            var pwd = HostuserScreen.FindName("txtPWD") as TextBlock;
            if (txtPassword.Text == pwd.Text)
            {
                var chaindetail = App.ChainList.Where(x => x.ID == App.selectedChainID).ToList();
                if (chaindetail[0].ID == 3)
                {
                    foreach (var item in App.ChainList.Where(x => x.ID == chaindetail[0].ID).ToList())
                    {
                        item.Status = "Connected - 3 Users";
                    }

                    ProfileList.ItemsSource = null;
                    ProfileList.ItemsSource = App.ChainList;
                    selectedChainFun(SelectedParrentgrid, selectedname);
                }
                else
                {
                    selectedChainFun(SelectedParrentgrid, selectedname);
                }

            }
            else
            {
                // txtPassword.Text = txtPWD.Text;
                if (Message_Bar.Visibility == Visibility.Visible)
                {
                    Message_Bar.Visibility = Visibility.Collapsed;
                }
                string ValidationErrorMessage = "";
                bool IsError = false;
                if (true)
                {
                    ValidationErrorMessage += "Incorrect password. Try again.";
                    IsError = true;
                }
                if (IsError)
                {
                    this.SetMessageBarTimeout(Message_Bar, ValidationErrorMessage);
                }
            }

            CheckPwdPopup.IsOpen = false;
        }
        private async void SetMessageBarTimeout(MessageBar MessageBar, string ValidationErrorMessage)
        {
            this.ShowValidationErrorMessage(MessageBar, ValidationErrorMessage);
            await Task.Delay(3000);
            this.HideValidationErrorMessage(MessageBar);
        }
        private void ShowValidationErrorMessage(MessageBar MessageBar, string ValidationErrorMessage)
        {
            if (MessageBar.Visibility == Visibility.Collapsed)
            {
                TextBlock Message_Text_Box = (TextBlock)MessageBar.FindName("Message_Text");
                //Message_Text_Box.VerticalAlignment = (VerticalAlignment)AlignmentY.Center;
                Message_Text_Box.Text = ValidationErrorMessage;
                Message_Text_Box.Margin = new Thickness(5, 10, 0, 0);
                MessageBar.Visibility = Visibility.Visible;
            }
        }

        private void HideValidationErrorMessage(MessageBar MessageBar)
        {
            if (MessageBar.Visibility == Visibility.Visible)
            {
                MessageBar.Visibility = Visibility.Collapsed;
            }
        }

        private void CheckPwdPopup_Opened(object sender, object e)
        {

            Popup p = (Popup)sender;

            Border sp = (Border)p.Child;
            StackPanel tb = (StackPanel)sp.FindName("checkpwdstack");
            TextBox tbs = (TextBox)tb.FindName("txtPassword");
            tbs.Text = string.Empty;
            tbs.Focus(FocusState.Pointer);


        }
    }
}