﻿using System;
using MixAmp.Carbonite.ViewModels;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using MixAmp.Common.UserControls.Setting;
using MixAmp.BoontaEve.ViewModels;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.BoontaEve.UserControls
{
    public sealed partial class BoontaEveSleepModeSettingsMenu : UserControl
    {
        public BoontaEveSleepModeSettingsMenu()
        {
            this.InitializeComponent();
            BoontaEveSleepModeSettingsList.ItemsSource = new BoontaEveSleepModes();
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            StackPanel SettingsStackPanel = (StackPanel)SettingsRelativePanel.Parent;
            FlyoutPresenter SettingsFlyoutPresenter = (FlyoutPresenter)SettingsStackPanel.Parent;
            Popup SettingsPopup = (Popup)SettingsFlyoutPresenter.Parent;

            if (SettingsPopup.IsOpen)
            {
                SettingsPopup.IsOpen = false;
            }
        }

        /*private void Radio_Sleep_Click(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = e.OriginalSource as RadioButton;
            if (radioButton != null)
            {
                BoontaEveSleepModeViewModel BoontaEveSleepModeViewModel = radioButton.DataContext as BoontaEveSleepModeViewModel;
                BoontaEveSleepModeSettingsList.SelectedItem = BoontaEveSleepModeViewModel;
            }
        }*/

        private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        {
            RelativePanel CurrentMenuParent = this.Parent as RelativePanel;
            UIElementCollection UIElements = CurrentMenuParent.Children;

            foreach (var UIElement in UIElements)
            {
                if (UIElement is BoontaEveSleepModeSettingsMenu)
                {
                    if (this.Visibility == Visibility.Visible)
                    {
                        this.Visibility = Visibility.Collapsed;
                    }
                }
                else if (UIElement is BoontaEveDeviceSettingsMenu)
                {
                    BoontaEveDeviceSettingsMenu DeviceSettingsMenu = UIElement as BoontaEveDeviceSettingsMenu;
                    if (DeviceSettingsMenu.Visibility == Visibility.Collapsed)
                    {
                        DeviceSettingsMenu.Visibility = Visibility.Visible;
                    }
                }
            }
        }

        private void BoontaEveSleepModeSettingsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListView ListView = (ListView)sender as ListView;
            foreach (var item in ListView.Items)
            {
                var ListViewItem = (ListViewItem)ListView.ContainerFromItem(item);
                var ItemViewGrid = (Grid)ListViewItem.ContentTemplateRoot;
                var radioButton = ItemViewGrid.FindName("Boonta_Eve_Radio_Sleep") as RadioButton;
                BoontaEveSleepModeViewModel BoontaEveSleepModeViewModel = (BoontaEveSleepModeViewModel)item;

                if (ListViewItem.IsSelected)
                {
                    radioButton.IsChecked = true;
                    BoontaEveSleepModeViewModel.IsSelected = true;
                }
                else
                {
                    radioButton.IsChecked = false;
                    BoontaEveSleepModeViewModel.IsSelected = false;
                }
            }
        }

        private void Boonta_Eve_Radio_Sleep_Click(object sender, RoutedEventArgs e)
        {
            RadioButton radioButton = e.OriginalSource as RadioButton;
            if (radioButton != null)
            {
                BoontaEveSleepModeViewModel BoontaEveSleepModeViewModel = radioButton.DataContext as BoontaEveSleepModeViewModel;
                BoontaEveSleepModeSettingsList.SelectedItem = BoontaEveSleepModeViewModel;
            }
        }
    }
}
