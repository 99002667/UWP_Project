﻿using MixAmp.BoontaEve.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.BoontaEve.UserControls.Mixer
{
    public sealed partial class BoontaEveMixerRightPanelDisableUserControl : UserControl
    {
        public BoontaEveMixerRightPanelDisableUserControl()
        {
            this.InitializeComponent();
        }
        /// <summary>
        /// manupulate the grid as per angle 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Grid_ManipulationDelta(object sender, ManipulationDeltaRoutedEventArgs e)
        {

            try
            {
                var grid = sender as Grid;
                var angle = GetAngle(e.Position, grid.RenderSize);
                (this.DataContext as MixerViewModel).Angle = angle;
                (this.DataContext as MixerViewModel).UpdateSource();

            }
            catch (Exception ex)
            {

            }

        }
        /// <summary>
        /// define enum for calculate angle of globe
        /// </summary>
        public enum Quadrants : int { nw = 2, ne = 1, sw = 4, se = 3 }

        private double GetAngle(Point touchPoint, Size circleSize)
        {
            var _X = touchPoint.X - (circleSize.Width / 2d);
            var _Y = circleSize.Height - touchPoint.Y - (circleSize.Height / 2d);
            var _Hypot = Math.Sqrt(_X * _X + _Y * _Y);
            var _Value = Math.Asin(_Y / _Hypot) * 180 / Math.PI;
            var _Quadrant = (_X >= 0) ?
                (_Y >= 0) ? Quadrants.ne : Quadrants.se :
                (_Y >= 0) ? Quadrants.nw : Quadrants.sw;
            switch (_Quadrant)
            {
                case Quadrants.ne: _Value = 90 - _Value; break;
                case Quadrants.nw: _Value = 270 + _Value; break;
                case Quadrants.se: _Value = 90 - _Value; break;
                case Quadrants.sw: _Value = 270 + _Value; break;
            }
            return _Value;
        }
    }
}
