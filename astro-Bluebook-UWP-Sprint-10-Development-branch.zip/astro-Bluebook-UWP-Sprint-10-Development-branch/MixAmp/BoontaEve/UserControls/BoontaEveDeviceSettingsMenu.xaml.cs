﻿using MixAmp.BoontaEve.ViewModels;
using MixAmp.Carbonite.UserControls;
using MixAmp.Common.UserControls.Setting;
using MixAmp.Common.ViewModels;
using MixAmp.Common.Views;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace MixAmp.BoontaEve.UserControls
{
    public sealed partial class BoontaEveDeviceSettingsMenu : UserControl
    {
        public BoontaEveDeviceSettingsMenu()
        {
            this.InitializeComponent();
            BoontaEveDeviceSettingsList.ItemsSource = new BoontaEveDeviceSettings();
        }

        private void Bluetooth_Toggled(object sender, RoutedEventArgs e)
        {
            Windows.UI.Xaml.Controls.ToggleSwitch ToggleSwitch = sender as Windows.UI.Xaml.Controls.ToggleSwitch;
            RelativePanel ToggleSwitchParent = (RelativePanel)ToggleSwitch.Parent;
            Grid Grid = (Grid)ToggleSwitchParent.Parent;
            TextBlock Actual_Settings_Name = (TextBlock)Grid.FindName("Actual_Settings_Name");
            BoontaEveDeviceSettingsViewModel BoontaEveDeviceSettingsViewModel = Grid.DataContext as BoontaEveDeviceSettingsViewModel;
            string id = "1";
            if (ToggleSwitch.IsOn)
            {
                BoontaEveDeviceSettingsViewModel.Actual_Settings_Name = "On";
                DeviceSpecificDataViewModel.UpdateBluetooth(true, id);

            }
            else if (!ToggleSwitch.IsOn)
            {
                BoontaEveDeviceSettingsViewModel.Actual_Settings_Name = "Off";
                DeviceSpecificDataViewModel.UpdateBluetooth(false, id);
            }
            Actual_Settings_Name.Text = BoontaEveDeviceSettingsViewModel.Actual_Settings_Name;
        }

        private void Close_Flyout(object sender, RoutedEventArgs e)
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            StackPanel SettingsStackPanel = (StackPanel)SettingsRelativePanel.Parent;
            FlyoutPresenter SettingsFlyoutPresenter = (FlyoutPresenter)SettingsStackPanel.Parent;
            Popup SettingsPopup = (Popup)SettingsFlyoutPresenter.Parent;

            if (SettingsPopup.IsOpen)
            {
                SettingsPopup.IsOpen = false;
            }
        }
        private void LED_Brightness_Slider_PointerReleased(object sender, PointerRoutedEventArgs e)
        {
            Slider LED_Brightness_Slider = sender as Slider;
            string id = "1";
            DeviceSpecificDataViewModel.UpdateLEDBrightness((int)LED_Brightness_Slider.Value, id);
        }
        //private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        //{
        //    RelativePanel CurrentMenuParent = this.Parent as RelativePanel;
        //    UIElementCollection UIElements = CurrentMenuParent.Children;

        //    foreach (var UIElement in UIElements)
        //    {
        //        if (UIElement is BoontaEveDeviceSettingsMenu)
        //        {
        //            if (this.Visibility == Visibility.Visible)
        //            {
        //                this.Visibility = Visibility.Collapsed;
        //            }
        //        }
        //        else if (UIElement is MainSettingsMenu)
        //        {
        //            MainSettingsMenu MainSettingsMenu = UIElement as MainSettingsMenu;
        //            if (MainSettingsMenu.Visibility == Visibility.Collapsed)
        //            {
        //                MainSettingsMenu.Visibility = Visibility.Visible;
        //            }
        //        }
        //    }
        //}
        private void Arrow_Left_Click(object sender, RoutedEventArgs e)
        {
            RelativePanel CurrentMenuParent = this.Parent as RelativePanel;
            UIElementCollection UIElements = CurrentMenuParent.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is BoontaEveDeviceSettingsMenu)
                {
                    if (this.Visibility == Visibility.Visible)
                    {
                        this.Visibility = Visibility.Collapsed;
                        var mainSetting = CurrentMenuParent.FindName("MainSettingsMenu") as MainSettingsMenu;
                        string BoontaName = DeviceSpecificDataViewModel.GetBoontaEveDeviceName();
                        var devicetext = mainSetting.FindName("SelectedDevice") as TextBlock;

                        var mainList = mainSetting.FindName("MainSettingsList") as ListView;
                        int count = 0;
                        foreach (var item in mainList.Items)
                        {
                            var ListViewItem = (ListViewItem)mainList.ContainerFromItem(item) as ListViewItem;
                            if (ListViewItem != null)
                            {
                                var itemGrid = (Grid)ListViewItem.ContentTemplateRoot as Grid;
                                var settingsName = itemGrid.FindName("Settings_Name") as TextBlock;
                                var DeviceName = itemGrid.FindName("Settings_Status") as TextBlock;
                                if (count == 0)
                                {
                                    (item as BoontaEveMainSettingsViewModel).Name = BoontaName;
                                    settingsName.Text = BoontaName;
                                    Frame parentFrame = Window.Current.Content as Frame;
                                    var lastpage = parentFrame.Content.ToString();
                                    if (lastpage.Contains("MainPage"))
                                    {
                                        devicetext.Text = "SETTINGS";
                                    }
                                    else if (lastpage.Contains("TabHeader"))
                                    {
                                        devicetext.Text = BoontaName;
                                    }
                                }
                                count++;
                            }
                        }
                    }
                }
                else if (UIElement is MainSettingsMenu)
                {
                    MainSettingsMenu MainSettingsMenu = UIElement as MainSettingsMenu;
                    if (MainSettingsMenu.Visibility == Visibility.Collapsed)
                    {
                        MainSettingsMenu.Visibility = Visibility.Visible;
                    }
                }
            }
        }
        private void Arrow_Right_Click(object sender, RoutedEventArgs e)
        {
            Button Arrow_Right = sender as Button;
            var SettingsViewModel = Arrow_Right.DataContext;

            if (SettingsViewModel is BoontaEveDeviceSettingsViewModel)
            {
                BoontaEveDeviceSettingsViewModel BoontaEveDeviceSettingsViewModel = (BoontaEveDeviceSettingsViewModel)SettingsViewModel;
                if (BoontaEveDeviceSettingsViewModel.Name.Equals("Name"))
                {
                    NewNamePopup.IsOpen = true;
                }
                else
                if (BoontaEveDeviceSettingsViewModel.Name.Equals("Daisy Chain"))
                {
                    ShowBoontaEveDaisyChainSettingsMenu();
                }
                else if (BoontaEveDeviceSettingsViewModel.Name.Equals("Sleep Mode"))
                {
                    ShowSleepModeSettingsMenu();
                }
                else if (BoontaEveDeviceSettingsViewModel.Name.Equals("Reset Device"))
                {
                    ShowResetDeviceScreen();
                }
            }
        }
        //private void Save_Click(object sender, RoutedEventArgs e)
        //{
        //    string NewName = Namedevice_txt.Text;
        //    var device = DeviceNameText.Text;

        //    ListView listView = BoontaEveDeviceSettingsList as ListView;
        //    foreach (var item in listView.Items)
        //    {
        //        var ListViewItem = (ListViewItem)listView.ContainerFromItem(item) as ListViewItem;
        //        if (ListViewItem != null)
        //        {
        //            var itemGrid = (Grid)ListViewItem.ContentTemplateRoot as Grid;
        //            var settingsName = itemGrid.FindName("Settings_Name") as TextBlock;
        //            var DeviceName = itemGrid.FindName("Actual_Settings_Name") as TextBlock;
        //            if (settingsName.Text == "Name")
        //            {
        //                (item as BoontaEveDeviceSettingsViewModel).Actual_Settings_Name = NewName;
        //                DeviceName.Text = NewName;
        //            }
        //        }
        //        BoontaEveDeviceSpecificDataViewModel.UpdateName(NewName, "1");
        //        if (NewNamePopup.IsOpen) { NewNamePopup.IsOpen = false; }
        //        Frame parentFrame = Window.Current.Content as Frame;
        //        var lastpage = parentFrame.Content.ToString();
        //        var page = "BoontaEve";
        //        if (lastpage == "MixAmp.MainPage")
        //        {
        //            parentFrame.Navigate(typeof(MainPage), page);
        //        }
        //        else if (lastpage == "MixAmp.BoontaEve.Views.TabHeader")
        //        {
        //            parentFrame.Navigate(typeof(MixAmp.BoontaEve.Views.TabHeader));
        //        }
        //    }
        //}
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            string NewName = Namedevice_txt.Text;
            if (!String.IsNullOrWhiteSpace(NewName))
            {
                var device = DeviceNameText.Text;
                ListView listView = BoontaEveDeviceSettingsList as ListView;
                foreach (var item in listView.Items)
                {
                    var ListViewItem = (ListViewItem)listView.ContainerFromItem(item) as ListViewItem;
                    if (ListViewItem != null)
                    {
                        var itemGrid = (Grid)ListViewItem.ContentTemplateRoot as Grid;
                        var settingsName = itemGrid.FindName("Settings_Name") as TextBlock;
                        var DeviceName = itemGrid.FindName("Actual_Settings_Name") as TextBlock;
                        if (settingsName.Text == "Name")
                        {
                            (item as BoontaEveDeviceSettingsViewModel).Actual_Settings_Name = NewName;
                            DeviceName.Text = NewName;
                            DeviceNameText.Text = NewName;
                        }
                    }
                    BoontaEveDeviceSpecificDataViewModel.UpdateName(NewName, "1");
                }
                if (NewNamePopup.IsOpen) { NewNamePopup.IsOpen = false; }
                //Frame parentFrame = Window.Current.Content as Frame;	
                //var lastpage = parentFrame.Content.ToString();	
                //var page = "BoontaEve";	
                //if (lastpage == "MixAmp.MainPage")	
                //{	
                //    parentFrame.Navigate(typeof(MainPage), page);	
                //}	
                //else if (lastpage == "MixAmp.BoontaEve.Views.TabHeader")	
                //{	
                //    parentFrame.Navigate(typeof(MixAmp.BoontaEve.Views.TabHeader));	
                //}	
            }
        }
        private void Slider_ValueChanged(object sender, RangeBaseValueChangedEventArgs e)
        {
            Slider LED_Brightness_Slider = sender as Slider;
            StackPanel LED_Brightness_Slider_Parent = (StackPanel)LED_Brightness_Slider.Parent;
            TextBlock Actual_Settings_Name = (TextBlock)LED_Brightness_Slider_Parent.FindName("Actual_Settings_Name");
            BoontaEveDeviceSettingsViewModel BoontaEveDeviceSettingsViewModel =
                LED_Brightness_Slider.DataContext as BoontaEveDeviceSettingsViewModel;
            if (BoontaEveDeviceSettingsViewModel.Name.Equals("LED Brightness"))
            {
                string Slider_Brightness_Value = String.Format(e.NewValue.ToString());
                Actual_Settings_Name.Text = Slider_Brightness_Value + "%";
                BoontaEveDeviceSettingsViewModel.Actual_Settings_Name = Slider_Brightness_Value + "%";
            }
        }

        private void ShowBoontaEveDaisyChainSettingsMenu()
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            UIElementCollection UIElements = SettingsRelativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is BoontaEveDaisyChainMenu)
                {
                    BoontaEveDaisyChainMenu BoontaEveDaisyChainMenu = (BoontaEveDaisyChainMenu)UIElement;
                    BoontaEveDaisyChainMenu.Visibility = Visibility.Visible;
                }
                else if (UIElement is BoontaEveDeviceSettingsMenu)
                {
                    BoontaEveDeviceSettingsMenu BoontaEveDeviceSettingsMenu = (BoontaEveDeviceSettingsMenu)UIElement;
                    BoontaEveDeviceSettingsMenu.Visibility = Visibility.Collapsed;
                }
            }
        }

        public void ShowSleepModeSettingsMenu()
        {
            RelativePanel SettingsRelativePanel = this.Parent as RelativePanel;
            UIElementCollection UIElements = SettingsRelativePanel.Children;
            foreach (var UIElement in UIElements)
            {
                if (UIElement is BoontaEveSleepModeSettingsMenu)
                {
                    BoontaEveSleepModeSettingsMenu SleepModeSettingsMenu = (BoontaEveSleepModeSettingsMenu)UIElement;
                    SleepModeSettingsMenu.Visibility = Visibility.Visible;
                }
                else if (UIElement is BoontaEveDeviceSettingsMenu)
                {
                    BoontaEveDeviceSettingsMenu BoontaEveDeviceSettingsMenu = (BoontaEveDeviceSettingsMenu)UIElement;
                    BoontaEveDeviceSettingsMenu.Visibility = Visibility.Collapsed;
                }
            }
        }

        public void ShowResetDeviceScreen()
        {
            ((Frame)Window.Current.Content).Navigate(typeof(ResetBaseScreen));
        }
    }
}

